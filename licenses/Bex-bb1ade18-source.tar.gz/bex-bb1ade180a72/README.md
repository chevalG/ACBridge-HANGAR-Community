# Bex

[![NuGet Version](https://img.shields.io/nuget/v/JKAnderson.Bex?logo=nuget&label=NuGet&color=%23004880)](https://www.nuget.org/packages/JKAnderson.Bex)

An enhanced binary reader and writer for .NET. This is mostly a personal project for use in my other libraries, so depend on it at your own risk.


## Changelog

### 1.0.1
- Make source paths relative for cleaner stack traces
