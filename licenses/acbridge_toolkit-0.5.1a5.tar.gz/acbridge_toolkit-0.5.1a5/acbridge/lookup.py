# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
import copy
from difflib import SequenceMatcher
import json
from pathlib import Path
import re
import unicodedata

NAMESPACES=('character','ac_part','weapon','project_sample','assembled_frame')

class BridgeError(Exception):
    def __init__(self, code, message, **details):
        super().__init__(message)
        self.code,self.details=code,details

def normalize(value):
    return ''.join(c for c in unicodedata.normalize('NFKC',value).casefold() if c.isalnum())

def catalog():
    return json.loads((Path(__file__).parent/'data/assets.json').read_text(encoding='utf-8'))

def assembled_frame(query):
    """An assembly convention, never evidence that files exist or an official ID."""
    m=re.fullmatch(r'frame_(\d+)',query or '',re.I)
    if not m:return None
    ident=m.group(1)
    return dict(id='frame_'+ident,name_en='Same-ID AC assembly '+ident,namespace='assembled_frame',category='ac_assembly_convention',is_game_id=False,
        aliases=[],sources=[dict(source_id='assembly_convention',type='tool_convention',document='docs/discovery.md',basis='bd/hd/am/lg_m_NUMBER; no game identity or file availability inferred')],
        components=[p+'_M_'+ident for p in ('BD','HD','AM','LG')],availability='not_inspected',limitations=['Resources are not yet inspected; this convention is not proof of original files or compatible bones.'],operations=['export_dynamic_frame','export_static','check_assembly'],
        operation_status={'export_dynamic_frame':'attemptable','export_static':'attemptable','check_assembly':'diagnostic'},
        related_workflows=[dict(operation='export_dynamic_frame',status='attemptable',document='docs/dynamic-pipeline.md')],
        next_step='Use discover-assets against the installed index or expanded roots to check files, then export or check-assembly. Not a compatibility guarantee.')

def lookup_asset(query, namespace=None, limit=10):
    if not isinstance(query,str) or not normalize(query) or len(query)>200:
        raise BridgeError('invalid_query','Provide a non-empty asset name or ID, at most 200 characters.')
    if namespace is not None and namespace not in NAMESPACES:
        raise BridgeError('invalid_namespace','Choose one of: '+', '.join(NAMESPACES))
    if isinstance(limit,bool) or not isinstance(limit,int) or not 1<=limit<=50:
        raise BridgeError('invalid_limit','limit must be an integer in 1..50.')
    data=catalog();q=normalize(query)
    entries=[e for e in data['entries'] if namespace is None or e['namespace']==namespace]
    matches=[]
    for e in entries:
        labels=[e['id'], e['name_en'], *e['aliases']]
        hit=next((s for s in labels if normalize(s)==q),None)
        if hit is not None:matches.append((1.0,e,hit))
    exact=bool(matches)
    # Unknown syntactically valid IDs must not be silently corrected to a neighbor.
    idlike=bool(re.fullmatch(r'(?:c\d{4}|(?:hd|bd|am|lg)m\d{4}|wp[a-z]\d{4}|frame\d{4})',q))
    if not matches and not idlike:
        for e in entries:
            labels=[e['name_en'],*e['aliases']]
            scored=[]
            for s in labels:
                n=normalize(s)
                score=SequenceMatcher(None,q,n).ratio()
                if len(q)>=2 and q in n:score=max(score,0.9)
                scored.append((score,s))
            score,hit=max(scored)
            if score>=0.65:matches.append((score,e,hit))
    # Equipment name index: display names/designations -> technical IDs.
    from .nameindex import search_name_index
    ni=search_name_index(query,namespace,limit)
    ni_rows=ni['results'] if ni['status']!='not_found' else []
    ni_exact=ni['status'] in ('unique','ambiguous')
    exact=exact or ni_exact
    from .workflows import describe
    catalog_ids={e['id'].upper() for _,e,_ in matches}
    ni_by_id={r['id'].upper():r for r in ni_rows}
    rows=[]
    for score,e,hit in matches:
        row=copy.deepcopy(e)
        row.update(describe(row['id']))
        row['match']={'method':'exact' if exact or score==1.0 else 'fuzzy','score':round(score,4),'matched_text':hit}
        row['sources']=[dict(source_id=k,**data['sources'][k]) for k in e['sources']]
        extra=ni_by_id.get(e['id'].upper())
        if extra is not None:
            row['display_name']=extra['name_en']
            row['name_index']=extra['name_index']
        rows.append((score,row))
    for ni_row in ni_rows:
        if ni_row['id'].upper() in catalog_ids:continue
        ni_row.update(describe(ni_row['id']))
        rows.append((ni_row['match']['score'],ni_row))
    derived=assembled_frame(query)
    if not rows and derived and namespace in (None,'assembled_frame','project_sample'):
        derived['match']=dict(method='assembly_convention',score=1.0,matched_text=query)
        return dict(schema_version=1,status='unique',query=query,namespace=namespace,total=1,truncated=False,results=[derived],next_step=derived['next_step'],catalog_version=data['catalog_version'],coverage='Project assembly convention; actual resource availability not inspected')
    rows.sort(key=lambda m:(-m[0],m[1]['id']))
    total=len(rows)
    status='not_found' if not total else ('unique' if total==1 else 'ambiguous') if exact else 'suggestions'
    result=[row for _,row in rows[:limit]]
    response=dict(schema_version=1,status=status,query=query,namespace=namespace,total=total,truncated=total>limit,results=result,
                next_action='Use an explicit candidate ID before processing.' if status in ('ambiguous','suggestions') else 'No indexed mapping; supply more context or verified source evidence.' if status=='not_found' else None,
                catalog_version=data['catalog_version'],coverage=data['coverage'])
    if ni_rows:response['name_index']=ni['name_index']
    return response
