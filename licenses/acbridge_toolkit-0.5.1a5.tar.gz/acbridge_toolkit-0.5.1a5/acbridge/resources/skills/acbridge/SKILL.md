# Skill: acbridge（随包版 · ACBridge Toolkit 0.5.1a5）

AC6 资产桥接工具的 Agent 操作说明。本文件随 wheel/sdist 分发，对应 **MCP 10 个
工具**；不要使用旧版全局 Skill（历史版本只列 4 个工具且边界过时）。安装位置：
`acbridge resources` 输出的 `skill` 路径；`acbridge init WORKSPACE` 会连同文档
一起复制。

## 支持边界（先读这个）

- **Alpha 首发范围 = expanded-only 动态路径**：用户已合法展开的 FLVER/Skeleton/
  HKX/compendium 输入。静态（export_static）与 Game 提取（--game-dir）入口是
  **历史代码**，不在首版支持承诺内。
- 无注册门禁：编目/索引收录不是许可，未收录也不阻止显式输入的真实尝试。
- 诚实语义：partial=有真实产物但有限；output_valid / 数值一致 ≠ 动态外观 PASS
  （dynamic_appearance 未验证就是未验证）。

## MCP 工具（10 个，与 CLI 同一实现）

查询类（无需配置）：
1. `lookup_asset(query, namespace?, limit?)` — 显示名（MORLEY / HD-011 MELANDER）、
   型号代号、PARAM 行 ID 或资源 ID → 技术身份链（row_id / model_id / resource_id），
   附槽位、左右侧、装备标志与逐条证据。歧义返回候选，不猜测。
2. `name_index_status(config?)` — 名称索引覆盖、版本、本地叠加与权利状态。
3. `asset_capabilities(query?)` — bounded profile 与操作边界。

处理类（需 ACBRIDGE_CONFIG 指向合法配置）：
4. `export_dynamic_frame(asset, output, input_roots|game_dir, parts?, clips?, ...)`
   — 四槽装配 + 原版 HKX 动画导出（主路径）。parts: {bd,hd,am,lg}→资源 stem；
   assembly_method: geometry(默认)/relative/baseline；blender_adapter:
   default/identity-basis；animation_check: sampled/all-keys。
5. `export_static(asset, output, input_roots|game_dir)` — 历史静态单模型路径。
6. `discover_assets(query?, kind?, input_roots?, game_dir?)` — 实际文件/索引发现。
7. `list_clips(archive?, ...)` — ANIBND 内真实 HKX 元数据。
8. `check_assembly(asset, output, parts?)` — 骨架/权重/参考差异诊断；永不作为导出门禁。
9. `inspect_result(output)` — 作业 GLB/Validator/回读证据复核。
10. `build_name_index(msg_root, regulation, archive_index?, output?)` — 从用户合法
    拥有的 FMG/PARAM 生成本地名称索引（私有数据，禁止再分发）。

## 典型流程

```
lookup_asset("MORLEY")            → ambiguous: WP_R_4110(shoulder_right)/WP_L_4110(shoulder_left)
lookup_asset("HD-011 MELANDER")   → unique HD_M_1010
export_dynamic_frame("frame_1010", output, input_roots=[".../expanded"], parts={...})
inspect_result(output)
```

失败处理：读 `error.code/message`、`failures`、作业日志；缺资源请用户提供正确目录；
输出必须是 output_root 中新子目录。名称索引状态与许可边界见包内
docs/name-index.md；法律门禁状态见 docs/licensing.md（当前 Release Blocked）。
