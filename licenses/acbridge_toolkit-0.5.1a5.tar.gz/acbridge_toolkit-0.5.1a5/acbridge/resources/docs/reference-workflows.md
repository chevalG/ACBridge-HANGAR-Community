# 参考数据工作流（research_reference）

lookup 结果中的 `research_reference` 工作流表示：编目与名称索引是**带来源引用的
参考数据**，不是运行许可，也不是覆盖率白名单。

- 技术编目（`assets.json`，24 条）：数值事实 + 证据定位符；T66 起不含任何显示名或
  社区标签。来源与整改记录见 [catalog-provenance.md](catalog-provenance.md)。
- 装备名称索引（`name_index.json`，278 条）：显示指称串 → 行 ID / 模型 ID / 资源档
  的映射，逐条证据引用；状态为 review candidate，详见 [name-index.md](name-index.md)。
- "编目未收录"不等于"不能处理"：动态路径不设注册门禁，显式部件/HKX 输入允许真实
  尝试；反过来"编目收录"也不构成任何授权或兼容保证。
- 法律门禁（数据权、历史贡献权属、最终发布授权）与这些参考数据的关系见
  [licensing.md](licensing.md)。
