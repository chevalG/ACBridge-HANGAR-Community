# 静态导出路径（历史代码，Alpha 不承诺支持）

`export-static` / MCP `export_static` 是 T47–T53 时代的单模型静态转换路径：把一个
FLVER（武器或同尾号四槽机体）经现有 vendored 后端转成 GLB/Blend，材质使用既有静态
近似。它保留在本候选中仅为透明与复现历史结果。

## 支持边界（重要）

- **Alpha 首发支持范围是 expanded-only 动态路径**（见 [dynamic-pipeline.md](dynamic-pipeline.md)
  与 [installation.md](installation.md)）。静态与 Game 提取入口属于**历史代码**，
  不在首版安装/发行支持承诺内。
- 静态 bounded profile 仅覆盖 `WP_R_1610`、`WP_L_0411`、`frame_1010` 三个历史样本；
  其他 `WP_*_NUMBER` / `frame_NUMBER` 是显式尝试，成功与否以实际输出为准。
- 材质为静态近似；partial 表示"有真实产物但消费检查未全过"，不是完整转换认证。

## 输入与工具

- expanded 模式：`--input-root`（可多次）提供已展开 FLVER/DDS/材质库；无需
  NuxeBridge/Witchy。
- game 模式：`--game-dir` 触发现有 Nuxe/Witchy 定点提取；需要本机已装外部工具
  （见 [dependencies.md](dependencies.md)），且 WitchyBND 在无附加控制台的进程链中
  可能要求交互终端（环境依赖，见 installation.md「Game 输入」）。

## 结果语义

先读 `completion`（output_valid / gltf_validator_passed / consumer_validation_passed）
与 `failures`、`warnings`；用 `acbridge inspect JOB` 复核。输出必须是配置 output_root
中不存在的新子目录。历史样本的已知边界见 [known-limitations.md](known-limitations.md)。
