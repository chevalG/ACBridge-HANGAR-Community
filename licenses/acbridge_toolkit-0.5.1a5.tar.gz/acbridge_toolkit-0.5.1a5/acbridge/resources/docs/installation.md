# wheel安装与展开输入

本说明不依赖开发源码。Python3.11+，本机已测3.12/3.14；其他平台未获本轮认证。包名acbridge-toolkit，命令acbridge，模块acbridge。始终用目标venv的python执行pip。

```powershell
py -3 -m venv .venv
./.venv/Scripts/python.exe -m pip install './acbridge_toolkit-0.5.1a5-py3-none-any.whl'
./.venv/Scripts/python.exe -m pip install './acbridge_toolkit-0.5.1a5-py3-none-any.whl[dynamic,mcp,preview]'
./.venv/Scripts/acbridge.exe init ./workspace
```

裸包零依赖、可完全离线安装（第一条命令即可查询/发现）。进入workspace后用acbridge；可激活venv，也可用exe绝对路径，无法激活不需改安全策略。动态用dynamic extra，MCP用mcp extra，GIF用preview extra；此候选尚未上传PyPI。extras 依赖第三方 PyPI 包
（numpy/scipy/Pillow/mcp==1.29.0）：部分镜像源未同步全部版本（如 mcp==1.29.0 在
某些镜像无匹配版本报 No matching distribution），这是**镜像源覆盖问题，不是本包
缺陷**；可显式指定源 `pip install -i https://pypi.org/simple ...` 或提前在有网
环境下载 wheel 后离线安装。运行测试需要 sdist 源码树（wheel 不含 tests）：解包
`acbridge_toolkit-0.5.1a5.tar.gz` 后 `python -m unittest discover -s tests -p "test_*.py"`。

## 安装外部Validator、配置

Node.js需在PATH。安装官方Khronos npm包，保留完整包目录，不只复制index.js：

```powershell
npm install --prefix ./user-tools gltf-validator@2.0.0-dev.3.10
Copy-Item config.example.json config.local.json
acbridge doctor --config config.local.json --input-mode expanded
```

至少配置validator和专用output_root。所有相对配置路径以JSON目录解释。可选增加`"blender":"C:/YOUR_BLENDER/blender.exe"`获得数值回读、asset.blend。无Blender时GLB仍可生成，blender_consumption=not_run，不是动态PASS。请求render-preview必须有Blender；GIF还需preview extra。

**动态展开输入不需要外部importer、Adapter.exe、NuxeBridge.exe、WitchyBND.exe、Nuxe索引或dotnet。** 即使旧配置有无效nuxe_res，明确input-root的资源发现也只扫描输入。

## 用户提供合法展开资源

一个足够的布局如下（示例不随包提供）：

```text
expanded/
  parts/
    BD_M_1010/BD_M_1010.flver
    BD_M_1010/Skeleton.hkx
    BD_M_1010/BD_M_1010.compendium
    HD_M_1010/HD_M_1010.flver
    HD_M_1010/Skeleton.hkx
    AM_M_1010/AM_M_1010.flver
    AM_M_1010/Skeleton.hkx
    LG_M_1010/LG_M_1010.flver
    LG_M_1010/Skeleton.hkx
  chr/c0000/Skeleton.hkx
  clips/a000_020100.hkx
  clips/a000_01.compendium
```

四部件Skeleton是真实对应参考骨架；HD/AM/LG有自己的compendium则保留，没有时沿用现有BD类型表回退，不替换Skeleton。动作HKX和其compendium相邻。c0000是动作源骨架，不是部件Skeleton；需要类型表时明确--skeleton-compendium。

Witchy原嵌套目录也支持，保留部件前缀的容器归属，不必手工扁平化。不要把所有Skeleton挤入同一目录。只有BHD/BDT不构成展开输入；Game链缺失时见dependencies.md，工具不会凭空生成资源。

## 发现、导出、检查

```powershell
acbridge discover-assets --input-root ./expanded --kind part --config config.local.json --limit 20
acbridge list-clips --input-root ./expanded --config config.local.json --output ./jobs/bank --limit 10
acbridge export-dynamic-frame frame_1010 --input-root ./expanded --clip a000_020100 --config config.local.json --output ./jobs/first
acbridge inspect ./jobs/first --config config.local.json
```

输出须为output_root内不存在的新子目录；输入只读。优先取asset-ue.glb。partial要看计数、failures、verification和sources.json。装有Blender时，可另建作业显式试R3适配：

```powershell
acbridge export-dynamic-frame frame_1010 --input-root ./expanded --clip a000_020100 --config config.local.json --output ./jobs/blender-check --blender-adapter identity-basis --animation-check all-keys
```

不是解锁，也不是泛兼容保证。Blender默认型号差异、NLA、秒时间与FPS见blender-playback.md。

混装可用`export-dynamic-frame my-ac --part bd=BD_M_2010 --part hd=HD_M_3010 --part am=AM_M_4210 --part lg=LG_M_6010 ...`，必须提供对应真实资源。models、clip-spec、source skeleton显式格式见dynamic-pipeline.md。

## Game输入

已有工具时用--game-dir替代input-root，并`doctor --input-mode game`；配置额外填nuxe_bridge/nuxe_res/witchy。Nuxe本体不是NuxeBridge，不可互换。没有公开桥接安装包时，Game-only新用户仍被依赖阻断；本轮可承诺的是用户已有合法展开资源路线。注意：WitchyBND在无附加控制台的进程链（部分无人值守运行器/重定向stdio环境）中可能报"PromptPlus requires a terminal"并中止——该行为依赖启动环境（控制台环境下不复现）；规避方式为使用展开输入或带控制台的运行环境。
