# Blender 动画消费

优先导入 asset-ue.glb，它将 RootMotion 纳入 skin joints；这是标准 glTF 文件，不专属 Unreal。用干净场景，导入前设 scene.render.fps=30、fps_base=1（或自己所需 FPS），以相同时间基导入与求值。工具的自动回读从 factory-startup 空场景开始。

glTF 动画输入是秒。源 frames 表示样本数量，不是 Blender 场景帧终点。161 keys 跨2.6667秒，原生60Hz，30FPS场景覆盖约80个帧间隔；24FPS场景约64个。按秒换算 `scene_frame = strip.frame_start + seconds * scene_fps / fps_base`，不要拿源第160个样本直接当场景第160帧。

导入多动画时会生成 NLA tracks/strips，有时同时保留活动 action。推荐在 NLA Editor 只解除目标 Root 或 In-Place 所在轨的静音，其余轨静音，同时把 Animation Data 的活动 action 清空，避免叠加。脚本可以：

```python
arm.animation_data.action = None
for track in arm.animation_data.nla_tracks:
    track.mute = not any(strip.action and 'a000_020100_inplace' in strip.action.name for strip in track.strips)
scene.frame_set(12)
# 通过 evaluated_depsgraph_get() 读取求值网格，不能只读未求值基础网格。
```

实际 action/strip 名以导入结果为准，Blender4.5可能使用 action slots。另一条路径是静音所有 NLA，只选择正确活动 action 及其 armature slot；不要同时启用两种消费方式。切换后更新 scene/depsgraph。

大位移片段先看 root-analysis.json，固定相机可能出画。In-Place 保留高度，仍可能上升数百米；可用跟随相机观察，工具不截断数据。不把额外 Icosphere 当 GLB 节点：T59 的观察对象不在原文件中，来源未确认；本轮标准空场景回读与文件节点清单单独核对，不声称查明用户插件来源。
# T62可选消费路径与实际预览

导出时`--blender-adapter identity-basis`显式采用T61-R3单次导入适配：仅在import_scene.gltf期间临时替换显示骨轴选择，finally恢复，不改GLB或用户全局Blender。默认`default`仍保留原导入方式，其数值误差若超0.1mm会独立报告failed，不自动改路径。

打开输出asset.blend后按空格播放。场景已设30FPS、清空active Action且仅启用第一段In-Place NLA；切换动作需先静音其他NLA。不要将pose.matrix_basis一律重置为单位矩阵，这会破坏部分未关键帧补偿。骨custom_shape由实际引用识别并隐藏渲染，不按Icosphere名字猜测。

`--animation-check all-keys --render-preview`生成真实每key间隔的斜视GIF，另有首/三分之一/三分之二/末key的正侧斜三视图。PNG、GIF及秒时间在preview-manifest.json；默认sampled仅稀疏检查/预览。GIF时间有10ms量化，末端key PNG单独保留。原始glTF时间是秒，30FPS是显示时间基，不把161keys/2.6667s误称30Hz。

数值passed只证明该Blender消费与GLB CPU一致；机械连接、绝对姿态或原版额外驱动仍需看实际画面。详细分项见verification.md。以下保留T60的动作/时间使用说明。

