# Equipment name index (T66-N)

`acbridge lookup` now resolves AC6 equipment **display names** to the technical
identity chain: PARAM row id → `equipModelId` → real resource archive. The
shipped builtin index covers the player-equippable scope; users can overlay a
locally built index from their own extraction. No game installation is needed
for queries.

```
acbridge lookup "MORLEY"          → ambiguous: WP_R_4110 (shoulder_right) / WP_L_4110 (shoulder_left)
acbridge lookup "HD-011 MELANDER" → unique: HD_M_1010 (slot HD, model 1010, row 50000000)
acbridge lookup "30200000"        → unique: WP_R_4110 (query by PARAM row id)
acbridge name-index               → coverage, versions, rights status
```

## What a hit contains

Every result distinguishes the three ID kinds explicitly:

| Field | Meaning | MORLEY example |
| --- | --- | --- |
| `name_index.row_id` | EquipParamWeapon / EquipParamProtector row | 30200000 |
| `name_index.model_id` | `equipModelId` (shared per frame family / weapon) | 4110 |
| `id` / `name_index.resource_stem` | real archive identity | `WP_R_4110` / `wp_r_4110` |

Weapons additionally carry `slot_group` (arm/shoulder), `side` (right/left),
verbatim `equip_flags` (hand/back eligibility), and `weapon_bay_compatible`.
Parts carry `slot` (BD/HD/AM/LG). Every entry carries `evidence` selectors into
the FMG text, the PARAM row and the archive index, with source SHA256 digests.

## Ambiguity policy

R/L pairs of one weapon (for example MORLEY) are two distinct equipment rows
with different archives; both are returned with explicit side labels and a
`disambiguation` note. A designation spanning frame slots (MELANDER) returns
all four slots. Nothing is silently narrowed: pick the explicit resource ID
before converting. Unknown syntactically valid IDs (`WP_R_9999`) still return
`not_found`; partial inputs only ever produce unconfirmed `suggestions`.

## Shared archives and inferred stems

Most weapons have side-specific archives (`wp_r_`/`wp_l_`). Some models also
ship a shared `wp_a_` archive; rows without a side-specific archive fall back
to it and are marked `resource_basis: archive_inventory_shared`. Content
verification (T67-R, 2026-10-26) showed `wp_a_` and side archives are
**complementary packages, not alternatives** — geometry, skeleton and textures
may be split across them:

- **model 2720 (VP-66LR)**: no `wp_r` exists; `wp_a_2720` is the only
  right-hand candidate (full package). The left-hand variant has its own
  distinct mesh `wp_l_2720` (FLVER sizes/hashes differ) without its own
  Skeleton.hkx/behbnd. Both rows carry `content_verification` notes.
- **model 3010 (44-141 JVLN ALPHA)**: `wp_a_3010` carries geometry;
  `wp_l_3010` is a textures-only package (no FLVER). The left row lists
  `companion_stems: ["wp_a_3010"]` — a left-hand conversion needs both.
- **models 0221/0230/0910** (left-hand blades): `wp_l` carries the model;
  the coexisting `wp_a` is animation+textures only.
- The a+l+r models (1410, 2020, …) were not content-checked and carry no
  verification note; their side-specific resolution is unchanged.

Range-25 shields record only `leftBackEquipable` in the param while community
references describe them as left arm units; flags stay verbatim and the slot
group follows the row range (documented per entry in `slot_note`).

## Coverage of the builtin index

`T66N.2-builtin-engus` (see `acbridge name-index`): 194 weapon rows
(107 distinct designations: 47 right-hand, 47 left-hand, 13 left-hand blades,
7 shields, 40+40 shoulder pairs) and 84 part rows (23 HD / 17 BD / 19 AM /
25 LG), all verified against the archive index — zero unresolved stems.
Excluded by rule: expansions (row 75), head scans (80), NPC/system rows
(29/38/95) and the unnamed protector rows (59/99 range, no FMG text).

## Local index build (any language, your data)

```
acbridge build-name-index --msg-root PATH/TO/msg/engus/item-msgbnd-dcx \
  --regulation PATH/TO/regulation-bin \
  --archive-index PATH/TO/BinderKeys-Data0.txt   # optional stem verification
```

Writes `name_index.local.json` beside the config (or `~/.acbridge/`). The file
overlays the builtin index per (kind, row_id) key at query time; precedence:
`ACBRIDGE_NAME_INDEX` paths, config sibling, `~/.acbridge/`. It is private
convenience data for that installation and must not be redistributed. MCP
mirrors the same surface (`name_index_status`, `build_name_index`; lookup is
the same `lookup_asset` as the CLI).

## Provenance and distribution basis

Entries map one FMG item designation string (model code and/or unit name) to
numeric facts and an archive path citation. Per-entry evidence selectors and
per-file SHA256 digests identify the source extraction; the referenced files
are not included. Descriptive FMG files (説明) are never read; Paramdex
community labels are not used; the 24-record technical catalog
(`assets.json`) is unchanged from T66. The builtin index is regenerable from
any legally owned local extraction via `scripts/generate_builtin_name_index.py`
or `acbridge build-name-index`.

Distribution status: **review candidate**. Individual item designations are
short identifier strings and the mapping is numeric facts, but database /
extraction rights, trademark review and the owner's final publication approval
remain open gates — the same posture as the rest of the release candidate
(see `docs/licensing.md` and `docs/catalog-provenance.md`). Locally built
indexes carry an explicit do-not-redistribute notice. Deleting the builtin
file does not break the tool: queries fall back to technical IDs and local
builds.
