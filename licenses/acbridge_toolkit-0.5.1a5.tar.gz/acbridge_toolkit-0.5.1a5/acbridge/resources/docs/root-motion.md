# Root Motion、In-Place 与实际世界位移

Root 模式 = 现有适配器能够表达的 HKX extractedMotion 额外父层 × 原始骨轨。无 extractedMotion 时额外层 identity，内部 Master/Root/BD_Root 仍可移动。实际变换要按层级连乘，不能仅看一个节点。In-Place 在共同父层抵消 **BD_Root世界XZ与相对yaw**，保留Y高度、pitch/roll和原骨局部通道，不等于三维静止，也不保证 RootMotion 本身严格零。

T60 对 a000_024615 的原 HKX、已解码轨道、T59 raw/adapted GLB 作了全161关键帧、65900唯一蒙皮顶点的数值检查。原 extractedMotion末值约[0.000136,0,-900.758301,0]；原 Root局部Y从3.530704到887.485840，增量883.955136。导出Root的绝对偏移来自目标参考姿态，增量在float32误差内一致。

| 实际量 | Root | In-Place |
|---|---:|---:|
| RootMotion最大位移 |900.758301m|0.299510m|
| BD_Root世界Y增量 |884.351062m|884.351062m|
| BD_Root最大水平漂移 |900.465736m|3.66e-8m|
| 蒙皮世界质心终点位移 |1262.057841m|884.707249m|

原大位移分属Y与Z，没有发现标准 glTF 消费中重复应用父变换。raw/adapted质心一致。蒙皮使用 `worldJoint * inverseBind * vertex`，不能再额外乘 mesh-node 世界变换。模型的绝对游戏朝向、动作语义仍 UNKNOWN/继承研究边界，单位沿T47按米解释；没有新的游戏引擎等价性证明。

161samples包含160intervals，源duration2.666666746秒、frameDuration0.0166666675秒，即约60Hz。GLB已保留正确时间与全部keys；30FPS是Blender显示时间基，不是这段源采样率。无需修改时长或截断位移。新导出每段结果列 native fps，root-analysis.json 从实际GLB计算全帧骨世界及蒙皮世界指标；超过50m仅提示 LARGE_WORLD_DISPLACEMENT，不禁止处理。

UE只抽取RootMotion根骨不会自动把内部Master/Root位移升级为Actor运动。开启RootMotion、ForceRootLock、重设parent或再手动应用轨迹都会改变消费语义。In-Place父层是反向补偿，不应直接用来推动Actor。当前非零extracted yaw仅保留平移/骨轨并标记partial_root_representation；不宣称完整旋转表示，也不重做UE系统。详细原始数值见 research/root-motion-evidence.json，T60新产物数值以各job/root-analysis.json为准。
