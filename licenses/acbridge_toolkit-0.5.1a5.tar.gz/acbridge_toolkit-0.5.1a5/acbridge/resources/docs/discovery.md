# 资源发现

先 `discover-assets --kind frame|part|weapon|archive --config config.local.json`，再按 query 搜索或 limit/offset 分页。无须全游戏数据库，索引来自配置的 Nuxe `BinderKeys/ArmoredCore6_PC/Hash/*.txt`；它是已有工具的文本资料，不保证当前游戏版本所有容器内容。加 Game 目录会报告相应 BHD/BDT 是否存在，**不会因此声称 FLVER 已解析**。已有展开目录可 `--input-root`，按实际文件发现。

frame_NUMBER 是同尾号四槽的组合约定。发现返回实际 available/missing slots；不完整组合仍可通过 --part 覆盖。lookup 同样识别该约定，但 availability=not_inspected，不会伪造游戏官方名称。原始部件 stem 和项目标签分列。

动画：`list-clips --archive /chr/c0000_a000_01.anibnd.dcx --game-dir YOUR_GAME --config config.local.json --output jobs/bank`。也接受 `c0000_a000_01`；展开目录用 `--input-root PATH`，可附 archive 过滤容器；本地 packed ANIBND 用 `--archive PATH`，工具先复制到新作业再展开，绝不原地解包输入。

每行返回真实 clip_id、filename、路径/sha256、archive、动画类型、frames、duration_seconds、frame_duration_seconds、transform_tracks、binding_track_count、original_skeleton、实际解析 compendium、extracted_motion。字段无法获取时为 null/UNKNOWN；动作语义始终 UNKNOWN，不能根据 ID猜测招式。元数据 parse 失败仍列为 error，整体 partial。Skeleton-only HKX 单列 non_animation_hkx。

轻量 TagFile 扫描不执行 spline decode，因此 changing-track 特征不伪装已算出；需要完整轨道时用 decode-hkx/动态导出。compendium 为相邻或受限祖先目录的候选，记录首次能实际解析的类型表和此前错误；可解析不等于证明任意动画绑定适用。完整 bank 结果在 result_json，返回 clips 分页；继续读取已提取的 bank 可用报告中的展开目录作为新 --input-root，不必再次从 Game 提取。

例如 a100_020101 的元数据是114轨；c0000常用源骨架130骨。用户仍可发起转换尝试。若不覆盖所选源骨架，会得到 animation_skeleton_mismatch，保留其他动作及有用的 bind pose，不做许可检查。
