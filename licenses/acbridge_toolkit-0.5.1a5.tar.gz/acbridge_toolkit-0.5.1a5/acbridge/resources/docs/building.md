# Build and corresponding source

Python >=3.11 is required. Build frontend and setuptools are separately installed
from their declared package sources; they are not bundled third-party binaries.
From the unpacked source root in PowerShell:

```powershell
py -3 -m venv .build-venv
./.build-venv/Scripts/python.exe -m pip install build "setuptools>=77"
./.build-venv/Scripts/python.exe scripts/build_release.py
```

The script stages reviewed resources, generates the file source matrix, and
builds sdist then wheel in isolation from sdist. It requires no game resources,
developer directories, private config, global skills or native tool bridges.
The build frontend may download declared build dependencies. A byte-identical
wheel across tool versions/timestamps is not promised; package source equality
is checked during the T66 artifact audit. Publish both matching artifacts.

Install the wheel in a separate empty directory:

```powershell
py -3 -m venv .venv
./.venv/Scripts/python.exe -m pip install "./acbridge_toolkit-0.5.1a5-py3-none-any.whl[dynamic,mcp,preview]"
./.venv/Scripts/python.exe -m acbridge --version
./.venv/Scripts/python.exe -m acbridge init workspace
```

Follow installation.md for user-provided legal expanded inputs and npm Validator.
Blender is optional; without it numerical Blender consumption stays not_run.
No Game unpacking executable or native compression library is distributed.
Do not include local verification jobs, original inputs, private evidence,
virtualenvs, caches or developer paths in source/wheel publication.
dependencies.md records optional external components. The local verification
pip freeze is evidence of one environment, not a cross-platform dependency lock.
