# 依赖、获取与许可清单

本轮只验证Windows本地工作流。版本列是实测版本/明确契约，不编造未测版本范围；更换版本请用doctor和实际输出复核。所有链接为原项目入口，不是ACBridge分发承诺。游戏文件用户自行提供，不捆绑。

| 组件 | 作用/何时需要 | 实测或要求 | 许可/获取 |
|---|---|---|---|
| Python | CLI及解码/组装 | >=3.11；3.12/3.14已有实测 | PSF；[python.org](https://www.python.org/downloads/) |
| NumPy/SciPy | 动态网格矩阵/旋转 | >=1.26/>=1.12，dynamic extra自动解析 | BSD-3-Clause；[NumPy](https://numpy.org/install/)、[SciPy](https://scipy.org/install/)；具体安装版本和依赖许可由pip记录 |
| Pillow | GIF预览、静态贴图 | >=10，preview/conversion extra | HPND及附加组件许可；[Pillow](https://pillow.readthedocs.io/en/stable/installation/basic-installation.html) |
| MCP Python SDK | 可选stdio MCP | ==1.29.0 | MIT；[官方SDK](https://github.com/modelcontextprotocol/python-sdk) |
| Node.js | 调用Validator模块 | 使用Node可require模块；本轮以实装版本记录，不声明最低兼容版 | MIT及附带组件；[Node官网](https://nodejs.org/en/download) |
| gltf-validator | 真实GLB格式验证 | 2.0.0-dev.3.10；完整npm包 | Apache-2.0及NOTICES；[Khronos官方项目](https://github.com/KhronosGroup/glTF-Validator)，其README链接官方npm包。`npm install --prefix ./user-tools gltf-validator@2.0.0-dev.3.10` |
| Blender | 可选数值消费/场景/预览；静态转换必需 | 本轮4.5.12 LTS；R3适配需对应io_scene_gltf2内部API | GPL；[Blender官网](https://www.blender.org/download/)、[LTS](https://www.blender.org/download/lts/)；不随wheel分发 |
| FLVER importer | 仅既有静态转换外部工具；动态解析代码已随包 | 本机0.2.0，manifest要求Blender>=4.2 | GPL-3.0-or-later；[原仓库](https://github.com/shintheweapon/Blender-flver-importer)，需确认发布包相符；动态展开入口不需要外装它 |
| Nuxe资源索引/核心库 | Game按路径定位/提取BHD/BDT；可选纯索引发现 | 既有Nuxe1.2.1和匹配res；本机目标net10.0-windows | [Nuxe官方](https://github.com/JKAnderson/Nuxe) GPL-3.0，BinderKeys子库Apache-2.0；索引许可不自动授权游戏名称/参数 |
| NuxeBridge.exe | ACBridge调用Nuxe库的本地桥接 | 现有本地net10.0-windows工程；不是Nuxe.exe | **无经核实公开二进制获取入口/完整构建分发许可**。不编造下载地址，不作为陌生Game-only用户可安装承诺 |
| WitchyBND.exe | Game/packed ANIBND复制到作业后展开 | 本机3.0.1.0，ProductVersion含3e03b31249ce7786078d4432ab02a2ed1ca593c2 | [官方仓库](https://github.com/ividyon/WitchyBND)、[官方Releases](https://github.com/ividyon/WitchyBND/releases)；GPL-3.0及捆绑组件需逐项审计；展开输入无需它 |
| Adapter.exe | 仅既有静态链对SoulsFormats的本地桥接 | net10.0-windows及匹配DLL | 本地项目代码授权未清、无经核实公开安装包；不是Witchy替代品 |
| .NET Desktop Runtime | 运行本机Windows桥接/WPF依赖 | 本机桥接target net10.0-windows | [Microsoft官方.NET](https://dotnet.microsoft.com/download/dotnet/10.0)；仅Game/静态桥接需要 |
| Oodle等原生压缩库 | 某些外部工具/源资源压缩路径可能需要 | 由用户工具版本决定 | 专有授权；不包含在wheel，不提供非官方获取链接，不认为GPL覆盖其授权。若外部工具无法合法准备，改用已展开输入 |

## 两条动态输入路线

**展开输入**：Python动态extra + Node/Validator即可新生成蒙皮动画GLB。Blender可选；无需Adapter/NuxeBridge/Witchy/Nuxe索引/importer/.NET。外部工具缺失不应让doctor此路线报整体失败。

**Game输入**：另外需要NuxeBridge+匹配Nuxe资源目录+Witchy；不能把Nuxe官方本体重命名成NuxeBridge。用户已有合法可用工具时可用；若没有，本轮不承诺补齐该路径。错误信息引导到展开输入，而不是下载不明EXE。

静态链继续保留，但它的Adapter及外部importer依赖与动态展开不同；`doctor --workflow static --input-mode expanded|game`单独检查，不把静态依赖强加到动态路径。

## 安装结果的来源

pip安装清单、Python/Node/Blender实际版本和wheel哈希应保留在自己的评估目录。不要随包带个人路径、完整Game数据、捕获、缓存或工具DLL。本文链接的上游许可只约束对应组件，不能替代ACBridge自身授权；见licensing.md。
