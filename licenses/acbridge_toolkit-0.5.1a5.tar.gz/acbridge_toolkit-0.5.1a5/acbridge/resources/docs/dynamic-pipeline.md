# 动态提取当前输入和结果契约

完整入口和配置见README；不依赖旧任务接线。新Agent先discover-assets/list-clips自行选目标，再直接export-dynamic-frame。不是所有frame_NUMBER都有四件，查询是组合约定而非官方机体身份证明。

## 输入与发现

Game模式：现有Nuxe精确提取 `/parts/STEM.partsbnd.dcx`、`/chr/c0000.anibnd.dcx` 与所选clip所在的实际ANIBND；Witchy展开到新job/cache。展开模式用一个或多个--input-root，保留容器目录归属。四槽默认bd/hd/am/lg_m_NUMBER，--part逐槽覆盖。HD/AM/LG优先本件compendium，否则BD类型表；这只是类型表复用，不是替换Skeleton。

原版常用来源：walk a000_020100位于 `/chr/c0000_a000_01.anibnd.dcx` + `a000_01.compendium`，jump a000_081200位于 `_02` + `a000_02.compendium`。来源有真实提取证据；其余用list-clips，不猜动作名。任意clip ID按aAAA前缀搜索实际c0000动画包，--clip-spec可给精确archive。动画绑定与用户所选source skeleton必须实际对应；没有固定机体/动画白名单或统一30FPS门槛。

Witchy需要真实控制台，Windows创建隐藏控制台。递归-1只在所需文件实际存在、可解析并通过后续验证时作为warning；其他真实错误不吞掉。

## 明确指定输入

--models PATH相对于其JSON文件目录解释路径，恰好四槽；可明确选择搜索根以外或不同命名的真实文件：

```json
{"parts": {
 "bd":{"flver":"body.flver","hkx":"body.hkx","comp":"types.compendium"},
 "hd":{"flver":"head.flver","hkx":"head.hkx","comp":"types.compendium"},
 "am":{"flver":"arms.flver","hkx":"arms.hkx","comp":"types.compendium"},
 "lg":{"flver":"legs.flver","hkx":"legs.hkx","comp":"types.compendium"}
}}
```

也接受外层frame_NUMBER或数字键。models优先于自动part选择；complete仅元数据，不是完整性保证。--skeleton-hkx与--skeleton-compendium可明确源动作骨架，否则发现c0000 Skeleton。源文件都参与只读保护。

--clip-spec PATH格式如下；不写--clip则处理spec全部键，写了选择子集：

```json
{
 "my_motion":{"hkx":"motions/actual.hkx","compendium":"motions/types.compendium","label":"用户标签","identity":"UNKNOWN"},
 "a000_050100":{"archive":"/chr/c0000_a000_02.anibnd.dcx","compendium":"a000_02.compendium"}
}
```

明确compendium路径/文件名是权威输入，缺失时不暗换另一张；未指定才相邻发现。完整models、clip-spec、source skeleton可不提供Game/搜索根。Game和input-root互斥。独立decode-hkx仍是同一T47算法：

```powershell
py -3 -B acbridge.py decode-hkx --clip CLIP.hkx --compendium TYPES.compendium --skeleton-hkx SOURCE.hkx --config CONFIG --output jobs/decode
```

## 处理、骨架和错误

沿用T47列向量参考局部映射：`L_target(t)=L_target_ref * inverse(L_source_ref) * L_source(t)`；世界FK，真实FLVER动态权重，原顶点/LOD0面/骨名完整回读。共享参考帧差超过1e-4时报告reference_frame_conflict，包含完整冲突值。该判断反映现有单绑定帧合并算法限制，不作为未知输入的许可检查。缺独立Skeleton报part_skeleton_missing；缺真实权重骨报missing_weighted_bones并给part/FLVER/影响权重数；114轨对130骨报animation_skeleton_mismatch，列expected/actual/missing/unexpected。可选check-assembly给实际parent/local/world及权重诊断。

各clip独立定位、解码、导出。失败保留其余clip；所有clip失败仍尝试真实bind pose，animations为空、bind_pose_only=true。四件不能组成真实蒙皮时保留原提取、解码与诊断，不制造GLB成功。实际TRS剪切、无效权重、非有限值、输出Validator错误仍如实报告。

completion.output_valid表示当前几何/源读回/Validator要求的结果，不表示已获用户视觉认可；consumer_validation失败另记。partial常因演示材质/未知绝对朝向，也可能动作不全，必须查看failures和计数。默认摘要，磁盘完整result.json不截断；inspect检查当前文件hash和结构。

## 输出和时间

asset.glb含真实四件、统一skin、关节及Root/In-Place；asset-ue.glb把RootMotion加入joints/IBM，网格置场景根、根通道排首。原版NODE_SKINNED_MESH_NON_ROOT警告以实际层级解释，不能单靠警告断言动作全丢失；跨工具优先适配版。两版Validator原始报告分别保存。

decoded/保留新解码keys/验证；models/source-skeleton是本次新读输入；sources/extraction记录真实路径、sha256、Game快照。dynamic-readback验证完整FLVER与所有动画/适配通道；root-analysis计算全部导出keys和唯一蒙皮顶点的世界位移。可用Blender时新建空场景实际导入/求值并保存asset.blend。

保留原生样本与duration，采样率是(samples-1)/duration，可能30/60Hz。场景播放30FPS独立于源keys；原Y-up、尺寸按米解释，不使用静态frame高度归一化。Root/In-Place精确定义和a000_024615数值见root-motion.md；Blender操作见blender-playback.md。源模型绝对游戏朝向仍继承UNRESOLVED。

## Unreal参考

沿用T51/T55经验用asset-ue.glb和Interchange，导入SkeletalMesh/AnimSequence，关闭不需要的physics asset；自定义动画采样30会重采样显示，研究原生60Hz时选实际源率或保持时间。RootMotion首轨映射到同名根骨；RootMotion与ForceRootLock独立。裸SkeletalMeshActor不会自动将轨迹消费成Actor运动，消费者须自己定义Root/内部骨轨的处理。VSM模板需要SM6。T60不启动UE/PIE、不创建工程，不把过去T55实播当成本轮新产物实播证据。
# T62当前默认

默认使用R1相对参考骨架+R2刚性几何挂接，具体方法见assembly-pipeline.md。CLI/MCP新增对应的assembly_method、blender_adapter、animation_check、render_preview，命令拼写与例子以根README为准。下文显式源文件格式、资源路径和Root/In-Place约定继续有效；历史固定样本不是运行许可或白名单。

