# T66 licensing candidate — Release Blocked

The project owner has authorized preparation of a free software candidate with
commercial use permitted. ACBridge project-controlled contributions and the
combined distribution use GPL-3.0-only (GNU GPL version 3). This is a candidate
license choice within the owner's rights, not final public release approval.
LICENSE contains the full GPLv3 text; NOTICE identifies component exceptions.
No additional noncommercial or field-of-use limitation is added to GPL rights.

The actual fixed HavokLib and SoulsAssetPipeline source headers explicitly allow
GPL version 3 or later. T65's shorthand GPL-3.0 must not be read as GPL-only.
Their existing grants remain GPL-3.0-or-later. The GPL-only choice for this
combination does not revoke upstream recipients' original alternative grants.
FLVER's two parser files remain unmodified GPL-3.0-or-later copies. tag0c.py
contains MIT-licensed TagTools/Havoc portions; its full MIT notice is retained.
See licenses/Upstream-notices.txt and licenses/upstream-sources.json for fixed
refs, actual header text and hashes. No clean-room claim remains for the ports.

Source notices dated 2026-10-26 identify T66 attribution-only edits. Earlier
ACBridge changes include Python translation, AC6 THREECOMP24/STRAIGHT16,
TCM0/compendium support, and local environment/output-path handling. No decode,
sampling, retargeting or assembly mathematics was rewritten for licensing.
The AST check and independent T63-B rerun are technical evidence, not legal consent.

fsbridge PROVENANCE.json is the current authoritative byte inventory of the ten
vendored source files. It supersedes stale historical hashes. It records the
T20-B/T62/T64 chain and does not manufacture identities or retroactive permission.
The owner's control of historical contributions/modifications remains to be
confirmed. Collective ACBridge credit is not a claim of third-party ownership.

24 seed records have game names, aliases and community labels removed. Numeric
facts, resource paths and hashes retain citations. This reduces unverified text
redistribution but does not decide game/data/database rights. Residual data
clearance remains a release gate; see catalog-provenance.md.

T66-N adds a separate equipment name index (acbridge/data/name_index.json).
It maps individual FMG item designation strings (model code and/or unit name,
for example SB-033M MORLEY) to numeric facts and archive path citations, with
per-entry evidence selectors and source digests. Descriptive FMG text is never
read; Paramdex community labels are not reintroduced; the 24-record technical
catalog itself is unchanged. The index is regenerable from any legally owned
local extraction via acbridge build-name-index, and locally built copies are
private convenience data. Whether designation-string mapping is distributable
remains an open review item; see docs/name-index.md. This is a candidate, not
a clearance.

For corresponding source, provide the exact matching source tarball beside the
wheel with equivalent access at publication. It contains the preferred Python
source, vendored source, build scripts, dependency declarations, notices and
instructions. No installed compiled ACBridge artifact lacks its source. There
is no invented public hosting URL or promise that a private checkout is public.
Do not publish the wheel alone. See building.md.

Only expanded-resource dynamic export is the first Alpha support scope. Legacy
Game/static source remains for transparency but its bridges/native binaries and
game resources are excluded. Process separation alone is not a general legal
exemption: external components and any future combinations need their own review.

Remaining gates: project ownership/author credit confirmation (especially the
fsbridge historical modifiers), residual seed data rights review, independent
release review, and final owner publication approval. No third-party extra grant
has been obtained or assumed. Unknowns stay unknown. Release Blocked remains.
