# T66 resource catalog provenance

The public candidate uses `acbridge/data/assets.json` catalog version
`T66.1-technical-ids`. This is a bounded catalog of 24 technical resource
records, not a game database or a claim of authorization from a game publisher.

T66 removes all 22 `paramdexName` values and all 17 copied game display-text
values from source records. All 24 required `name_en` values now equal their
technical IDs, and all 86 human search aliases are removed. Character entries
no longer repeat community names in their limitations. Human-name lookup is
therefore intentionally unavailable in this candidate; use a resource ID or
discover the user's expanded resource files. No resource availability or visual
acceptance is inferred from a catalog match.

All 24 record IDs, namespaces, categories, resource paths, sides, assembly
components, numerical parameter values and all 72 source references remain.
Source paths, selectors and SHA256 digests identify the original evidence;
those referenced files are not included. Game-text references remain as
reference-only records with empty `fields`, `content_included: false` and the
original digest. The five community-reference documents likewise remain
citations, with no document contents bundled. The c4210 dummy flag and its
unknown character-name semantics remain explicit.

| Source group | Records | Candidate treatment | Rights status |
| --- | ---: | --- | --- |
| Game parameters previously carrying community labels | 22 | Remove community labels; retain numeric facts, selectors, digests | Residual data/database rights review required |
| Game display text | 17 | Exclude copied text; retain reference and digest only | No game-text redistribution claimed |
| BinderKeys archive index | 22 | Factual path citations and digests only; no index files | JKAnderson/BinderKeys, Apache-2.0; T65 fixed ref `b95a32c5` |
| Game character-model parameters | 5 | Retain numeric IDs and evidence locators | Residual data/database rights review required |
| Community model reference | 5 | Citation and digest only; no community document included | No permission for document redistribution asserted |
| Project assembly convention | 1 | Project technical convention; no claim of an original game ID | Subject to project code/document licensing |

BinderKeys is a separate project by JKAnderson:
[JKAnderson/BinderKeys](https://github.com/JKAnderson/BinderKeys).
T65 verified its Apache-2.0 license at ref `b95a32c5` through Nuxe's submodule
reference. The references here are not a redistributed BinderKeys index or a
relicensing of its contents. The original index digests are retained so that
independent reviewers can distinguish a source citation from a fresh extract.

To reproduce the transformation, provide the original catalog as an explicit
local input. The script never modifies that baseline:

```text
python scripts/catalog_remediate.py --baseline PATH_TO_PRE_T66_ASSETS_JSON --output acbridge/data/assets.json --evidence evidence/catalog-remediation.json
```

The evidence records every entry's retained sources and every source's removed
and retained fields, plus baseline/output SHA256 digests. It deliberately omits
the removed display strings. The script asserts preservation of identifiers,
numeric fields, locators, source digests and referential integrity. Reviewers
must still decide whether the remaining bounded factual selection raises
applicable data/database rights obligations before publication. Removing labels
does not establish a legal clearance and does not authorize game-asset sharing.
