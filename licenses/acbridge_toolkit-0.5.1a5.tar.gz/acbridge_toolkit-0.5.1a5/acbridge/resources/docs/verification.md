# 结果语义

`completion.output_valid`只代表GLB数值/源回读和Validator范围内有效。`status=partial`可表示研究材质/朝向/消费或部分Clip边界；不能把exit0、文件存在、Validator0或覆盖率高当作动态正确。

`verification`分开报告：

|字段|意义|
|---|---|
|geometry.status=source_checks_passed|刚性源位置、权重/拓扑/IBM回读及GLB结构检查通过；没有自动认证视觉接触|
|blender_consumption.status=passed|指定adapter、指定采样策略下实际Blender与CPU误差低于0.1mm|
|dynamic_appearance.status=not_verified|本次外观未实测审查，不自动使用历史组合名替代验收|
|dynamic_appearance.status=known_issue_reference|所选腿部已有相关异常/分支证据；当前组合仍需查看，工具继续尝试|

实际验收记录另区分`geometry_visual=PASS/PARTIAL/FAIL`、`dynamic_visual=PASS/PARTIAL/FAIL/UNKNOWN`。PASS必须带确切四槽、Clip、消费路径、画面及审查范围。不能用一个子指标抹掉另一个失败。

7010：原FK行走已有机械段脱节，次级Jiggler/Cylinder运行时没有复现；9400：直接覆盖率高仍有未知姿态异常；5510：独立坦克骨架/动作分支，默认c0000只是尝试，可显式提供真正skeleton_hkx/clip_spec。本轮不研究这些机制，不据它们拒绝未知输入。

默认Blender与identity-basis分别保留数值结果；默认消费差异若超过阈值，仍保留GLB及failed报告，不放宽阈值或自动切换适配器制造PASS。已有样本的历史默认误差不因R3路径通过而消失。
