# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Detach numerical/native assembly inspection from the stdio protocol host."""
import contextlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from acbridge.lookup import BridgeError
try:
    from acbridge.assembly import check_assembly
    with contextlib.redirect_stdout(sys.stderr):data=check_assembly(**json.loads(sys.argv[1]))
except BridgeError as ex:data=dict(status='error',error=dict(code=ex.code,message=str(ex),**ex.details))
except Exception as ex:data=dict(status='error',error=dict(code='assembly_inspection_failed',message=str(ex)))
print(json.dumps(data,ensure_ascii=False))
