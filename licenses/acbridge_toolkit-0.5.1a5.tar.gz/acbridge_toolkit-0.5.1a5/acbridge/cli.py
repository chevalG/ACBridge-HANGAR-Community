# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
import argparse
import json
import sys
from pathlib import Path
from .lookup import BridgeError, NAMESPACES, lookup_asset
from .operations import capabilities,doctor,export_static,inspect_result

class Parser(argparse.ArgumentParser):
    def error(self,message):raise BridgeError('invalid_arguments',message)

def main(argv=None):
    try:
        if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
        p=Parser(description='ACBridge: source-attributed lookup, static profiles and research-first weighted AC/HKX attempts. All results are JSON.')
        from . import __version__
        p.add_argument('--version',action='version',version=__version__)
        sub=p.add_subparsers(dest='command',required=True)
        q=sub.add_parser('lookup',help='Name/alias ↔ original resource ID; no game installation needed')
        q.add_argument('query');q.add_argument('--namespace',choices=NAMESPACES);q.add_argument('--limit',type=int,default=10)
        ni=sub.add_parser('name-index',help='Equipment name index status: builtin coverage, local overlays, provenance')
        ni.add_argument('--config',help='Used only to locate sibling name_index.local.json overlays.')
        nb=sub.add_parser('build-name-index',help='Build a local name index from your own extracted FMG/PARAM XML; output stays local')
        nb.add_argument('--msg-root',required=True,help='Directory containing 武器名.fmg.xml / 防具名.fmg.xml (extracted item-msgbnd)')
        nb.add_argument('--regulation',required=True,help='Directory containing EquipParamWeapon/EquipParamProtector .param.xml')
        nb.add_argument('--archive-index',help='BinderKeys Data0.txt (or its Nuxe res root) to verify resource stems')
        nb.add_argument('--output',help='Default: name_index.local.json beside --config or in ~/.acbridge/')
        nb.add_argument('--config',help='Resolves the default output location.')
        nb.add_argument('--index-version',default='local')
        c=sub.add_parser('capabilities',help='Discover inputs, reference profiles and actual processing limits; coverage is not permission');c.add_argument('query',nargs='?')
        d=sub.add_parser('doctor',help='Check dependencies for the selected input/workflow');d.add_argument('--config');d.add_argument('--input-mode',choices=['expanded','game'],default='expanded');d.add_argument('--workflow',choices=['dynamic','static'],default='dynamic')
        sub.add_parser('resources',help='Locate installed README, docs, config example and Agent Skill')
        init=sub.add_parser('init',help='Copy installed user docs/config/Skill to a fresh workspace');init.add_argument('output')
        i=sub.add_parser('inspect',help='Inspect generated GLB, Validator and Blender readback evidence');i.add_argument('output');i.add_argument('--config',help='Accepted for command consistency; inspection reads output evidence, not tool configuration.')
        x=sub.add_parser('export-static',help='Run a supported static profile through existing converter')
        x.add_argument('asset');x.add_argument('--output',required=True);x.add_argument('--config');x.add_argument('--timeout',type=int,default=600)
        group=x.add_mutually_exclusive_group(required=True);group.add_argument('--input-root',action='append');group.add_argument('--game-dir')
        dx=sub.add_parser('export-dynamic-frame',help='Try automatic frame, mixed parts or explicit files with original HKX and honest partial results')
        dx.add_argument('asset');dx.add_argument('--output',required=True);dx.add_argument('--config');dx.add_argument('--timeout',type=int,default=600)
        dx.add_argument('--clip',action='append',dest='clips',help='Clip ID or explicit-source label; repeat. Default: spec keys, otherwise walk and jump.');dx.add_argument('--models',help='Explicit models JSON; overrides automatic part selection')
        dx.add_argument('--clip-spec',help='JSON mapping clip labels to hkx path, compendium path/name, archive and descriptive metadata')
        dx.add_argument('--part',action='append',help='Slot=resource stem override; repeat bd/hd/am/lg. For example hd=HD_M_3010.')
        dx.add_argument('--skeleton-hkx',help='Explicit source animation skeleton HKX; otherwise discover c0000')
        dx.add_argument('--skeleton-compendium',help='Optional source skeleton type compendium')
        dx.add_argument('--assembly-method',choices=['geometry','relative','baseline'],default='geometry',help='R1/R2 geometric mounting (default), relative rig only, or T60 comparison path; no registration gate.')
        dx.add_argument('--blender-adapter',choices=['default','identity-basis'],default='default',help='Optional R3 single-import bone-display adaptation; default remains Blender importer behavior.')
        dx.add_argument('--animation-check',choices=['sampled','all-keys'],default='sampled',help='Numerical Blender/GLB comparison: representative keys or every emitted key. Neither is visual PASS.')
        dx.add_argument('--render-preview',action='store_true',help='Save real Blender sample renders using the selected consumer path.')
        dg=dx.add_mutually_exclusive_group();dg.add_argument('--input-root',action='append');dg.add_argument('--game-dir')
        hk=sub.add_parser('decode-hkx',help='Decode one real HKX using the same unmodified T47 decoder')
        hk.add_argument('--clip',required=True);hk.add_argument('--compendium',required=True);hk.add_argument('--skeleton-hkx',required=True);hk.add_argument('--skeleton-compendium');hk.add_argument('--output',required=True);hk.add_argument('--config');hk.add_argument('--timeout',type=int,default=600)
        ds=sub.add_parser('discover-assets',help='Search actual local Nuxe index or expanded files; no static registration required')
        ds.add_argument('query',nargs='?',default='');ds.add_argument('--kind',choices=['part','frame','weapon','archive']);ds.add_argument('--input-root',action='append');ds.add_argument('--game-dir');ds.add_argument('--config');ds.add_argument('--limit',type=int,default=20);ds.add_argument('--offset',type=int,default=0)
        ls=sub.add_parser('list-clips',help='Probe actual HKX contents of one archive, without full spline decoding')
        ls.add_argument('--archive');ls.add_argument('--input-root',action='append');ls.add_argument('--game-dir');ls.add_argument('--output');ls.add_argument('--config');ls.add_argument('--limit',type=int,default=10);ls.add_argument('--offset',type=int,default=0);ls.add_argument('--timeout',type=int,default=600)
        ca=sub.add_parser('check-assembly',help='Inspect real skeleton/weight/reference differences; never required before trying export')
        ca.add_argument('asset');ca.add_argument('--output',required=True);ca.add_argument('--input-root',action='append');ca.add_argument('--game-dir');ca.add_argument('--config');ca.add_argument('--timeout',type=int,default=600);ca.add_argument('--part',action='append')
        for parser in (q,c,d,i,x,dx,hk,ds,ls,ca,ni,nb):parser.add_argument('--detail',choices=['summary','full'],default='summary',help='Concise transport summary (default) or complete evidence')
        sub.add_parser('mcp',help='Run the optional official SDK stdio MCP server')
        a=p.parse_args(argv)
        if a.command=='mcp':
            from .server import run
            run();return 0
        if a.command in ('resources','init'):
            from .resources import resources,initialize
            result=resources() if a.command=='resources' else initialize(a.output)
            print(json.dumps(result,ensure_ascii=False));return 0
        if a.command=='lookup':result=lookup_asset(a.query,a.namespace,a.limit)
        elif a.command=='name-index':
            from .nameindex import name_index_status
            result=name_index_status(a.config)
        elif a.command=='build-name-index':
            from .nameindex import default_local_output,build_local
            result=build_local(a.msg_root,a.regulation,a.archive_index,a.output or default_local_output(a.config),a.config,a.index_version)
        elif a.command=='capabilities':result=capabilities(a.query)
        elif a.command=='doctor':result=doctor(a.config,a.input_mode,a.workflow)
        elif a.command=='inspect':result=inspect_result(a.output)
        elif a.command=='discover-assets':
            from .discovery import discover_assets
            result=discover_assets(a.query,a.kind,a.input_root,a.game_dir,a.config,a.limit,a.offset)
        elif a.command=='list-clips':
            from .discovery import list_clips
            result=list_clips(a.archive,a.input_root,a.game_dir,str(Path(a.output).expanduser().resolve()) if a.output else None,a.config,a.limit,a.offset,a.timeout)
        elif a.command=='check-assembly':
            import contextlib
            from .assembly import check_assembly
            parts={}
            for value in a.part or []:
                if '=' not in value:raise BridgeError('invalid_parts','Use --part slot=RESOURCE_STEM.')
                slot,stem=value.split('=',1)
                if slot in parts:raise BridgeError('invalid_parts','A part slot was specified twice.',slot=slot)
                parts[slot]=stem
            with contextlib.redirect_stdout(sys.stderr):
                result=check_assembly(a.asset,a.output,a.input_root,a.game_dir,a.config,a.timeout,parts)
        elif a.command=='export-dynamic-frame':
            from .dynamic import export_dynamic_frame
            parts={}
            for value in a.part or []:
                if '=' not in value:raise BridgeError('invalid_parts','Use --part slot=RESOURCE_STEM.')
                slot,stem=value.split('=',1)
                if slot in parts:raise BridgeError('invalid_parts','A part slot was specified twice.',slot=slot)
                parts[slot]=stem
            result=export_dynamic_frame(a.asset,a.output,a.input_root,a.game_dir,a.clips,a.models,a.config,a.timeout,a.clip_spec,parts,a.skeleton_hkx,a.skeleton_compendium,a.assembly_method,a.blender_adapter,a.animation_check,a.render_preview)
        elif a.command=='decode-hkx':
            from .dynamic import decode_hkx
            result=decode_hkx(a.clip,a.compendium,a.skeleton_hkx,a.output,a.config,a.timeout,a.skeleton_compendium)
        else:result=export_static(a.asset,a.output,a.input_root,a.game_dir,a.config,a.timeout)
        from .presentation import present
        print(json.dumps(present(result,a.detail),ensure_ascii=False));return 1 if result['status']=='error' else 0
    except BridgeError as ex:
        from .presentation import present
        print(json.dumps(present(dict(schema_version=1,status='error',error=dict(code=ex.code,message=str(ex),**ex.details)),getattr(locals().get('a'),'detail','summary')),ensure_ascii=False));return 2
    except (OSError,ValueError,ImportError) as ex:
        print(json.dumps(dict(schema_version=1,status='error',error=dict(code='environment_error',message=str(ex))),ensure_ascii=False));return 2

if __name__=='__main__':sys.exit(main())
