# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Install the unchanged R1/R2 math on one job-local vendored T47 core."""
from .relative_assembly import assemble_rig
from .geometry_assembly import make_plan,relocate_geometry
from .dynamic_worker import save

def install(core,request,out):
 method=request.get('assembly_method','geometry')
 if method=='baseline':return
 def rig(model):
  result=assemble_rig(core,model,out/'assembly-proof.json')
  if method=='geometry':
   core.GEOMETRY_PLAN=make_plan(core,result[0],core.ASSEMBLY_PROOF)
   core.ASSEMBLY_PROOF['geometry_unchanged']=all(g['identity'] for g in core.GEOMETRY_PLAN['groups'])
   core.ASSEMBLY_PROOF['geometry_coordinate_policy']='R2 measured rigid mounting; shape, weights and topology preserved.'
   for a in core.ASSEMBLY_PROOF['anchors']:a['geometry_transform']=next(g['geometry_transform'] for g in core.GEOMETRY_PLAN['groups'] if g['part']==a['part'] and g['anchor']==a['anchor'])
   save(out/'assembly-proof.json',core.ASSEMBLY_PROOF)
  return result
 core.rig=rig
 if method=='geometry':
  base=core.geometry
  core.geometry=lambda entry,order:relocate_geometry(core,base,entry,order,out)

