# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66-N 2026-10-26: equipment name index generation from user-owned local data.
# Reads only user-provided extracted FMG/PARAM XML; never writes game sources.
"""Build an equipment name index from the user's legally owned local extraction.

The index maps one FMG item designation (for example ``SB-033M MORLEY``) to the
numeric identity chain: PARAM row id -> equipModelId -> resource archive stem
(``wp_r_4110``). Inclusion is mechanical: every FMG-named EquipParamWeapon row
in the hand/shoulder ranges with an equip flag and a nonzero model, and every
FMG-named EquipParamProtector row in the four frame-slot ranges. Descriptive
FMG files (説明) are never read. Output is a standalone JSON file; a built-in
copy ships with the package and locally built copies overlay it at query time.
"""
from .lookup import BridgeError

import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

INDEX_SCHEMA_VERSION = 1

WEAPON_FMG = '武器名.fmg.xml'
PART_FMG = '防具名.fmg.xml'
WEAPON_PARAM = 'EquipParamWeapon.param.xml'
PART_PARAM = 'EquipParamProtector.param.xml'
ARCHIVE_INDEX_DEFAULT = 'BinderKeys/ArmoredCore6_PC/Hash/Data0.txt'

# Row-range conventions verified against the local regulation evidence
# (T66-N scan 2026-10-26): 10/15/20/25 hand (arm) units, 30/35 shoulder units.
WEAPON_RANGES = {
    '10': dict(slot_group='arm', side='right'),
    '15': dict(slot_group='arm', side='left'),
    '20': dict(slot_group='arm', side='left'),
    '25': dict(slot_group='arm', side='left'),
    '30': dict(slot_group='shoulder', side='right'),
    '35': dict(slot_group='shoulder', side='left'),
}
PART_RANGES = {'50': 'HD', '51': 'BD', '52': 'AM', '53': 'LG'}
SHIELD_RANGE_NOTE = (
    'Range-25 rows record only leftBackEquipable=1 while community references '
    'describe AC6 shields as left arm units; flags are kept verbatim and the '
    'slot group follows the row range. No interpretation is forced.'
)
WP_A_NOTE = (
    'No side-specific archive exists for this model in the archive index; the '
    'shared wp_a_ archive is the only candidate and its use is inferred from '
    'archive inventory, not from a direct param reference.'
)

# T67-R N2: content verification (2026-10-26) for models whose shared wp_a and
# side archives coexist. wp_a and side archives are complementary packages, not
# alternatives: geometry, skeleton and textures may be split across them.
# Facts below were verified by extracting and unpacking every listed archive
# from the legal local game copy (see evidence/name-index/shared-archive-verification.json).
CONTENT_VERIFIED = {
    '0221': dict(
        note='Content-verified: wp_l_0221 carries the left-hand model (FLVER, behbnd, Skeleton.hkx); the coexisting wp_a_0221 contains only animation and textures (no FLVER). Left-hand conversion may need wp_a_0221 textures.',
        companion_for_left=['wp_a_0221']),
    '0230': dict(
        note='Content-verified: wp_l_0230 carries the left-hand model (FLVER, behbnd, Skeleton.hkx, embedded tpf); the coexisting wp_a_0230 contains only animation and textures (no FLVER).',
        companion_for_left=[]),
    '0910': dict(
        note='Content-verified: wp_l_0910 carries the left-hand model (FLVER, behbnd, Skeleton.hkx); the coexisting wp_a_0910 contains only animation and textures (no FLVER). Left-hand conversion may need wp_a_0910 textures.',
        companion_for_left=['wp_a_0910']),
    '2720': dict(
        note='Content-verified: no wp_r_2720 exists; wp_a_2720 is the only right-hand candidate and carries the full package (FLVER 474000 B, behbnd, Skeleton.hkx). The left-hand variant has a distinct dedicated mesh wp_l_2720 (FLVER 535168 B, different sha256) without its own Skeleton.hkx/behbnd. Weapon textures ship as standalone wp_2720.tpf.dcx / wp_2720_l.tpf.dcx, not inside these part packages.',
        companion_for_right=[],
        companion_for_left=['wp_a_2720']),
    '3010': dict(
        note='Content-verified: wp_a_3010 carries the full model (FLVER, behbnd, Skeleton.hkx, embedded tpf). wp_l_3010 contains only a texture package (tpf 13981826 B, no FLVER): a left-hand conversion needs wp_a_3010 geometry together with wp_l_3010 textures.',
        companion_for_right=[],
        companion_for_left=['wp_a_3010']),
}


def _content_verification(model, side):
    info = CONTENT_VERIFIED.get(f'{model:04d}')
    if not info:
        return None, None
    companions = info.get('companion_for_' + side) or []
    return info['note'], companions


def _sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _parse_xml(path, what):
    try:
        return ET.parse(path).getroot()
    except (OSError, ET.ParseError) as ex:
        raise BridgeError('name_index_input', f'Cannot read {what}: {ex}', path=str(path)) from ex


def _file_digest(root, name, what):
    path = root / name
    if not path.is_file():
        raise BridgeError('name_index_input', f'{what} not found under the provided root.', expected=name, root=str(root))
    return path, _sha256(path)


def _fmg_texts(root):
    texts = {}
    for el in root.iter('text'):
        tid = el.get('id')
        value = (el.text or '').strip()
        if tid is not None and value:
            texts[tid] = value
    return texts


def _param_rows(root):
    rows = {}
    for el in root.iter('row'):
        rid = el.get('id')
        if rid is not None:
            rows[rid] = el.attrib
    return rows


def _flag(row, key):
    value = row.get(key)
    if value not in ('0', '1'):
        return None
    return value == '1'


def _designation_parts(display_name):
    """Split 'SB-033M MORLEY' into model code and unit name tokens."""
    tokens = display_name.split()
    if not tokens:
        return None, None
    if len(tokens) == 1:
        token = tokens[0]
        return (token, None) if re.search(r'\d', token) else (None, token)
    first = tokens[0]
    if re.search(r'\d', first):
        return first, ' '.join(tokens[1:])
    return None, display_name


def _load_archive_stems(archive_index):
    if not archive_index:
        return None
    path = archive_index / ARCHIVE_INDEX_DEFAULT if archive_index.is_dir() else archive_index
    if not path.is_file():
        raise BridgeError('name_index_input', 'Archive index not found.', path=str(path))
    text = path.read_text(encoding='utf-8', errors='replace')
    return set(re.findall(r'/parts/([a-z0-9_]+)\.partsbnd\.dcx', text)), path


def build_name_index(msg_root, regulation_root, archive_index=None):
    """Build index entries + report from local FMG/PARAM XML roots.

    Returns (index_dict, report_dict). ``msg_root`` is the directory containing
    the FMG XML files (for example an extracted ``item-msgbnd-dcx`` folder);
    ``regulation_root`` contains the extracted PARAM XML files. Both stay
    untouched; only their digests and selectors are recorded.
    """
    msg_root = Path(msg_root)
    regulation_root = Path(regulation_root)
    if not msg_root.is_dir() or not regulation_root.is_dir():
        raise BridgeError('name_index_input', 'msg_root and regulation_root must be existing directories.')

    wfmg_path, wfmg_sha = _file_digest(msg_root, WEAPON_FMG, 'Weapon name FMG')
    pfmg_path, pfmg_sha = _file_digest(msg_root, PART_FMG, 'Part name FMG')
    wpar_path, wpar_sha = _file_digest(regulation_root, WEAPON_PARAM, 'Weapon param XML')
    ppar_path, ppar_sha = _file_digest(regulation_root, PART_PARAM, 'Protector param XML')

    weapon_names = _fmg_texts(_parse_xml(wfmg_path, WEAPON_FMG))
    part_names = _fmg_texts(_parse_xml(pfmg_path, PART_FMG))
    weapon_rows = _param_rows(_parse_xml(wpar_path, WEAPON_PARAM))
    part_rows = _param_rows(_parse_xml(ppar_path, PART_PARAM))

    stems = None
    archive_path = None
    archive_sha = None
    if archive_index is not None:
        stems, archive_path = _load_archive_stems(Path(archive_index))
        archive_sha = _sha256(archive_path)

    language = msg_root.name
    msg_uri_dir = language
    if language == 'item-msgbnd-dcx':
        # Caller passed the extracted binder directory itself; the language
        # folder (for example engus) is its parent.
        language = msg_root.parent.name
        msg_uri_dir = f'{language}/item-msgbnd-dcx'
    sources = {
        f'user-resource://msg/{msg_uri_dir}/{WEAPON_FMG}': dict(
            path=f'user-resource://msg/{msg_uri_dir}/{WEAPON_FMG}',
            kind='game_item_name_designation', sha256=wfmg_sha,
            content_basis='Individual item designation strings only; descriptive FMG files are never read.'),
        f'user-resource://msg/{msg_uri_dir}/{PART_FMG}': dict(
            path=f'user-resource://msg/{msg_uri_dir}/{PART_FMG}',
            kind='game_item_name_designation', sha256=pfmg_sha,
            content_basis='Individual item designation strings only; descriptive FMG files are never read.'),
        f'user-resource://regulation-bin/{WEAPON_PARAM}': dict(
            path=f'user-resource://regulation-bin/{WEAPON_PARAM}', kind='game_param_numeric_facts', sha256=wpar_sha),
        f'user-resource://regulation-bin/{PART_PARAM}': dict(
            path=f'user-resource://regulation-bin/{PART_PARAM}', kind='game_param_numeric_facts', sha256=ppar_sha),
    }
    if archive_path is not None:
        sources['nuxe-resource://BinderKeys/ArmoredCore6_PC/Hash/Data0.txt'] = dict(
            path='nuxe-resource://BinderKeys/ArmoredCore6_PC/Hash/Data0.txt',
            kind='tool_archive_path_index', sha256=archive_sha,
            reference_attribution=dict(project='JKAnderson/BinderKeys', license='Apache-2.0',
                                       upstream='https://github.com/JKAnderson/BinderKeys',
                                       scope='Factual path citation and file digest only; index file not bundled.'))

    entries = []
    excluded_rows = []
    unresolved_stems = []
    wp_a_entries = 0

    for rid in sorted(weapon_rows, key=int):
        name = weapon_names.get(rid)
        row = weapon_rows[rid]
        model = int(row.get('equipModelId') or 0)
        flags = dict(
            rightHand=_flag(row, 'rightHandEquipable'),
            leftHand=_flag(row, 'leftHandEquipable'),
            rightBack=_flag(row, 'rightBackEquipable'),
            leftBack=_flag(row, 'leftBackEquipable'),
        )
        range_info = WEAPON_RANGES.get(rid[:2])
        equippable = any(v for v in flags.values())
        if name is None or model == 0 or not equippable or range_info is None:
            if range_info is not None and (name is not None or equippable):
                reason = 'no_fmg_name' if name is None else ('zero_model' if model == 0 else 'no_equip_flag')
                excluded_rows.append(dict(kind='weapon', row_id=int(rid), reason=reason))
            continue
        side = range_info['side']
        stem_side = 'r' if side == 'right' else 'l'
        stem = None
        stem_basis = None
        for candidate, basis in ((f'wp_{stem_side}_{model:04d}', 'archive_inventory'),
                                 (f'wp_a_{model:04d}', 'archive_inventory_shared')):
            if stems is None or candidate in stems:
                stem = candidate
                stem_basis = basis
                if basis == 'archive_inventory_shared':
                    wp_a_entries += 1
                break
        if stem is None:
            unresolved_stems.append(dict(kind='weapon', row_id=int(rid), name=name, model=model))
            continue
        code, unit = _designation_parts(name)
        entry = dict(
            kind='weapon', display_name=name, row_id=int(rid), model_id=model,
            slot_group=range_info['slot_group'], side=side, equip_flags=flags,
            weapon_bay_compatible=row.get('shoulderEquipType') == '1',
            resource_id=stem.upper(), resource_stem=stem,
            resource_path=f'/parts/{stem}.partsbnd.dcx', resource_basis=stem_basis,
            search_keys=[k for k in (code, unit) if k],
            evidence=[
                f'user-resource://msg/{msg_uri_dir}/{WEAPON_FMG}#text[@id="{rid}"]',
                f'user-resource://regulation-bin/{WEAPON_PARAM}#row[@id="{rid}"]',
                f'nuxe-resource://BinderKeys/ArmoredCore6_PC/Hash/Data0.txt#/parts/{stem}.partsbnd.dcx',
            ],
        )
        if stems is None:
            entry['resource_basis'] = 'param_model_id_unverified'
            entry['evidence'] = entry['evidence'][:2]
        if rid[:2] == '25':
            entry['slot_note'] = SHIELD_RANGE_NOTE
        if stem_basis == 'archive_inventory_shared':
            entry['resource_note'] = WP_A_NOTE
        if stems is not None:
            note, companions = _content_verification(model, side)
            if note:
                entry['content_verification'] = note
                if companions:
                    entry['companion_stems'] = companions
        entries.append(entry)

    for rid in sorted(part_rows, key=int):
        name = part_names.get(rid)
        row = part_rows[rid]
        slot = PART_RANGES.get(rid[:2])
        model = int(row.get('equipModelId') or 0)
        if slot is None:
            continue
        if name is None or model == 0:
            excluded_rows.append(dict(kind='part', row_id=int(rid), slot=slot, reason='no_fmg_name_or_zero_model'))
            continue
        stem = f'{slot.lower()}_m_{model:04d}'
        if stems is not None and stem not in stems:
            unresolved_stems.append(dict(kind='part', row_id=int(rid), name=name, model=model))
            continue
        code, unit = _designation_parts(name)
        entry = dict(
            kind='part', display_name=name, row_id=int(rid), model_id=model,
            slot=slot, equip_flags=dict(head=_flag(row, 'headEquip'), leg=_flag(row, 'legEquip')),
            resource_id=f'{slot}_M_{model:04d}', resource_stem=stem,
            resource_path=f'/parts/{stem}.partsbnd.dcx',
            resource_basis='archive_inventory' if stems is not None else 'param_model_id_unverified',
            search_keys=[k for k in (code, unit) if k],
            evidence=[
                f'user-resource://msg/{msg_uri_dir}/{PART_FMG}#text[@id="{rid}"]',
                f'user-resource://regulation-bin/{PART_PARAM}#row[@id="{rid}"]',
                f'nuxe-resource://BinderKeys/ArmoredCore6_PC/Hash/Data0.txt#/parts/{stem}.partsbnd.dcx',
            ],
        )
        if stems is None:
            entry['evidence'] = entry['evidence'][:2]
        entries.append(entry)

    orphan_fmg = sorted(
        int(t) for t in weapon_names
        if t not in weapon_rows or not WEAPON_RANGES.get(t[:2])
    ) + sorted(
        int(t) for t in part_names
        if t not in part_rows or t[:2] not in PART_RANGES
    )

    weapons = [e for e in entries if e['kind'] == 'weapon']
    parts = [e for e in entries if e['kind'] == 'part']
    distinct_names = {e['display_name'] for e in entries}
    report = dict(
        language=language,
        weapon_rows=len(weapons), part_rows=len(parts),
        distinct_display_names=len(distinct_names),
        wp_a_shared_archive_rows=wp_a_entries,
        excluded_rows=excluded_rows, unresolved_stems=unresolved_stems,
        orphan_fmg_text_ids=orphan_fmg,
        archive_verified=stems is not None,
        input_digests=dict(
            weapon_fmg=wfmg_sha, part_fmg=pfmg_sha,
            weapon_param=wpar_sha, part_param=ppar_sha,
            archive_index=archive_sha),
    )
    index = dict(
        schema_version=INDEX_SCHEMA_VERSION,
        index_kind='ac6_equipment_name_index',
        generated_by='acbridge.nameindex_build',
        language=language,
        entries=entries,
        sources=sources,
        inclusion_rule=(
            'Every FMG-named EquipParamWeapon row in hand ranges 10/15/20/25 or shoulder '
            'ranges 30/35 with at least one equip flag and nonzero equipModelId, and every '
            'FMG-named EquipParamProtector row in frame-slot ranges 50/51/52/53. Descriptive '
            'FMG files are never read. Resource stems require archive-index confirmation '
            'when an archive index is supplied.'),
        rights_notice=(
            'Generated from the user-owned local extraction identified by the digests above. '
            'Each entry maps one item designation string to numeric facts and an archive path '
            'citation. No descriptive game text is included. Redistribution of this file '
            'requires the review described in docs/name-index.md; locally built copies are '
            'private convenience data.'),
    )
    return index, report
