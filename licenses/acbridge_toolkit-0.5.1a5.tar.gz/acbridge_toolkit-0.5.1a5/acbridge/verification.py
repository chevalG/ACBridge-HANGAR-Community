# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Describe evidence without turning coverage or prior observations into gates."""
import json

def known_issues(leg):
 leg=leg.lower();issues=[]
 if leg=='lg_m_7010':issues.append(dict(code='SECONDARY_MECHANICAL_DRIVE_UNREPRODUCED',evidence='T61-R4/R5/R7/R8',observation='Walking native7010 and8020+7010leg showed mechanical segment/contact anomalies. Jiggler/Cylinder runtime not reproduced. This output remains free to inspect.',scope='Prior leg-specific observation; current combination is not visually certified.'))
 if leg=='lg_m_9400':issues.append(dict(code='UNEXPLAINED_DYNAMIC_POSTURE',evidence='T61-R4/R5',observation='Prior walking output has unexplained leg posture anomaly despite high direct track coverage.',scope='Prior leg-specific observation; no coverage-based rejection.'))
 if leg=='lg_m_5510':issues.append(dict(code='SEPARATE_TANK_ANIMATION_BRANCH',evidence='T61-R6 input research; no new solver',observation='Tank branch uses separate animation/skeleton resources. Default c0000 pairing is an attempt, not proof of applicability; explicit skeleton_hkx/clip_spec remain available.',scope='Branch warning; export is not blocked.'))
 return issues

def assessment(out,entry,readback,validations,failures=()):
 issues=known_issues(entry['parts']['lg']['part_id'])
 request=json.loads((out/'request.json').read_text(encoding='utf-8'))
 consumer={}
 p=out/'blender-readback.json'
 if p.exists():consumer=json.loads(p.read_text(encoding='utf-8'))
 consumer_failures=[f for f in failures if f.get('category')=='consumer_validation']
 glbs={name for name in ('asset.glb','asset-ue.glb') if (out/name).is_file()}
 geometry=bool(readback and readback.get('status')=='passed') and bool(glbs) and glbs==set(validations) and all(v['errors']==0 for v in validations.values())
 return dict(geometry=dict(status='source_checks_passed' if geometry else 'not_validated',scope='Source rigid transforms, shape/weight/topology/IBM readback and GLB validation; not a visual contact certificate.'),blender_consumption=dict(status=consumer.get('status','failed' if consumer_failures else 'not_run'),adapter=consumer.get('adapter',request.get('blender_adapter','default')),policy=consumer.get('sample_policy',request.get('animation_check','sampled')),tolerance_m=.0001,max_error_m=consumer.get('max_error_m'),failures=consumer_failures,scope='Numerical equivalence only; default Blender and identity-basis are separate paths.'),dynamic_appearance=dict(status='known_issue_reference' if issues else 'not_verified',current_output_visually_reviewed=False,issues=issues,scope='No automatic dynamic PASS. See acceptance records for explicitly reviewed exact combinations/clips/consumer paths.'),assembly_method=request.get('assembly_method','geometry'),document='docs/verification.md')
