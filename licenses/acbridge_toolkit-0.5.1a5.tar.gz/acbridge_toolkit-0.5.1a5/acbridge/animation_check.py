# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""R3 CPU oracle preparation: source vertex order/weights, no nearest matching."""
import json
import numpy as np
from .dynamic_readback import read,acc,worlds

def prepare(out,policy='sampled'):
 g,b=read(out/'asset-ue.glb');skin=g['skins'][0];ps=g['meshes'][0]['primitives'];a=ps[0]['attributes'];v=acc(g,b,a['POSITION']);j=acc(g,b,a['JOINTS_0']);w=acc(g,b,a['WEIGHTS_0']);ib=acc(g,b,skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);vi=np.concatenate([np.unique(acc(g,b,p['indices'])) for p in ps]).astype(int);v4=np.c_[v,np.ones(len(v))];arrays={};samples=[]
 for anim in g.get('animations',[]):
  W=worlds(g,b,anim);times=acc(g,b,anim['samplers'][0]['input']).ravel();indices=range(len(W)) if policy=='all-keys' else sorted({0,len(W)//3,2*len(W)//3,len(W)-1})
  for key in indices:
   M=W[key,skin['joints']]@ib;P=sum(w[:,k,None]*np.einsum('nij,nj->ni',M[j[:,k],:3],v4) for k in range(4));name='sample'+str(len(samples));arrays[name]=P[vi][:,[0,2,1]]*[1,-1,1];samples.append(dict(key=name,animation=anim['name'],seconds=float(times[key]),source_key=key))
 arrays.update(source_vertex_indices=vi,joints=j[vi],weights=w[vi],bone_names=np.array([g['nodes'][i]['name'] for i in skin['joints']]))
 np.savez_compressed(out/'animation-expected.npz',**arrays)
 (out/'animation-samples.json').write_text(json.dumps(dict(policy=policy,joint_count=len(skin['joints']),samples=samples,scope='CPU/Blender consumption equivalence, not original-game mechanical articulation'),indent=2),encoding='utf-8')

def preview_media(out):
 p=out/'preview-manifest.json'
 if not p.exists():return
 report=json.loads(p.read_text(encoding='utf-8'));policy=json.loads((out/'animation-samples.json').read_text(encoding='utf-8'))['policy'];movies=[]
 if not report.get('images'):return
 from PIL import Image
 for name in sorted({r['animation'] for r in report['images']}):
  rows=sorted([r for r in report['images'] if r['animation']==name and r['view']=='oblique'],key=lambda r:r['seconds'])
  if not rows:continue
  source=rows[:-1] if len(rows)>1 else rows;images=[Image.open(r['path']).convert('RGB') for r in source];times=[round(r['seconds']*100) for r in rows];durations=[max(10,(b-a)*10) for a,b in zip(times,times[1:])] or [100];target=out/'preview'/(name+'.gif');images[0].save(target,save_all=True,append_images=images[1:],duration=durations,loop=0,optimize=False)
  declared=json.loads((out/'animation-samples.json').read_text(encoding='utf-8'));expected_rows=sum(s['animation']==name for s in declared['samples']);effective=policy if len(rows)==expected_rows else 'sampled-render-set'
  movies.append(dict(animation=name,path=str(target),policy=effective,frames=len(images),display_duration_ms=sum(durations),source_times_seconds=[r['seconds'] for r in source],scope='Actual Blender renders at every emitted key interval' if effective=='all-keys' else 'Sparse actual sample renders; not continuous video',endpoint_png=rows[-1]['path']))
 report['animations']=movies;p.write_text(json.dumps(report,indent=2),encoding='utf-8')

