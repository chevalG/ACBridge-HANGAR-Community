# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""On-demand discovery from the existing Nuxe index and real expanded HKX files.

No name database or animation decoder is maintained here. The vendored TagFile
reader inspects declared metadata; spline keys are not decoded by list_clips.
"""
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from types import SimpleNamespace
import uuid

from .lookup import BridgeError, normalize
from .operations import digest, load_config, under

PACKAGE = Path(__file__).resolve().parent
PART = re.compile(r'^(hd|bd|am|lg)_([a-z])_(\d+)$', re.I)
WEAPON = re.compile(r'^wp_[a-z]_\d+$', re.I)
KINDS = ('part', 'frame', 'weapon', 'archive')


def _page(limit, offset):
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
        raise BridgeError('invalid_limit', 'limit must be an integer in 1..500.')
    if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
        raise BridgeError('invalid_offset', 'offset must be a nonnegative integer.')


def _roots(input_roots):
    roots = [Path(p).expanduser().resolve() for p in input_roots or []]
    for p in roots:
        if not p.is_dir():
            raise BridgeError('input_missing', 'Expanded input directory does not exist.', path=str(p))
    return roots


def _game_module(bridge=None):
    """Reuse the existing extraction frontend without copying its algorithms."""
    name = '_acbridge_discovery_game_input'
    if bridge is not None or name not in sys.modules:
        source = PACKAGE / 'vendor/fsbridge/src'
        sys.path.insert(0, str(source))
        try:
            spec = importlib.util.spec_from_file_location(name, source / 'game_input.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if bridge is None:
                sys.modules[name] = module
            else:
                # GameInput obtains its executable via its module's os.environ.
                # A per-job module namespace reuses that code unchanged while
                # keeping MCP process environment untouched during extraction.
                module.os = SimpleNamespace(environ=dict(os.environ, ACBRIDGE_NUXE_BRIDGE=bridge))
                return module
        finally:
            sys.path.remove(str(source))
    return sys.modules[name]


def _catalog(c):
    if not c or not c.get('nuxe_res'):
        raise BridgeError('index_required', 'Provide config with nuxe_res, or expanded input_roots.')
    try:
        return _game_module().load_catalog(Path(c['nuxe_res']))
    except (OSError, ValueError) as ex:
        raise BridgeError('index_unavailable', str(ex), nuxe_res=c['nuxe_res']) from ex


def _resource_stem(path):
    name = Path(path).name.lower()
    for suffix in ('.partsbnd.dcx', '.anibnd.dcx', '.flver', '.hkx'):
        if name.endswith(suffix):
            return name[:-len(suffix)]
    return None


def discover_assets(query='', kind=None, input_roots=None, game_dir=None,
                    config=None, limit=50, offset=0):
    """Find indexed containers and/or actual expanded parts; no coverage gate.

    An index hit is explicitly not proof that the corresponding file parses.
    frame_NUMBER entries are project assembly conventions, never original IDs.
    """
    _page(limit, offset)
    if not isinstance(query, str) or len(query) > 200:
        raise BridgeError('invalid_query', 'query must be a string of at most 200 characters.')
    if kind is not None and kind not in KINDS:
        raise BridgeError('invalid_kind', 'Choose part, frame, weapon or archive.')
    roots = _roots(input_roots)
    config = config or os.environ.get('ACBRIDGE_CONFIG')
    c = load_config(config) if config else None
    game = Path(game_dir).expanduser().resolve() if game_dir else None
    if game and not game.is_dir():
        raise BridgeError('input_missing', 'Game directory does not exist.', path=str(game))
    if not roots and not (c and c.get('nuxe_res')):
        raise BridgeError('input_required', 'Provide expanded input_roots or config containing the existing Nuxe index.')
    found = {}

    def add(stem, category, source):
        key = (category, stem)
        if key not in found:
            found[key] = dict(id=stem if category == 'archive' else stem.upper(),
                              kind=category, namespace='archive' if category == 'archive' else
                              'weapon' if category == 'weapon' else 'ac_part',
                              is_game_id=True, name='UNKNOWN', sources=[])
        found[key]['sources'].append(source)

    if not roots and c and c.get('nuxe_res'):
        for path, binder in sorted(_catalog(c).items()):
            stem = _resource_stem(path)
            category = 'archive' if path.endswith('.anibnd.dcx') else 'part' if stem and PART.fullmatch(stem) else 'weapon' if stem and WEAPON.fullmatch(stem) else None
            if not category or (category in ('part', 'weapon') and not path.endswith('.partsbnd.dcx')):
                continue
            source = dict(type='nuxe_index', resource=path, binder=binder,
                          index_root=c['nuxe_res'], availability='indexed_only', content_parsed=False)
            if game:
                present = all((game / (binder + suffix)).is_file() for suffix in ('.bhd', '.bdt'))
                source.update(game=str(game), binder_pair_present=present,
                              availability='container_pair_present' if present else 'container_pair_missing')
            add(stem, category, source)
    for root in roots:
        for p in sorted(root.rglob('*')):
            if not p.is_file():
                continue
            stem = _resource_stem(p.name)
            category = 'archive' if p.name.lower().endswith('.anibnd.dcx') else 'part' if stem and PART.fullmatch(stem) else 'weapon' if stem and WEAPON.fullmatch(stem) else None
            if category:
                add(stem, category, dict(type='local_file', path=str(p.resolve()),
                    availability='file_present', content_parsed=False))
    families = {}
    for (category, stem), row in list(found.items()):
        match = PART.fullmatch(stem) if category == 'part' else None
        if match and match.group(2).lower() == 'm':
            families.setdefault(match.group(3), {})[match.group(1).lower()] = row
    for ident, slots in families.items():
        # Incomplete sets remain discoverable; their missing slots are evidence.
        found[('frame', 'frame_' + ident)] = dict(id='frame_' + ident, kind='frame',
            namespace='assembled_frame', is_game_id=False, name='UNKNOWN',
            convention='Project same-number HD/BD/AM/LG_M assembly convenience; compatibility is not implied.',
            components={slot: slot.upper() + '_M_' + ident for slot in ('hd', 'bd', 'am', 'lg')},
            available_slots=sorted(slots), missing_slots=sorted(set(('hd', 'bd', 'am', 'lg')) - set(slots)),
            sources=[s for row in slots.values() for s in row['sources']],
            operations=['export_dynamic_frame'], compatibility='uninspected')
    q = normalize(query)
    rows = [r for r in found.values() if (kind is None or r['kind'] == kind) and
            (not q or q in normalize(r['id']) or any(q in normalize(s.get('resource', s.get('path', ''))) for s in r['sources']))]
    rows.sort(key=lambda r: (r['kind'], r['id']))
    return dict(schema_version=1, operation='discover_assets', status='ready', query=query,
                total=len(rows), offset=offset, limit=limit, truncated=offset + limit < len(rows),
                results=rows[offset:offset + limit],
                evidence='Nuxe text index and/or actual local filenames; availability is not successful parsing or assembly.',
                next_offset=offset + limit if offset + limit < len(rows) else None)


def _output(output, c, protected):
    if output is None:
        base = Path(c['output_root']) if c else Path(tempfile.gettempdir()) / 'acbridge-discovery'
        out = (base / ('list-clips-' + uuid.uuid4().hex[:12])).resolve()
    else:
        p = Path(output).expanduser()
        out = ((Path(c['_config']).parent / p) if c and not p.is_absolute() else p).resolve()
    if c:
        allowed = Path(c['output_root'])
        if out == allowed or not under(out, allowed):
            raise BridgeError('output_outside_root', 'Choose a fresh child of configured output_root.', output=str(out), output_root=str(allowed))
    for p in [PACKAGE, *protected]:
        if under(out, p) or under(p, out):
            raise BridgeError('path_overlap', 'Output overlaps a source/input path.', output=str(out), input=str(p))
    if out.exists():
        raise BridgeError('output_exists', 'Existing discovery jobs are never overwritten.', output=str(out))
    out.mkdir(parents=True)
    (out / 'logs').mkdir()
    return out


def _save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _animation_rows(path, compendiums, tagfile):
    failures = []
    root = None
    chosen = None
    for comp in compendiums or [None]:
        try:
            root = tagfile(str(path), types_from=str(comp) if comp else None).root_object()
            chosen = comp
            break
        except Exception as ex:
            failures.append(dict(compendium=str(comp) if comp else None, error_type=type(ex).__name__, message=str(ex)))
    if root is None:
        return [dict(clip_id=path.stem, filename=path.name, path=str(path), status='error', semantic='UNKNOWN',
                     error=dict(code='hkx_metadata_parse_failed', message='TagFile could not read this HKX with available adjacent type compendiums.', attempts=failures))]
    if 'namedVariants' in root:
        variants = root['namedVariants']
        container = next((v['variant'] for v in variants if isinstance(v.get('variant'), dict) and 'animations' in v['variant']), None)
    else:
        container = root if 'animations' in root else None
    if container is None or not container.get('animations'):
        return []
    rows = []
    for index, a in enumerate(container['animations']):
        frames = a.get('numFrames')
        duration = a.get('duration')
        fd = a.get('frameDuration')
        motion = a.get('extractedMotion')
        samples = motion.get('referenceFrameSamples', []) if isinstance(motion, dict) else []
        bindings = container.get('bindings', [])
        binding = bindings[index] if index < len(bindings) else {}
        row = dict(clip_id=path.stem, filename=path.name, animation_index=index, path=str(path),
            bytes=path.stat().st_size, sha256=digest(path), status='ready', semantic='UNKNOWN',
            animation_type=a.get('__type__', 'UNKNOWN'), frames=frames, duration_seconds=duration,
            frame_duration_seconds=fd, transform_tracks=a.get('numberOfTransformTracks'),
            float_tracks=a.get('numberOfFloatTracks'), annotation_tracks=len(a.get('annotationTracks', [])),
            original_skeleton=binding.get('originalSkeletonName', 'UNKNOWN'),
            binding_track_count=len(binding.get('transformTrackToBoneIndices', [])),
            native_sample_fps=(frames - 1) / duration if frames is not None and duration and frames > 1 else None,
            declared_sample_fps=1 / fd if fd else None,
            time_basis='numFrames samples include both endpoints; intervals = numFrames - 1. Preview/export FPS is separate.',
            compendium=str(chosen) if chosen else None,
            compendium_sha256=digest(chosen) if chosen else None,
            compendium_candidates=[str(p) for p in compendiums],
            compendium_association='Adjacent/ancestor candidates tried with the existing TagFile reader; first parseable type table recorded.',
            extracted_motion=dict(present=motion is not None, type=motion.get('__type__') if isinstance(motion, dict) else None,
                samples=len(samples), first_sample=samples[0] if samples else None, last_sample=samples[-1] if samples else None,
                max_translation_from_first_source_units=max((math.sqrt(sum((v[i] - samples[0][i]) ** 2 for i in range(3))) for v in samples), default=0) if samples else None),
            metadata_only=True)
        if failures:
            row['compendium_attempt_failures'] = failures
        rows.append(row)
    return rows


def list_clips(archive=None, input_roots=None, game_dir=None, output=None,
               config=None, limit=50, offset=0, timeout=600):
    """Inspect one indexed/packed bank, or HKX files in expanded roots.

    The complete report is retained at result_json. Returned clip rows paginate;
    failed metadata parses remain visible. Original sources are never unpacked
    in place. No animation semantic names are guessed.
    """
    _page(limit, offset)
    if isinstance(timeout, bool) or not isinstance(timeout, int) or not 10 <= timeout <= 3600:
        raise BridgeError('invalid_timeout', 'timeout must be 10..3600 seconds per external stage.')
    if game_dir and input_roots:
        raise BridgeError('input_required', 'Provide Game OR expanded input_roots.')
    if archive is not None and (not isinstance(archive, str) or not archive):
        raise BridgeError('invalid_archive', 'archive must be a nonempty indexed path, archive filename, or local path.')
    roots = _roots(input_roots)
    config = config or os.environ.get('ACBRIDGE_CONFIG')
    c = load_config(config) if config else None
    game_path = Path(game_dir).expanduser().resolve() if game_dir else None
    if game_path and not game_path.is_dir():
        raise BridgeError('input_missing', 'Game directory does not exist.', path=str(game_path))
    local_archive = Path(archive).expanduser().resolve() if archive and Path(archive).is_file() else None
    if game_path and local_archive:
        raise BridgeError('ambiguous_input', 'Use Game plus indexed archive, or a local archive without Game.')
    if not game_path and not local_archive and not roots:
        raise BridgeError('input_required', 'Provide Game plus archive, a packed archive path, or expanded input_roots.')
    if game_path and not archive:
        raise BridgeError('archive_required', 'Select one archive from discover-assets --kind archive; full-game extraction is not required.')
    if (game_path or local_archive) and not c:
        raise BridgeError('config_required', 'Packed/Game input requires configured Nuxe/Witchy runtime.')
    catalog = _catalog(c) if game_path else None
    selected = None
    if catalog is not None:
        a = archive.replace(chr(92), '/').lower()
        matches = [p for p in catalog if p.endswith('.anibnd.dcx') and (p == a or Path(p).name == a or _resource_stem(p) == a)]
        if len(matches) != 1:
            raise BridgeError('archive_not_found' if not matches else 'ambiguous_archive',
                'Choose one exact indexed ANIBND path from discover-assets.', archive=archive, candidates=matches)
        selected = matches[0]
    protected = roots + ([game_path] if game_path else []) + ([local_archive.parent] if local_archive else [])
    if c:
        protected += [Path(c[k]) if Path(c[k]).is_dir() else Path(c[k]).parent for k in ('witchy', 'nuxe_res', 'nuxe_bridge') if c.get(k)]
    out = _output(output, c, protected)
    report = dict(schema_version=1, operation='list_clips', output=str(out), result_json=str(out / 'result.json'),
                  archive=selected or archive, input_roots=[str(p) for p in roots],
                  method='Existing TagFile metadata scan; no spline-key decoding and no inferred action semantics.', clips=[])
    game = None
    try:
        from .dynamic_worker import Job, TagFile
        request = dict(operation='list_clips', output=str(out), timeout=timeout, config=c or {})
        _save(out / 'request.json', request | dict(archive=selected or archive, input_roots=[str(p) for p in roots], game_dir=str(game_path) if game_path else None))
        job = Job(request)
        if game_path:
            missing = [k for k in ('nuxe_bridge', 'nuxe_res', 'witchy') if not Path(c.get(k, '__missing__')).exists()]
            if missing:
                raise BridgeError('extraction_runtime_missing', 'Game bank discovery requires existing Nuxe/Witchy tools.', missing=missing)
            class DiscoveryInput(_game_module(c['nuxe_bridge']).GameInput):
                def unpack(self, path, tag):
                    job.unpack(path, tag)
            game = DiscoveryInput(job, SimpleNamespace(game_dir=str(game_path), nuxe_res=c['nuxe_res'], witchy=c['witchy']), SimpleNamespace(digest=digest, write_json=_save))
            game.preflight()
            game.extract([selected], 'clip-bank')
            bank = game.root / selected.lstrip('/')
            job.unpack(bank, 'clip-bank')
            roots = [game.root]
            report['extraction_manifest'] = str(out / 'extraction.json')
            report['archive_sha256'] = digest(bank)
        elif local_archive:
            if not Path(c.get('witchy', '__missing__')).is_file():
                raise BridgeError('extraction_runtime_missing', 'Packed archive discovery requires configured Witchy.')
            if not local_archive.name.lower().endswith(('.anibnd.dcx', '.anibnd')):
                raise BridgeError('invalid_archive', 'A packed local input must be an ANIBND archive.', archive=str(local_archive))
            stage = out / 'cache/source'
            stage.mkdir(parents=True)
            before = digest(local_archive)
            bank = stage / local_archive.name
            shutil.copy2(local_archive, bank)
            job.unpack(bank, 'clip-bank')
            if digest(local_archive) != before:
                raise BridgeError('source_changed', 'Original packed source changed during the scan.', archive=str(local_archive))
            report['archive_sha256'] = before
            report['source_readonly_check'] = True
            roots = [stage]
        files = sorted(set(p.resolve() for root in roots for p in root.rglob('*.hkx')))
        # Path.rglob is case-sensitive on POSIX, so include uppercase extensions too.
        files = sorted(set(files) | {p.resolve() for root in roots for p in root.rglob('*') if p.is_file() and p.suffix.lower() == '.hkx'})
        if archive and not game_path and not local_archive:
            token = Path(archive.replace(chr(92), '/')).name.lower()
            stem = token.removesuffix('.dcx').removesuffix('.anibnd')
            files = [p for p in files if any(part.lower() == token or part.lower() == stem or part.lower().startswith(stem + '-') for part in p.parts[:-1])]
        skipped = []
        for path in files:
            comps = sorted(p for p in path.parent.iterdir() if p.is_file() and p.suffix.lower() == '.compendium')
            if not comps:
                for parent in path.parents:
                    if parent not in roots and not any(under(parent, root) for root in roots):
                        break
                    comps = sorted(parent.glob('*.compendium'))
                    if comps:
                        break
            try:
                rows = _animation_rows(path, comps, TagFile)
            except Exception as ex:
                rows = [dict(clip_id=path.stem, filename=path.name, path=str(path), status='error', semantic='UNKNOWN',
                    error=dict(code='hkx_metadata_invalid', message=str(ex), error_type=type(ex).__name__))]
            if not rows:
                skipped.append(dict(path=str(path), reason='Parsed HKX has no animations (for example, Skeleton.hkx).'))
            for row in rows:
                row['archive'] = selected or archive
                row['source_container'] = str(path.parent)
                row['archive_association'] = 'Exact requested bank' if selected or archive else 'Expanded source container; original archive identity not asserted.'
            report['clips'].extend(rows)
        if not files:
            raise BridgeError('archive_contents_missing', 'No expanded HKX files matched the requested bank; inspect unpack logs or supply the correct expanded root.', archive=archive)
        report.update(status='partial' if any(r['status'] == 'error' for r in report['clips']) else 'ready',
                      total=len(report['clips']), hkx_files=len(files), non_animation_hkx=skipped,
                      metadata_errors=sum(r['status'] == 'error' for r in report['clips']), warnings=job.warnings)
        if game:
            game.readonly_check()
            report['source_readonly_check'] = True
        _save(out / 'result.json', report)
        _save(out / 'status.json', dict(schema_version=1, operation='list_clips', status=report['status']))
        result = {k: v for k, v in report.items() if k != 'clips'}
        result.update(clips=report['clips'][offset:offset + limit], limit=limit, offset=offset,
                      truncated=offset + limit < report['total'], next_offset=offset + limit if offset + limit < report['total'] else None)
        return result
    except Exception as ex:
        code = getattr(ex, 'code', 'discovery_failed')
        if game and hasattr(game, 'before'):
            try:
                game.readonly_check()
                report['source_readonly_check'] = True
            except Exception as check:
                report['source_readonly_check'] = False
                report['source_check_error'] = str(check)
        report.update(status='error', error=dict(code=code, message=str(ex), details=getattr(ex, 'details', {})))
        _save(out / 'result.json', report)
        _save(out / 'status.json', dict(operation='list_clips', status='error', error=report['error']))
        raise BridgeError(code, str(ex), output=str(out), result_json=str(out / 'result.json'), details=getattr(ex, 'details', {})) from ex
