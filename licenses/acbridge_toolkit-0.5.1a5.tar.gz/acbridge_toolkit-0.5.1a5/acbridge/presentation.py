# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Bounded transport presentation; complete evidence remains in job files."""
from copy import deepcopy
from pathlib import Path
from .lookup import BridgeError
from .operations import load_config

def config_path(value,config=None):
    if value is None:return None
    p=Path(value).expanduser()
    if p.is_absolute():return str(p.resolve())
    return str((Path(load_config(config)['_config']).parent/p).resolve())

def present(data,detail='summary'):
    if detail not in ('summary','full'):raise BridgeError('invalid_detail','detail must be summary or full.')
    if detail=='full':return data
    r=deepcopy(data)
    def trim_error(e):
        if not isinstance(e,dict):return e
        e.pop('consumer_log_tail',None);e.pop('process_output_tail',None);e.pop('outputs',None)
        for key in ('conflicts','missing_bones','available_skeletons'):
            if isinstance(e.get(key),list) and len(e[key])>5:
                e[key+'_count']=len(e[key]);e[key]=e[key][:5];e['details_truncated']=True
        if isinstance(e.get('details'),dict):trim_error(e['details'])
        return e
    if 'error' in r:r['error']=trim_error(r['error'])
    if 'failures' in r:r['failures']=[trim_error(e) for e in r['failures']]
    if r.get('operation')=='list_clips':
        fields={'clip_id','filename','archive','status','semantic','frames','duration_seconds','frame_duration_seconds','transform_tracks','binding_track_count','native_sample_fps','compendium','error','extracted_motion'}
        r['clips']=[{k:v for k,v in row.items() if k in fields} for row in r.get('clips',[])]
        for row in r['clips']:
            if 'error' in row:row['error']=trim_error(row['error'])
            if isinstance(row.get('extracted_motion'),dict):row['extracted_motion']={k:v for k,v in row['extracted_motion'].items() if k in ('present','samples','max_translation_from_first_source_units')}
        if 'non_animation_hkx' in r:r['non_animation_hkx_count']=len(r.pop('non_animation_hkx'))
    if r.get('operation')=='discover_assets':
        for row in r.get('results',[]):
            for s in row.get('sources',[]):s.pop('index_root',None)
    if r.get('operation') in ('export_static','export_dynamic_frame'):
        r.pop('source_verification',None)
        r['outputs']={k:v for k,v in r.get('outputs',{}).items() if k in ('asset.glb','asset-ue.glb','asset.blend','sources.json','root-analysis.json','verification.json','blender-readback.json','preview-manifest.json','assembly-proof.json','geometry-proof.json')}
        if isinstance(r.get('warnings'),list):
            r['warnings']=[{k:v for k,v in w.items() if k not in ('path','argv')} if isinstance(w,dict) else w for w in r['warnings']]
        r['animations']=[{k:v for k,v in row.items() if k in ('clip','label','frames','duration','fps','modes','root_motion')} for row in r.get('animations',[])]
    for key in ('inspection','readback','conventions','dynamic_input_contract'):
        if key in r and r.get('operation') in ('export_static','export_dynamic_frame'):r.pop(key)
    if 'validation' in r:
        for v in r['validation'].values():
            if isinstance(v,dict) and 'messages' in v:
                msgs=v.pop('messages');v['message_codes']=list(dict.fromkeys(m.get('code','UNKNOWN') for m in msgs))
    for row in r.get('animations',[]):
        root=row.get('root_motion')
        if root and 'actual_varying_translation_tracks' in root:
            root['varying_translation_track_count']=len(root.pop('actual_varying_translation_tracks'))
        if root and 'world_measurements' in root:
            root['world_measurements']={mode:dict(native_sample_fps=v['native_key_intervals_per_second'],bd_root_world_max_horizontal_displacement_m=v['world_nodes'].get('BD_Root',{}).get('max_horizontal_displacement_m'),skinned_centroid_net_displacement_m=(v['skinned_world'].get('centroid') or {}).get('net_displacement_m'),skinned_centroid_max_displacement_m=(v['skinned_world'].get('centroid') or {}).get('max_displacement_m')) for mode,v in root['world_measurements'].items()}
        if root:
            row['root_motion']={k:v for k,v in root.items() if k in ('extracted_motion_present','representation_complete','rootmotion_joint_max_displacement','varying_translation_track_count','world_measurements','inplace_semantics','source','downstream_limit')}
    if r.get('operation')=='check_assembly':
        for row in r.get('parts',{}).values():
            row['weighted_bone_count']=len(row.pop('weighted_bones',{}))
        for row in r.get('comparisons',[]):
            rows=row.pop('differences',[]);row['difference_count']=len(rows);row['difference_examples']=rows[:3]
    if r.get('output'):
        p=Path(r['output']);r['full_report']=str(p/('assembly.json' if r.get('operation')=='check_assembly' else 'result.json'))
        r['detail']='summary; read full_report or request detail=full for complete evidence'
    return r
