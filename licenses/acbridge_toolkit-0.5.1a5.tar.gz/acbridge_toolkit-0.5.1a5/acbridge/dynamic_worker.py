# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""One isolated job. Parsing/retarget algorithms live in the vendored T47 code."""
import importlib.util,json,os,shutil,subprocess,sys,traceback
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
if not __package__:sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from acbridge.lookup import BridgeError
from acbridge.operations import digest,under
from acbridge.workflows import workflows

PACKAGE=Path(__file__).parent
VENDOR=PACKAGE/'vendor/t47'
sys.path[:0]=[str(VENDOR/'scripts'),str(VENDOR/'vendor')]
from tag0c import TagFile

def save(path,data):Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m

class Job:
    def __init__(self,request):
        self.request=request;self.out=Path(request['output']);self.timeout=request['timeout'];self.stage='preflight';self.warnings=[]
        self.args=SimpleNamespace(timeout=self.timeout)
    def mark(self,stage):
        self.stage=stage;save(self.out/'status.json',dict(schema_version=1,status='running',operation=self.request['operation'],stage=stage))
        print(stage,flush=True)
    def command(self,args,log):
        with (self.out/'logs'/log).open('w',encoding='utf-8') as f:
            f.write(json.dumps([str(a) for a in args])+'\n');f.flush()
            try:p=subprocess.run(list(map(str,args)),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=self.timeout,env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1'))
            except subprocess.TimeoutExpired as ex:raise BridgeError('stage_timeout','External stage timed out.',log=log) from ex
        if p.returncode:raise BridgeError('stage_failed','External process failed; parser/process details are retained below.',exit_code=p.returncode,log=log,process_output_tail=(self.out/'logs'/log).read_text(encoding='utf-8',errors='replace')[-2400:])
    def unpack(self,path,tag):
        args=[self.request['config']['witchy'],'--passive','--unpack','--recursive',str(path)]
        log=self.out/'logs'/('witchy-'+tag+'.json')
        if os.name=='nt':
            # PromptPlus needs a real console. Never redirect its output/protocol stdin.
            si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
            p=subprocess.Popen(args,creationflags=subprocess.CREATE_NEW_CONSOLE,startupinfo=si)
            try:code=p.wait(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,stdin=subprocess.DEVNULL);p.wait();raise BridgeError('unpack_timeout','Witchy timed out.',path=str(path))
        else:
            code=subprocess.run(args,stdin=subprocess.DEVNULL,timeout=self.timeout).returncode
        save(log,dict(argv=args,exit_code=code,console='hidden native console; no redirected PromptPlus output'))
        if code not in (0,-1,4294967295):raise BridgeError('unpack_failed','Witchy failed.',exit_code=code,path=str(path),log=str(log))
        if code:self.warnings.append(dict(code='WITCHY_RECURSIVE_NONZERO',exit_code=code,path=str(path),impact='Proceed only if every required resource is present and parses successfully.'))

def skeleton_json(source,target,compendium=None):
    r=TagFile(str(source),types_from=str(compendium) if compendium else None).root_object()
    if 'namedVariants' in r:r=r['namedVariants'][0]['variant']
    sk=r['skeletons'][0]
    data=dict(name=sk.get('name','c0000'),bones=[b['name'] for b in sk['bones']],parentIndices=[int(i) for i in sk['parentIndices']],referencePose=[dict(translation=v['translation'],rotation=v['rotation'],scale=v['scale']) for v in sk['referencePose']])
    if not data['bones'] or len(set(data['bones']))!=len(data['bones']) or len(data['bones'])!=len(data['parentIndices']) or len(data['bones'])!=len(data['referencePose']):raise BridgeError('invalid_source_skeleton','Skeleton names, parents and reference pose are inconsistent.')
    save(target,data);return data

def decode(job,clip,comp,skeleton_cache,directory):
    directory.mkdir(exist_ok=True,parents=True);prefix=directory/Path(clip).stem
    job.command([sys.executable,'-B',VENDOR/'vendor/decode_keys.py',clip,comp,skeleton_cache,prefix],'decode-'+Path(clip).stem+'.log')
    keys=Path(str(prefix)+'-keys.json');validation=Path(str(prefix)+'-validate.json')
    v=json.loads(validation.read_text(encoding='utf-8'));k=json.loads(keys.read_text(encoding='utf-8'))
    if not v['structure']['walkAlignmentPass'] or v['numeric']['tracksWithNonFinite']:
        raise BridgeError('unsupported_hkx_mapping','Decoded source structure/mapping failed T47 constraints.',validation=str(validation))
    frames=k['meta']['frames'];duration=k['meta']['duration']
    if frames<1 or not __import__('math').isfinite(duration) or duration<0 or (frames>1 and duration<=0):
        raise BridgeError('invalid_sample_time','Decoded sample count or duration cannot form animation times.',frames=frames,duration=duration)
    return keys,validation,k

def unique(paths,label):
    paths=sorted(set(paths))
    if not paths:raise BridgeError('missing_resource','Required expanded resource was not found: '+label,resource=label)
    hashes={digest(p) for p in paths}
    if len(hashes)>1:raise BridgeError('ambiguous_resource','Multiple different resources match; narrow input roots or supply models JSON.',resource=label,candidates=[str(p) for p in paths])
    return paths[0]

def in_container(path,stem):return any(s.lower()==stem or s.lower().startswith(stem+'-') for s in path.parts[:-1])

def known_clip(clip):return workflows()['clips'].get(clip)
def clip_meta(clip,spec=None):
    known=known_clip(clip) or {};row=(spec or {}).get(clip) or {}
    return dict(label=row.get('label') or known.get('label') or 'unverified original HKX',
                identity=row.get('identity') or known.get('identity') or 'caller-supplied original clip; semantic identity is not inferred from the ID',
                archive=row.get('archive') or known.get('archive'),
                compendium=row.get('compendium') or known.get('compendium'),
                known=bool(known))

def discover(roots,asset,clips,models_path=None,clip_spec=None,parts=None,skeleton_hkx=None,failures=None):
    files=sorted(set(p.resolve() for root in roots for p in root.rglob('*') if p.is_file() and (p.suffix.lower() in ('.hkx','.compendium','.flver'))))
    model=asset.split('_',1)[1] if asset.lower().startswith('frame_') else asset;entry={'parts':{},'complete':True}
    if models_path:
        raw=json.loads(Path(models_path).read_text(encoding='utf-8-sig'))
        entry=raw.get(asset,raw.get(model,raw if 'parts' in raw else None))
        if not isinstance(entry,dict) or set(entry.get('parts',{}))!={'bd','hd','am','lg'}:raise BridgeError('invalid_models','models must contain selected frame and exactly bd/hd/am/lg parts.')
        for part,p in entry['parts'].items():
            for key in ('flver','hkx','comp'):
                if key not in p:raise BridgeError('invalid_models','Each part needs flver, hkx and comp.',part=part)
                path=Path(p[key]);path=(Path(models_path).parent/path).resolve() if not path.is_absolute() else path.resolve()
                if not path.is_file():raise BridgeError('missing_resource','Explicit models file does not exist.',path=str(path))
                p[key]=str(path)
            stem=Path(p['flver']).stem.lower()
            p['part_id']=stem
    else:
        selection=parts or {p:p+'_m_'+model for p in ('bd','hd','am','lg')}
        body=selection['bd'];body_comps=[p for p in files if p.suffix.lower()=='.compendium' and p.stem.lower()==body]
        for part in ('bd','hd','am','lg'):
            stem=selection[part]
            flver=unique([p for p in files if p.name.lower()==stem+'.flver'],stem+'.flver')
            candidates=[p for p in files if p.name.lower()=='skeleton.hkx' and in_container(p,stem)]
            if not candidates:raise BridgeError('part_skeleton_missing','The selected part package has no standalone Skeleton.hkx. FLVER exists; this is not an unregistered-resource rejection. Skeleton sharing/inheritance has not been established by this exporter.',part=part,part_id=stem,flver=str(flver),expected=stem+'/Skeleton.hkx',available_skeletons=[str(p) for p in files if p.name.lower()=='skeleton.hkx'],next_action='Run check-assembly to inspect actual weighted dependencies and available source skeletons. Explicit models may name a real shared skeleton, but required weight bones must exist; no skeleton is guessed.')
            hkx=unique(candidates,stem+'/Skeleton.hkx')
            comps=[p for p in files if p.suffix.lower()=='.compendium' and p.stem.lower()==stem]
            comp=unique(comps or body_comps,stem+' or body .compendium')
            entry['parts'][part]=dict(flver=str(flver),hkx=str(hkx),comp=str(comp),compendium_policy='own part, otherwise body compendium fallback',part_id=stem)
    master=unique([Path(skeleton_hkx)] if skeleton_hkx and Path(skeleton_hkx).is_file() else [p for p in files if p.name.lower()=='skeleton.hkx' and in_container(p,'c0000')] if not skeleton_hkx else [],'source Skeleton.hkx')
    found={};spec=clip_spec or {}
    for clip in clips:
      try:
        explicit=spec.get(clip,{}).get('hkx')
        hkx=unique(([Path(explicit)] if Path(explicit).is_file() else []) if explicit else [p for p in files if p.name.lower()==clip.lower()+'.hkx'],clip+'.hkx')
        meta=clip_meta(clip,spec)
        candidates=[p for p in files if p.suffix.lower()=='.compendium' and p.parent==hkx.parent]
        explicit_comp=spec.get(clip,{}).get('compendium')
        if explicit_comp:
            cp=Path(explicit_comp)
            # An explicit path/name is authoritative, never a preference hint.
            if cp.is_absolute():candidates=[cp] if cp.is_file() else []
            else:candidates=[p for p in candidates if p.name.lower()==cp.name.lower()]
        elif meta['compendium'] and Path(meta['compendium']).is_absolute():
            candidates=[Path(meta['compendium'])] if Path(meta['compendium']).is_file() else []
        elif meta['compendium']:
            named=[p for p in candidates if p.name.lower()==Path(meta['compendium']).name.lower()]
            if named:candidates=named
        if not explicit_comp and not candidates and meta['compendium']:
            candidates=[p for p in files if p.suffix.lower()=='.compendium' and p.name.lower()==Path(meta['compendium']).name.lower()]
        if not candidates:raise BridgeError('missing_compendium','No type compendium is available for the selected clip.',clip=clip,hkx=str(hkx),expected=meta['compendium'])
        comp=unique(candidates,clip+' compendium')
        found[clip]=(hkx,comp)
      except (BridgeError,OSError,ValueError) as ex:
        if failures is None:raise
        failures.append(dict(clip=clip,category='input_resolution',stage='discover',code=getattr(ex,'code','resource_error'),message=str(ex),details=getattr(ex,'details',{})))
    return entry,master,found

def clip_archives(job,game):
    w=workflows();spec=job.request.get('clip_spec') or {};chosen=[]
    for clip in job.request['clips']:
        row=spec.get(clip) or {}
        if row.get('hkx'):continue
        if row.get('archive'):
            archive=row['archive'].lower()
            if archive not in game.catalog:
                job.failures.append(dict(clip=clip,category='input_resolution',stage='locate',code='clip_archive_missing',message='Explicit archive absent from installed index.',archive=archive));continue
            chosen.append(archive);continue
        known=w['clips'].get(clip)
        if known:
            archive=known['archive'].lower()
            if archive in game.catalog:chosen.append(archive)
            else:job.failures.append(dict(clip=clip,category='input_resolution',stage='locate',code='clip_archive_missing',message='Reference catalog bank is absent from installed index.',archive=archive))
            continue
        prefix=clip.split('_')[0];base=f'/chr/c0000_{prefix}_'
        candidates=sorted(p for p in game.catalog if p.startswith(base) and p.endswith('.anibnd.dcx'))
        if not candidates:
            job.failures.append(dict(clip=clip,category='input_resolution',stage='locate',code='clip_archive_not_found',message='No matching c0000 animation bank; provide explicit archive or HKX path.',searched=base+'*'));continue
        chosen.extend(candidates)
    return sorted(set(chosen))

def extract_game(job):
    c=job.request['config'];out=job.out
    source=PACKAGE/'vendor/fsbridge/src';sys.path.insert(0,str(source))
    from game_input import GameInput
    os.environ['ACBRIDGE_NUXE_BRIDGE']=c['nuxe_bridge']
    api=SimpleNamespace(digest=digest,write_json=save)
    a=SimpleNamespace(game_dir=job.request['input_paths'][0],nuxe_res=c['nuxe_res'],witchy=c['witchy'])
    class DynamicInput(GameInput):
        def unpack(self,path,tag):job.unpack(path,tag+'-'+path.stem)
    game=DynamicInput(job,a,api)
    job.game=game
    job.mark('game-preflight');game.preflight()
    ident=job.request['asset'][-4:];w=workflows()
    archives=clip_archives(job,game)
    targets=([] if job.request.get('models') else ['/parts/'+stem+'.partsbnd.dcx' for stem in job.request['parts'].values()])+([] if job.request.get('skeleton_hkx') else [w['master_skeleton_archive']])+archives
    job.mark('extract-part-skeletons');game.extract(targets,'dynamic')
    job.mark('unpack-source-animations')
    for archive in targets:
        if archive.endswith('.anibnd.dcx'):job.unpack(game.root/archive.lstrip('/'),Path(archive).stem)
    game.manifest['dynamic_targets']=targets;game.manifest['clip_archives']=archives;game.save()
    return [game.root],game

if __name__=='__main__':
    if sys.argv[1]=='--inspect':
        try:
            from acbridge.dynamic import _inspect_dynamic_result_local
            print(json.dumps(_inspect_dynamic_result_local(sys.argv[2]),ensure_ascii=False));raise SystemExit(0)
        except BridgeError as ex:
            print(json.dumps(dict(status='error',error=dict(code=ex.code,message=str(ex))),ensure_ascii=False));raise SystemExit(2)
    from acbridge.dynamic_run import execute as execute_attempt
    raise SystemExit(execute_attempt(json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))))
