# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
import json
from pathlib import Path
def workflows():return json.loads((Path(__file__).parent/'data/workflows.json').read_text(encoding='utf-8'))
def describe(ident):
    import re
    d=workflows();operations=[];status={};required={};related=[]
    if ident in d['static_assets']:
        operations.append('export_static');status['export_static']='supported_bounded'
        required['export_static']=['game_dir OR input_roots with FLVER/DDS/material library','configured existing static runtime']
        related.append(dict(operation='export_static',status='supported_bounded',document='docs/static-pipeline.md',note='Legacy static path; historical code, not part of the expanded-only Alpha support scope.'))
    elif re.fullmatch(r'(?:WP_[A-Z]_\d+|frame_\d+)',ident,re.I):
        operations.append('export_static');status['export_static']='attemptable'
        required['export_static']=['Explicit resource ID or FLVER path; Game OR expanded inputs; existing static runtime']
        related.append(dict(operation='export_static',status='attemptable',document='docs/static-pipeline.md',note='Legacy static path; historical code, not part of the expanded-only Alpha support scope.'))
    if ident in d['dynamic_frames'] or re.fullmatch(r'frame_\d+',ident,re.I):
        operations.append('export_dynamic_frame');status['export_dynamic_frame']=d['dynamic_status']
        required['export_dynamic_frame']=['game_dir OR expanded input_roots with four part FLVER/Skeleton.hkx/compendia','c0000 master skeleton and selected clip HKX/compendium packages','NumPy/SciPy and configured Validator; Nuxe/Witchy for game mode']
        related.append(dict(operation='export_dynamic_frame',status=d['dynamic_status'],document='docs/dynamic-pipeline.md'))
        operations.append('check_assembly');status['check_assembly']='diagnostic'
    related.append(dict(operation='research_reference',status='research_only',document='docs/reference-workflows.md',note='Catalog is source-attributed reference data. It neither authorizes nor prohibits a dynamic attempt with explicit resources.'))
    return dict(operations=operations,operation_status=status,required_inputs=required,related_workflows=related,
                next_step='Supply resources and try the operation; inspect actual results.' if operations else 'No automatic source mapping for this catalog entry. An explicit parts/models/HKX dynamic attempt remains available; see docs/dynamic-pipeline.md.')
