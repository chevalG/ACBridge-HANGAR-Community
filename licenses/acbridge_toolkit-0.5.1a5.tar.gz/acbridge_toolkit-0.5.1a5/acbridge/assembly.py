# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Evidence-only assembly diagnostics. Never a prerequisite for export."""
import json
import os
import re
from pathlib import Path
from types import SimpleNamespace
from .lookup import BridgeError
from .operations import digest


def check_assembly(asset,output,input_roots=None,game_dir=None,config=None,timeout=600,parts=None):
    from .dynamic import _prepare
    from .dynamic_worker import Job,extract_game,unique,in_container,module,VENDOR,save
    if game_dir and input_roots:raise BridgeError('input_required','Supply Game OR expanded input_roots.')
    m=re.fullmatch(r'frame_(\d+)',asset,re.I)
    selection={p:p+'_m_'+m.group(1) for p in ('bd','hd','am','lg')} if m else {}
    for p,v in (parts or {}).items():
        if p not in ('bd','hd','am','lg') or not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_]+',v):raise BridgeError('invalid_parts','Use bd/hd/am/lg resource stems.')
        selection[p]=v.lower()
    if set(selection)!={'bd','hd','am','lg'}:raise BridgeError('part_selection_required','Supply frame_NUMBER or all four part stems.')
    roots=[Path(p).expanduser().resolve() for p in ([game_dir] if game_dir else input_roots or [])]
    if not roots or any(not p.is_dir() for p in roots):raise BridgeError('input_missing','Supply an existing Game or expanded resource directory.')
    c,out=_prepare('check_assembly',output,config,timeout,roots)
    out.mkdir(parents=True);(out/'logs').mkdir()
    request=dict(operation='check_assembly',asset=asset,output=str(out),config=c,timeout=timeout,input_paths=[str(p) for p in roots],parts=selection,clips=[])
    job=Job(request);job.failures=[];game=None
    try:
        if game_dir:roots,game=extract_game(job)
        files=sorted(set(p.resolve() for r in roots for p in r.rglob('*') if p.is_file() and p.suffix.lower() in ('.flver','.hkx','.compendium')))
        core=module('acbridge_assembly_diagnostic_core',VENDOR/'scripts/build.py')
        import numpy as np
        result_parts={};rigs={};source_paths=set();issues=[]
        body_comps=[p for p in files if p.suffix.lower()=='.compendium' and p.stem.lower()==selection['bd']]
        for slot,stem in selection.items():
            row=dict(part_id=stem,flver=None,skeleton=None,weighted_bones={},errors=[]);result_parts[slot]=row
            try:
                f=unique([p for p in files if p.name.lower()==stem+'.flver'],stem+'.flver');row['flver']=str(f);source_paths.add(f)
                mesh=core.read_flver(f);names=[b.name for b in mesh.bones]
                row['flver_bone_count']=len(names)
                for im in mesh.inflate():
                    w=np.asarray(im.vertices.bone_weights,float);bi=np.asarray(im.vertices.bone_indices,int)
                    for i in set(bi[w>0].tolist()):
                        if not 0<=i<len(names):raise BridgeError('invalid_weight_bone_index','Positive weights reference an invalid FLVER bone index.',index=i,bone_count=len(names))
                        n=names[i];row['weighted_bones'][n]=row['weighted_bones'].get(n,0)+int(((bi==i)&(w>0)).sum())
                sks=[p for p in files if p.name.lower()=='skeleton.hkx' and in_container(p,stem)]
                if not sks:
                    row['errors'].append(dict(code='part_skeleton_missing',message='Original part has no standalone Skeleton.hkx; sharing is not inferred.'))
                    continue
                sk=unique(sks,stem+' Skeleton.hkx');comps=[p for p in files if p.suffix.lower()=='.compendium' and p.stem.lower()==stem]
                cp=unique(comps or body_comps,stem+' or body compendium')
                rigs[slot]=core.skeleton(sk,cp);source_paths.update((sk,cp));row.update(skeleton=str(sk),compendium=str(cp),hkx_bone_count=len(rigs[slot][0]),compendium_policy='own part, otherwise body')
            except (BridgeError,OSError,ValueError,KeyError) as ex:row['errors'].append(dict(code=getattr(ex,'code',type(ex).__name__),message=str(ex),details=getattr(ex,'details',{})))
        union=set().union(*(set(v[0]) for v in rigs.values()))
        masters=[p for p in files if p.name.lower()=='skeleton.hkx' and in_container(p,'c0000')]
        source_bones=set()
        if masters:
            master=unique(masters,'c0000 source skeleton');source_bones=set(core.skeleton(master)[0]);source_paths.add(master)
        for slot,row in result_parts.items():
            row['missing_weighted_bones_from_part_hkx']=sorted(set(row['weighted_bones'])-set(rigs[slot][0])) if slot in rigs else None
            row['missing_weighted_bones_from_selected_hkx_union']=sorted(set(row['weighted_bones'])-union)
            row['weighted_bones_in_source_skeleton']=sorted(set(row['weighted_bones'])&source_bones)
            row['missing_weighted_bones_from_all_available_skeletons']=sorted(set(row['weighted_bones'])-union-source_bones)
        comparisons=[]
        for i,first in enumerate(rigs):
            for second in list(rigs)[i+1:]:
                an,ap,al,aw,_=rigs[first];bn,bp,bl,bw,_=rigs[second];shared=sorted(set(an)&set(bn));diff=[];align=[]
                for n in shared:
                    wd=float(np.abs(aw[n]-bw[n]).max());ld=float(np.abs(al[n]-bl[n]).max())
                    align.append(aw[n]@np.linalg.inv(bw[n]))
                    if wd>1e-4 or ld>1e-4 or ap[n]!=bp[n]:diff.append(dict(bone=n,world_max_abs=wd,local_max_abs=ld,first_parent=ap[n],second_parent=bp[n]))
                residual=max((float(np.abs(a-align[0]).max()) for a in align),default=0)
                comparisons.append(dict(first=first,second=second,shared_bones=len(shared),differences=diff,world_conflict_count=sum(d['world_max_abs']>1e-4 for d in diff),single_world_alignment_residual=residual,single_world_alignment_supported=bool(align) and residual<=1e-4,alignment_matrix=align[0].tolist() if align else None))
        blocked=any(r['errors'] or r['missing_weighted_bones_from_selected_hkx_union'] for r in result_parts.values()) or any(r['world_conflict_count'] for r in comparisons)
        sources=[dict(path=str(p),sha256=digest(p)) for p in sorted(source_paths)]
        result=dict(schema_version=1,status='ready',operation='check_assembly',asset=asset,output=str(out),diagnostic_only=True,assembly_export_performed=False,current_assembler_assessment='unresolved_dependencies_or_reference_frames' if blocked else 'no_checked_obstacle; export and deformation still require validation',parts=result_parts,comparisons=comparisons,sources=sources,
            next_actions=['Export is always attemptable; this report is never a permission gate.','Missing standalone HKX does not prove the part is impossible: identify an actual shared skeleton/FLVER reference dependency.','A constant world alignment alone does not prove geometry and attachments can use it; no transform is applied by this diagnostic.'],outputs={'assembly.json':str(out/'assembly.json')})
        if any(digest(Path(s['path']))!=s['sha256'] for s in sources):raise BridgeError('source_changed','Source changed during inspection.')
        save(out/'assembly.json',result);save(out/'status.json',dict(status='ready',operation='check_assembly'));return result
    finally:
        if game and hasattr(game,'before'):game.readonly_check()
