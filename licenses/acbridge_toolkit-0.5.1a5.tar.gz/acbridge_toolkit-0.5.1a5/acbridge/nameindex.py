# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66-N 2026-10-26: equipment name lookup over builtin + locally built indexes.
"""Search equipment display names and map them to technical resource IDs.

The shipped builtin index covers player-equippable frame parts and hand/
shoulder weapons (see docs/name-index.md). Users can build an additional
local index from their own legally owned FMG/PARAM extraction with
`acbridge build-name-index`; local entries overlay the builtin ones at
query time. Every hit carries its evidence chain and the index it came
from, so name resolution is auditable instead of magical.
"""
import json
import os
import re
from difflib import SequenceMatcher
from pathlib import Path

from .lookup import BridgeError, normalize

LOCAL_BASENAME = 'name_index.local.json'
NS_BY_KIND = {'weapon': 'weapon', 'part': 'ac_part'}
IDLIKE = re.compile(r'(?:c\d{4}|(?:hd|bd|am|lg)m\d{4}|wp[a-z]?\d{4}|frame\d{4})')


def builtin_index_path():
    return Path(__file__).parent / 'data' / 'name_index.json'


def local_index_paths(config=None):
    """Candidate local index files, in precedence order, existing or not."""
    paths = []
    env = os.environ.get('ACBRIDGE_NAME_INDEX')
    if env:
        paths.extend(Path(p).expanduser() for p in env.split(os.pathsep) if p)
    for cfg in (config, os.environ.get('ACBRIDGE_CONFIG')):
        if cfg:
            paths.append(Path(cfg).expanduser().resolve().parent / LOCAL_BASENAME)
            break
    paths.append(Path.home() / '.acbridge' / LOCAL_BASENAME)
    seen, unique = set(), []
    for p in paths:
        s = str(p).casefold()
        if s not in seen:
            seen.add(s)
            unique.append(p)
    return unique


def _read_index(path, origin):
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        entries = data['entries']
        sources = data.get('sources', {})
        if not isinstance(entries, list):
            raise ValueError('entries must be a list')
        return data, entries, sources
    except (OSError, ValueError, KeyError) as ex:
        return None, None, dict(error=f'{type(ex).__name__}: {ex}')


def load_indexes(config=None):
    """Load builtin + local indexes; later files overlay earlier per key."""
    loaded = []
    load_errors = []
    builtin = builtin_index_path()
    data, entries, sources = _read_index(builtin, 'builtin')
    if data is not None:
        loaded.append(dict(origin='builtin', path=str(builtin), data=data, entries=entries, sources=sources))
    else:
        load_errors.append(dict(origin='builtin', path=str(builtin), error=sources['error']))
    for p in local_index_paths(config):
        if not p.is_file():
            continue
        data, entries, sources = _read_index(p, str(p))
        if data is not None:
            loaded.append(dict(origin=str(p), path=str(p), data=data, entries=entries, sources=sources))
        else:
            load_errors.append(dict(origin=str(p), path=str(p), error=sources['error']))
    return loaded, load_errors


def _entry_key(entry):
    return (entry.get('kind'), entry.get('row_id'))


def merged_entries(config=None):
    """Overlay-resolved entries plus the provenance maps needed to present them."""
    loaded, load_errors = load_indexes(config)
    by_key = {}
    sources = {}
    for layer in loaded:
        for sid, src in layer['sources'].items():
            sources.setdefault(sid, src)
        for entry in layer['entries']:
            by_key[_entry_key(entry)] = (entry, layer['origin'], sources)
    return [dict(entry=e, origin=origin, sources=srcs) for e, origin, srcs in by_key.values()], loaded, load_errors, sources


def _labels(entry):
    labels = [entry.get('display_name'), *(entry.get('search_keys') or []),
              entry.get('resource_id'), entry.get('resource_stem')]
    labels.append(str(entry.get('row_id')))
    labels.append(str(entry.get('model_id')))
    return [str(l) for l in labels if l]


def _slot_label(entry):
    if entry.get('kind') == 'weapon':
        return f"{entry.get('slot_group')}_{entry.get('side')}"
    return entry.get('slot')


def _pair_note(hits):
    """When one designation spans several rows, say what distinguishes them."""
    if len(hits) < 2:
        return None
    names = {normalize(h['entry'].get('display_name')) for h in hits}
    if len(names) != 1:
        return None
    kinds = {h['entry'].get('kind') for h in hits}
    if kinds == {'weapon'}:
        what = 'left/right variants' if len({h['entry'].get('side') for h in hits}) > 1 else 'rows'
    else:
        what = 'frame slots'
    slots = ', '.join(sorted(_slot_label(h['entry']) for h in hits))
    return (f'Same designation resolves to {len(hits)} {what} ({slots}); '
            'choose the explicit slot/side or resource ID before processing.')


def search_name_index(query, namespace=None, limit=10, config=None):
    """Search display names, designations, model codes and technical IDs.

    Returns a lookup-compatible envelope. Exact designation matches are
    never silently narrowed: R/L pairs and cross-slot names stay ambiguous
    candidates with explicit slot/side labels.
    """
    if not isinstance(query, str) or not normalize(query) or len(query) > 200:
        raise BridgeError('invalid_query', 'Provide a non-empty asset name or ID, at most 200 characters.')
    if namespace is not None and namespace not in ('weapon', 'ac_part'):
        raise BridgeError('invalid_namespace', 'Name index namespaces: weapon, ac_part.')
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 50:
        raise BridgeError('invalid_limit', 'limit must be an integer in 1..50.')
    merged, loaded, load_errors, _ = merged_entries(config)
    q = normalize(query)
    idlike = bool(IDLIKE.fullmatch(q))
    exact, fuzzy = [], []
    for rec in merged:
        entry = rec['entry']
        if namespace and NS_BY_KIND.get(entry.get('kind')) != namespace:
            continue
        labels = _labels(entry)
        hit_exact = next((s for s in labels if normalize(s) == q), None)
        if hit_exact is not None:
            exact.append((1.0 if normalize(entry.get('display_name', '')) == q else 0.97, rec, hit_exact))
            continue
        if idlike:
            continue
        scored = []
        for s in labels:
            n = normalize(s)
            score = SequenceMatcher(None, q, n).ratio()
            if len(q) >= 3 and q in n:
                score = max(score, 0.9)
            scored.append((score, s))
        score, hit = max(scored)
        if score >= 0.65:
            fuzzy.append((score, rec, hit))
    mode = 'exact' if exact else ('fuzzy' if fuzzy else 'none')
    matches = sorted(exact or fuzzy, key=lambda m: (-m[0], str(m[1]['entry'].get('row_id'))))
    total = len(matches)
    status = 'not_found' if not total else ('unique' if total == 1 else 'ambiguous') if mode == 'exact' else 'suggestions'
    pair_note = _pair_note([m[1] for m in matches[:limit]]) if mode == 'exact' else None
    results = [to_lookup_row(m[1], m[0], m[2]) for m in matches[:limit]]
    for row, (score, _, hit) in zip(results, matches[:limit]):
        row['match'] = dict(method=f'name_index_{mode}', score=round(score, 4), matched_text=hit)
    if pair_note:
        for row in results:
            row['name_index']['disambiguation'] = pair_note
    return dict(schema_version=1, status=status, query=query, namespace=namespace, total=total,
                truncated=total > limit, results=results,
                next_action=(pair_note if pair_note else
                             'Use an explicit candidate ID before processing.' if status in ('ambiguous', 'suggestions') else
                             'No indexed name; build a local index from your own FMG/PARAM (acbridge build-name-index).' if status == 'not_found' else None),
                name_index=index_summary(merged, loaded, load_errors))


def _resolve_sources(evidence, sources):
    resolved = []
    for ref in evidence:
        base, _, selector = ref.partition('#')
        if base in sources:
            item = dict(source_id=base, **sources[base])
            if selector:
                item['selector'] = selector
            resolved.append(item)
    return resolved


def to_lookup_row(rec, score, matched_text):
    """Shape a name-index hit as a catalog-compatible lookup result row."""
    entry, origin, sources = rec['entry'], rec['origin'], rec['sources']
    kind = entry.get('kind')
    row = dict(
        id=entry.get('resource_id'),
        name_en=entry.get('display_name'),
        namespace=NS_BY_KIND.get(kind, 'weapon'),
        category='weapon' if kind == 'weapon' else 'ac_part',
        is_game_id=True,
        aliases=list(entry.get('search_keys') or []),
        side=entry.get('side') if kind == 'weapon' else None,
        resource_path=entry.get('resource_path'),
        name_origin=f'name_index:{origin}',
        sources=_resolve_sources(entry.get('evidence', []), sources),
        evidence_refs=list(entry.get('evidence', [])),
        name_index=dict(
            kind=kind, display_name=entry.get('display_name'), row_id=entry.get('row_id'),
            model_id=entry.get('model_id'), slot=_slot_label(entry),
            slot_group=entry.get('slot_group'), side=entry.get('side'),
            equip_flags=entry.get('equip_flags'),
            weapon_bay_compatible=entry.get('weapon_bay_compatible'),
            resource_stem=entry.get('resource_stem'), resource_basis=entry.get('resource_basis'),
            origin=origin, builtin=origin == 'builtin',
        ),
    )
    if entry.get('slot_note'):
        row['name_index']['slot_note'] = entry['slot_note']
    if entry.get('resource_note'):
        row['name_index']['resource_note'] = entry['resource_note']
    if entry.get('content_verification'):
        row['name_index']['content_verification'] = entry['content_verification']
    if entry.get('companion_stems'):
        row['name_index']['companion_stems'] = list(entry['companion_stems'])
        row['name_index']['companion_resource_ids'] = [s.upper() for s in entry['companion_stems']]
    return row


def index_summary(merged, loaded, load_errors):
    # Count the overlay-resolved entries, not each layer separately: a local
    # index replacing builtin rows must not double the reported coverage.
    counts = {}
    versions = {}
    for layer in loaded:
        origin = 'builtin' if layer['origin'] == 'builtin' else str(layer['path'])
        versions[origin] = layer['data'].get('index_version') or layer['data'].get('generated') or 'unversioned'
    origins = {}
    for rec in merged:
        entry = rec['entry']
        key = f"{entry.get('kind')}:{_slot_label(entry)}"
        counts[key] = counts.get(key, 0) + 1
        origins.setdefault(key, {'builtin': 0, 'local': 0})
        origins[key]['builtin' if rec['origin'] == 'builtin' else 'local'] += 1
    summary = dict(schema_version=1, loaded=versions, entries_by_slot=counts,
                   entry_origin_by_slot=origins)
    if any(l['data'].get('builtin') for l in loaded):
        summary['rights_status'] = 'review candidate; no final legal clearance claimed'
    if load_errors:
        summary['load_errors'] = load_errors
    summary['local_build_hint'] = 'acbridge build-name-index --msg-root ... --regulation ...'
    return summary


def name_index_status(config=None):
    merged, loaded, load_errors, sources = merged_entries(config)
    builtin_layer = next((l for l in loaded if l['origin'] == 'builtin'), None)
    status = dict(
        schema_version=1, status='ready' if merged or loaded else 'error',
        builtin=dict(path=str(builtin_index_path()), present=builtin_layer is not None,
                     index_version=builtin_layer['data'].get('index_version') if builtin_layer else None,
                     scope=builtin_layer['data'].get('scope') if builtin_layer else None,
                     rights_status=builtin_layer['data'].get('rights_status') if builtin_layer else None,
                     distribution_basis=builtin_layer['data'].get('distribution_basis') if builtin_layer else None),
        local_indexes=[dict(path=l['path'], index_version=l['data'].get('index_version'),
                            language=l['data'].get('language'), entries=len(l['entries']))
                       for l in loaded if l['origin'] != 'builtin'],
        local_candidate_paths=[str(p) for p in local_index_paths(config)],
        total_entries=len(merged),
        summary=index_summary(merged, loaded, load_errors),
    )
    if load_errors:
        status['load_errors'] = load_errors
    return status


def default_local_output(config=None):
    for cfg in (config, os.environ.get('ACBRIDGE_CONFIG')):
        if cfg:
            return str(Path(cfg).expanduser().resolve().parent / LOCAL_BASENAME)
    return str(Path.home() / '.acbridge' / LOCAL_BASENAME)


def build_local(msg_root, regulation_root, archive_index=None, output=None, config=None, index_version='local'):
    """Build and write a local name index from the user's own extraction.

    The output is private convenience data for this installation; it is never
    published and never overwrites the shipped builtin index.
    """
    from .nameindex_build import build_name_index
    index, report = build_name_index(msg_root, regulation_root, archive_index)
    index['index_version'] = index_version
    index['builtin'] = False
    index['rights_notice'] += (' This locally built copy is private convenience data for this '
                               'installation; do not redistribute it or publish it.')
    out = Path(output or default_local_output(config)).expanduser()
    if out.resolve() == builtin_index_path().resolve() or builtin_index_path().parent in out.resolve().parents:
        raise BridgeError('invalid_output', 'Refusing to write a local index over the shipped builtin index.', output=str(out))
    if out.suffix != '.json':
        raise BridgeError('invalid_output', 'Output must be a .json file.', output=str(out))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding='utf-8', newline='\n')
    return dict(schema_version=1, status='ready' if not report['unresolved_stems'] else 'partial',
                operation='build_name_index', output=str(out),
                entries=len(index['entries']), report=report,
                next_action='Name lookups now overlay this file automatically; verify a known name with acbridge lookup.')
