# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""Installed user resources; no developer checkout or global configuration required."""
import json,shutil
from pathlib import Path
from .lookup import BridgeError

def resources():
 root=Path(__file__).parent/'resources'
 skill=root/'skills/acbridge/SKILL.md'
 return dict(schema_version=1,status='ready',operation='resources',root=str(root),readme=str(root/'README.md'),installation=str(root/'docs/installation.md'),config_example=str(root/'config.example.json'),
   skill=str(skill) if skill.is_file() else None,
   skill_note='Bundled skill matches the 10 MCP tools of this release; ignore older global copies.' if skill.is_file() else 'Skill not installed in this environment.',
   release_status='Release Blocked pending ownership/data review and final authorization')

def initialize(output):
 root=Path(__file__).parent/'resources';out=Path(output).expanduser().resolve()
 if out.exists():raise BridgeError('output_exists','Choose a new workspace directory; init never overwrites files.',output=str(out))
 if root==out or root in out.parents:raise BridgeError('path_overlap','Choose a workspace outside the installed package.')
 shutil.copytree(root,out)
 return dict(schema_version=1,status='ready',operation='init',workspace=str(out),config_example=str(out/'config.example.json'),next_action='Copy config.example.json to config.local.json, set validator/output paths, then follow docs/installation.md. No extraction EXEs are required for expanded dynamic input.')
