# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""R3 consumer check, job parameterized. No pose reset or global Blender patch."""
import bpy,json,sys,math
import numpy as np
from pathlib import Path
from mathutils import Vector
out=Path(sys.argv[sys.argv.index('--')+1]);req=json.loads((out/'request.json').read_text(encoding='utf-8'));meta=json.loads((out/'animation-samples.json').read_text(encoding='utf-8'));expected=np.load(out/'animation-expected.npz');adapter=req.get('blender_adapter','default')
bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.read_factory_settings(use_empty=True);scene=bpy.context.scene;scene.render.fps=30
import io_scene_gltf2.blender.imp.vnode as vnode
original=vnode.pick_bone_rotation
try:
 if adapter=='identity-basis':vnode.pick_bone_rotation=lambda *args:None
 bpy.ops.import_scene.gltf(filepath=str(out/'asset-ue.glb'))
finally:vnode.pick_bone_rotation=original
arms=[o for o in scene.objects if o.type=='ARMATURE'];shapes={b.custom_shape for a in arms for b in a.pose.bones if b.custom_shape};meshes=[o for o in scene.objects if o.type=='MESH' and o not in shapes]
for o in shapes:o.hide_render=True
assert arms and meshes
assert len(arms[0].data.bones)==meta['joint_count']
assert sum(len(o.data.vertices) for o in meshes)==len(expected['source_vertex_indices'])
weight_error=0.;offset=0;expected_joints=expected['joints'];expected_weights=expected['weights'];expected_names=expected['bone_names']
for mesh in meshes:
 for v in mesh.data.vertices:
  actual={mesh.vertex_groups[x.group].name:x.weight for x in v.groups if x.weight>0};want={}
  for j,w in zip(expected_joints[offset+v.index],expected_weights[offset+v.index]):
   if w>0:
    n=str(expected_names[j]);want[n]=want.get(n,0.)+float(w)
  assert actual.keys()==want.keys(),('Imported weighted bone correspondence',v.index)
  weight_error=max(weight_error,max((abs(actual[k]-want[k]) for k in want),default=0.))
 offset+=len(mesh.data.vertices)
assert weight_error<1e-7
def select(name):
 found=False
 for o in scene.objects:
  if o.animation_data:
   o.animation_data.action=None
   for track in o.animation_data.nla_tracks:
    track.mute=track.name!=name;found|=not track.mute
 assert found,('NLA not found',name)
def pose(seconds):
 frame=1+seconds*30;scene.frame_set(math.floor(frame),subframe=frame%1);return frame
def vertices():
 data=[]
 for o in meshes:
  ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();data.extend(tuple(ev.matrix_world@v.co) for v in m.vertices);ev.to_mesh_clear()
 return np.asarray(data)
rows=[];renders=[];cam=None
if req.get('render_preview'):
 (out/'preview').mkdir(exist_ok=True);scene.render.engine='BLENDER_WORKBENCH';scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL';scene.display.shading.show_cavity=True;scene.display.shading.show_shadows=True;scene.world=bpy.data.worlds.new('ACBridgePreview');scene.world.color=(.10,.10,.10);scene.render.resolution_x=640;scene.render.resolution_y=800;scene.render.resolution_percentage=100;cam=bpy.data.objects.new('ACBridgeCamera',bpy.data.cameras.new('ACBridgeCamera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.clip_end=1000000
 bounds={}
 for name in {s['animation'] for s in meta['samples']}:
  pts=np.concatenate([expected[s['key']] for s in meta['samples'] if s['animation']==name]);lo=pts.min(0);hi=pts.max(0);bounds[name]=((lo+hi)/2,float(max(hi-lo)))
for sample in meta['samples']:
 select(sample['animation']);frame=pose(sample['seconds']);actual=vertices();target=expected[sample['key']];d=np.linalg.norm(actual-target,axis=1);i=int(d.argmax());rows.append(dict(**sample,frame=frame,max_m=float(d[i]),source_vertex=int(expected['source_vertex_indices'][i]),cpu=target[i].tolist(),blender=actual[i].tolist()))
 if cam and sample['animation'].endswith('_inplace'):
  source_frames=next(c['frames'] for c in json.loads((out/'geometry.json').read_text())['clips'] if sample['animation']==c['clip']+'_inplace');keys={0,source_frames//3,2*source_frames//3,source_frames-1}
  if sample['source_key'] in keys or meta['policy']=='all-keys':
   c,extent=bounds[sample['animation']];center=Vector(c);cam.data.ortho_scale=extent*1.15
   views={'front':(0,-1,.03),'side':(-1,0,.03),'oblique':(-.8,-1,.3)} if sample['source_key'] in keys else {'oblique':(-.8,-1,.3)}
   for view,direction in views.items():
    cam.location=center+Vector(direction).normalized()*extent*3;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();path=out/'preview'/f"{sample['animation']}-key{sample['source_key']:04d}-{view}.png";scene.render.filepath=str(path);bpy.ops.render.render(write_still=True);renders.append(dict(animation=sample['animation'],source_key=sample['source_key'],seconds=sample['seconds'],view=view,path=str(path)))
if meta['samples']:
 name=next(s['animation'] for s in meta['samples'] if s['animation'].endswith('_inplace'));select(name);pose(0);scene.frame_start=1;scene.frame_end=max(1,round(max(s['seconds'] for s in meta['samples'] if s['animation']==name)*30)+1)
 if cam:
  c,extent=bounds[name];center=Vector(c);cam.data.ortho_scale=extent*1.15;cam.location=center+Vector((-.8,-1,.3)).normalized()*extent*3;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.wm.save_as_mainfile(filepath=str(out/'asset.blend'))
worst=max(rows,key=lambda r:r['max_m'],default=None);maximum=worst['max_m'] if worst else None
result=dict(status='passed' if rows and maximum<.0001 else 'failed' if rows else 'not_run',adapter=adapter,blender_version=bpy.app.version_string,sample_policy=meta['policy'],fps=30,samples=len(rows),vertices=len(expected['source_vertex_indices']),weights_max_abs_error=weight_error,tolerance_m=.0001,max_error_m=maximum,worst=worst,rows=rows,scope='Blender vs original exported GLB CPU numerical equivalence, not original-game mechanical correctness or visual PASS.',blend=str(out/'asset.blend'))
(out/'blender-readback.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(out/'preview-manifest.json').write_text(json.dumps(dict(rendered=bool(renders),images=renders,visual_review='not_performed_by_renderer'),indent=2),encoding='utf-8');print('BLENDER CONSUMPTION',result['status'],maximum,flush=True)
