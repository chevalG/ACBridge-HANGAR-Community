# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""MCP is a thin adapter over exactly the CLI's public API."""
import asyncio
import json
from mcp.server.fastmcp import FastMCP
from mcp.types import CallToolResult,TextContent,ToolAnnotations
from .lookup import BridgeError, lookup_asset as lookup
from .operations import capabilities,export_static as export,inspect_result as inspect
from .presentation import present,config_path

server=FastMCP('ACBridge',instructions='Discover resources and actual animation-bank contents, then try unregistered frames, mixed parts, explicit HKX/FLVER. Catalog coverage is reference information, not permission. Read actual failures and partial outputs. check_assembly diagnoses; it never gates export. Relative local paths use ACBRIDGE_CONFIG directory. Set UTF-8 stdio and ACBRIDGE_CONFIG for processing.',log_level='WARNING')

def result(fn,*args,detail='summary',**kw):
    try:
        if detail not in ('summary','full'):raise BridgeError('invalid_detail','detail must be summary or full.')
        data=fn(*args,**kw);error=data.get('status')=='error'
    except BridgeError as ex:data=dict(schema_version=1,status='error',error=dict(code=ex.code,message=str(ex),**ex.details));error=True
    except (OSError,ValueError,ImportError) as ex:data=dict(schema_version=1,status='error',error=dict(code='environment_error',message=str(ex)));error=True
    data=present(data,detail) if detail in ('summary','full') else data
    return CallToolResult(content=[TextContent(type='text',text=json.dumps(data,ensure_ascii=False))],structuredContent=data,isError=error)

@server.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False))
def lookup_asset(query:str,namespace:str|None=None,limit:int=10)->CallToolResult:
    """Find an AC6 asset by equipment display name (e.g. MORLEY), designation, model code or original ID; returns slot/side, evidence sources and ambiguity. Namespace optional, limit 1..50."""
    return result(lookup,query,namespace,limit)

@server.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False))
def name_index_status(config:str|None=None)->CallToolResult:
    """Report the equipment name index: builtin coverage, local overlay files, provenance and rights status. Read-only; use the CLI build-name-index to generate a local overlay from your own FMG/PARAM."""
    from .nameindex import name_index_status as status
    return result(lambda:status(config_path(config) if config else None))

@server.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
async def build_name_index(msg_root:str,regulation:str,archive_index:str|None=None,output:str|None=None,config:str|None=None,index_version:str='local',detail:str='summary')->CallToolResult:
    """Build a LOCAL equipment name index from the user's own extracted FMG/PARAM XML (item designations only; descriptive text never read). Paths are used as given; output defaults to name_index.local.json beside the config or in ~/.acbridge/. Private convenience data; overlays the builtin index at query time."""
    from .nameindex import build_local
    def call():return build_local(msg_root,regulation,archive_index,output,config,index_version)
    return await asyncio.to_thread(result,call,detail=detail)

@server.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False))
def asset_capabilities(query:str|None=None)->CallToolResult:
    """List bounded supported static profiles, or inspect operations for a queried asset. No game resources required."""
    return result(capabilities,query)

@server.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
async def export_static(asset:str,output:str,input_roots:list[str]|None=None,game_dir:str|None=None,timeout:int=600,detail:str='summary')->CallToolResult:
    """Try an exact WP_X_NUMBER/frame_NUMBER or an explicit FLVER path using the existing static backend; no name-registration requirement. Supply unpacked input_roots OR game_dir (explicit FLVER uses expanded roots/materials). Returns GLB/Blend, validation and honest partials. Relative paths use config directory. Requires ACBRIDGE_CONFIG."""
    return await asyncio.to_thread(result,_export_static,asset,output,input_roots,game_dir,timeout,detail=detail)

def _export_static(asset,output,input_roots,game_dir,timeout):
    if asset.lower().endswith('.flver'):asset=config_path(asset)
    return export(asset,config_path(output),[config_path(p) for p in input_roots or []],config_path(game_dir),None,timeout)

@server.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False))
def inspect_result(output:str,detail:str='summary')->CallToolResult:
    """Check an exported job's GLB structure/hash, Validator and Blender readback evidence."""
    return result(lambda:inspect(config_path(output)),detail=detail)

@server.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
async def export_dynamic_frame(asset:str,output:str,input_roots:list[str]|None=None,game_dir:str|None=None,clips:list[str]|None=None,models:str|None=None,clip_spec:str|None=None,timeout:int=600,parts:dict[str,str]|None=None,skeleton_hkx:str|None=None,skeleton_compendium:str|None=None,detail:str='summary',assembly_method:str='geometry',blender_adapter:str='default',animation_check:str='sampled',render_preview:bool=False)->CallToolResult:
    """Try weighted AC export with R1/R2 geometric assembly. parts maps bd/hd/am/lg to original stems; models/clip_spec accept explicit files. assembly_method: geometry(default)/relative/baseline. blender_adapter: default/identity-basis(optional R3). animation_check: sampled/all-keys; render_preview saves actual Blender views. Read verification: numerical validity is not dynamic visual PASS. No registration gate; Game OR expanded inputs, fresh output, configured tools required."""
    from .dynamic import export_dynamic_frame as export_dynamic
    def call():return export_dynamic(asset,config_path(output),[config_path(p) for p in input_roots or []],config_path(game_dir),clips,config_path(models),None,timeout,config_path(clip_spec),parts,config_path(skeleton_hkx),config_path(skeleton_compendium),assembly_method,blender_adapter,animation_check,render_preview)
    return await asyncio.to_thread(result,call,detail=detail)

@server.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False))
def discover_assets(query:str='',kind:str|None=None,input_roots:list[str]|None=None,game_dir:str|None=None,limit:int=20,offset:int=0)->CallToolResult:
    """Discover real original index paths or expanded parts/frames/weapons/archives. kind: part/frame/weapon/archive. Index presence is not proof of installed content. Pagination uses limit/offset. Relative local paths resolve against ACBRIDGE_CONFIG directory."""
    from .discovery import discover_assets as discover
    return result(lambda:discover(query,kind,[config_path(p) for p in input_roots or []],config_path(game_dir),None,limit,offset))

@server.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
async def list_clips(archive:str|None=None,input_roots:list[str]|None=None,game_dir:str|None=None,output:str|None=None,limit:int=10,offset:int=0,timeout:int=600,detail:str='summary')->CallToolResult:
    """List actual HKX in a selected ANIBND (Game indexed /chr/... or expanded roots or local packed archive). Lightweight metadata, not mass decoding: tracks/duration/native sample rate, compendium and extractedMotion. Unknown action semantics stay UNKNOWN. Game/packed inputs are staged into a fresh job; no source writes. Optional output is a fresh configured child; relative paths use config directory. Full report on disk, rows paginated."""
    from .discovery import list_clips as probe
    def call():
        chosen=archive
        if chosen and not game_dir and not chosen.startswith('/chr/'):
            from pathlib import Path
            candidate=config_path(chosen)
            if Path(candidate).is_file():chosen=candidate
        return probe(chosen,[config_path(p) for p in input_roots or []],config_path(game_dir),config_path(output),None,limit,offset,timeout)
    return await asyncio.to_thread(result,call,detail=detail)

@server.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
async def check_assembly(asset:str,output:str,input_roots:list[str]|None=None,game_dir:str|None=None,parts:dict[str,str]|None=None,timeout:int=600,detail:str='summary')->CallToolResult:
    """Inspect real FLVER weighted dependencies and HKX parent/local/world differences. Writes assembly.json; never a gate or proof of successful assembly. Same parts semantics as export_dynamic_frame; relative local paths use config directory."""
    def call():
        import subprocess,sys,os
        from pathlib import Path
        kw=dict(asset=asset,output=config_path(output),input_roots=[config_path(p) for p in input_roots or []],game_dir=config_path(game_dir),parts=parts,timeout=timeout)
        try:
            p=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('assembly_worker.py')),json.dumps(kw)],stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding='utf-8',timeout=timeout*8+60,env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1'))
            return json.loads(p.stdout)
        except subprocess.TimeoutExpired as ex:raise BridgeError('assembly_inspection_timeout','Assembly inspection exceeded total budget; inspect retained job logs.') from ex
    return await asyncio.to_thread(result,call,detail=detail)

def run():
    import sys
    for stream in (sys.stdin,sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8')
    server.run(transport='stdio')
