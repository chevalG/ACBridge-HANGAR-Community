# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""One small operation set, using the existing FS Asset Bridge conversion core."""
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
from .lookup import BridgeError, lookup_asset

PROFILES={
 'WP_R_1610':dict(type='weapon',exclude_mtd=[],label='RANSETSU-RF right; static NormalW profile'),
 'WP_L_0411':dict(type='weapon',exclude_mtd=['P[WP_0410]_Laser.matxml'],label='Vvc-774LS left; known battle-beam geometry excluded'),
 'frame_1010':dict(type='ac',exclude_mtd=[],label='Project sample: HD/BD/AM/LG_M_1010; static raw bind-space; normalized height 10'),
}
PATH_KEYS=('blender','importer','validator','adapter','nuxe_bridge','nuxe_res','witchy','material_library','output_root')

def _assembled_frame(query):
    m=re.fullmatch(r'frame_(\d+)',query or '',re.I)
    if not m:return None
    ident=m.group(1)
    return dict(id=query,name_en=f'Assembly convenience label {ident}',namespace='assembled_frame',category='ac_assembly_sample',is_game_id=False,sources=[],components=[f'HD_M_{ident}',f'BD_M_{ident}',f'AM_M_{ident}',f'LG_M_{ident}'],limitations=['Resources are not yet inspected. Same-ID defaults may be overridden per slot; coverage is not permission.'],operations=['export_dynamic_frame'],operation_status={'export_dynamic_frame':'attemptable'},required_inputs={'export_dynamic_frame':['Game OR expanded roots OR explicit models/HKX/skeleton files','parts overrides optionally select mixed original resource IDs','configured dynamic runtime']},related_workflows=[{'operation':'export_dynamic_frame','status':'attemptable','document':'docs/dynamic-pipeline.md'}],next_step='Supply resources and try export. Actual errors, partials and validation are reported.')

def capabilities(query=None):
    from .workflows import workflows
    w=workflows()
    r=lookup_asset(query) if query else dict(schema_version=1,status='ready',results=[lookup_asset(k)['results'][0] for k in dict.fromkeys([*PROFILES,*w['dynamic_frames']])])
    synthetic=_assembled_frame(query) if query and not r['results'] else None
    if synthetic:
        r=dict(schema_version=1,status='unique',query=query,namespace='assembled_frame',total=1,truncated=False,results=[synthetic],next_action=None,catalog_version=r.get('catalog_version'),coverage='assembled-frame pattern; not a complete game database')
    for e in r['results']:
        p=PROFILES.get(e['id'])
        e['profile']=p
        if e['id'] in w['dynamic_frames'] or re.fullmatch(r'frame_[0-9]+',e['id']):
            e['dynamic_profile']=dict(clips=w['clips'],master_skeleton_archive=w['master_skeleton_archive'],native_sampling='Read each HKX sample intervals/duration; source may be 30 or 60 Hz',preview_scene_fps=30,conventions=w['conventions'],frame_pattern=w.get('dynamic_frame_pattern'),clip_pattern=w.get('clip_pattern'))
            e['dynamic_profile'].update(assembly_methods=w.get('assembly_methods'),default_assembly_method='geometry',blender_adapters=w.get('blender_adapters'),verification_document='docs/verification.md',assembly_document='docs/assembly-pipeline.md')
    r['input_modes']=['input_root: already unpacked FLVER/DDS/material library','game_dir: targeted Nuxe + Witchy extraction into fresh job cache']
    r['discovery']=dict(assets='discover-assets: existing Nuxe index or expanded files',animations='list-clips: actual archive HKX metadata',assembly='check-assembly: parent/local/world and weighted dependencies; optional diagnostic',document='docs/discovery.md')
    r['dynamic_input_contract']=dict(operation='export_dynamic_frame',status='attemptable',parts='frame_NUMBER defaults OR parts slot overrides OR models JSON',clips='IDs OR clip_spec with explicit hkx/compendium paths',permission='No catalog/coverage whitelist; unknown inputs are attempted.',result='Read failures, completion.output_valid, actual animation root_motion and downstream limits.',document='docs/dynamic-pipeline.md')
    r['limits']=['Existing weighted AC algorithm is attempted; no new Boss algorithm, material research or Unreal automation.', 'Materials remain partial/approximate; T47 orientation boundaries remain.']
    return r

def load_config(path=None):
    value=path or os.environ.get('ACBRIDGE_CONFIG')
    if not value:raise BridgeError('config_required','Pass --config PATH or set ACBRIDGE_CONFIG; copy config.example.json and supply local tools. Lookup needs no configuration.')
    p=Path(value).expanduser().resolve()
    try:data=json.loads(p.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError) as ex:raise BridgeError('invalid_config',str(ex),path=str(p)) from ex
    if not isinstance(data,dict):raise BridgeError('invalid_config','Configuration must be a JSON object.')
    unknown=set(data)-set(PATH_KEYS)-{'schema_version'}
    if unknown:raise BridgeError('invalid_config','Unknown keys: '+', '.join(sorted(unknown)))
    for k in PATH_KEYS:
        if k in data:
            if not isinstance(data[k],str) or not data[k]:raise BridgeError('invalid_config',k+' must be a nonempty path string.')
            v=Path(data[k]).expanduser()
            data[k]=str((p.parent/v).resolve() if not v.is_absolute() else v.resolve())
    if 'output_root' not in data:raise BridgeError('invalid_config','Set output_root to a dedicated jobs directory.')
    data['_config']=str(p)
    return data

def doctor(config=None,input_mode='expanded',workflow='dynamic'):
    if input_mode not in ('expanded','game') or workflow not in ('dynamic','static'):raise BridgeError('invalid_arguments','Choose input_mode expanded|game and workflow dynamic|static.')
    c=load_config(config)
    checks={}
    for k in ('blender','importer','validator','adapter'):
        p=Path(c.get(k,'__missing__'))
        checks[k]=p.is_dir() and (p/'__init__.py').is_file() if k=='importer' else p.is_file()
    checks['adapter_dll']=Path(c.get('adapter','__missing__')).with_suffix('.dll').is_file()
    for k in ('node','dotnet'):checks[k]=shutil.which(k) is not None
    from importlib.util import find_spec
    for k in ('PIL','numpy'):checks[k]=find_spec(k) is not None
    extra={k:Path(c.get(k,'__missing__')).exists() for k in ('nuxe_bridge','nuxe_res','witchy')}
    dynamic_checks=dict(numpy=find_spec('numpy') is not None,scipy=find_spec('scipy') is not None,node=checks['node'],validator=checks['validator'],vendored_decoder=(Path(__file__).parent/'vendor/t47/vendor/decode_keys.py').is_file())
    selected=dict(dynamic_checks if workflow=='dynamic' else checks)
    if input_mode=='game':selected.update(extra)
    missing=[k for k,v in selected.items() if not v]
    return dict(schema_version=1,status='ready' if not missing else 'error',input_mode=input_mode,workflow=workflow,required_checks=selected,missing=missing,checks=checks,game_mode_checks=extra,dynamic_checks=dynamic_checks,dynamic_ready=all(dynamic_checks.values()),optional_blender=dict(available=checks['blender'],needed_for='Blender numerical validation, asset.blend and --render-preview; not needed for GLB generation'),output_root=c['output_root'],config=c['_config'],next_action=('Install the selected Python extras and Node/glTF Validator; see packaged docs/installation.md. Game extraction additionally needs existing NuxeBridge/Nuxe index/Witchy. Expanded dynamic --input-root needs none of Adapter.exe, NuxeBridge.exe or WitchyBND.exe.' if missing else None))

def under(a,b):return a==b or b in a.parents

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def inspect_result(output):
    status_file=Path(output).resolve()/'status.json'
    if status_file.is_file() and json.loads(status_file.read_text(encoding='utf-8')).get('operation')=='export_dynamic_frame':
        from .dynamic import inspect_dynamic_result
        return inspect_dynamic_result(output)
    out=Path(output).resolve();p=out/'asset.glb'
    try:
        with p.open('rb') as f:
            magic,version,length=struct.unpack('<4sII',f.read(12))
            size,kind=struct.unpack('<II',f.read(8))
            if magic!=b'glTF' or version!=2 or length!=p.stat().st_size or kind!=0x4e4f534a or size>length-20:
                raise ValueError('Invalid GLB v2 header/length/JSON chunk.')
            g=json.loads(f.read(size).decode('utf-8'))
        if not g.get('meshes'):raise ValueError('GLB has no meshes.')
        if any(x.get('uri') and not x['uri'].startswith('data:') for t in ('buffers','images') for x in g.get(t,[])):
            raise ValueError('GLB depends on external files.')
        validation=json.loads((out/'validation.json').read_text(encoding='utf-8'))
        saved=out/'result.json';previous={}
        if saved.is_file():
            previous=json.loads(saved.read_text(encoding='utf-8'))
            if previous.get('operation')=='export_static' and previous.get('completion',{}).get('output_valid') is False:
                if previous.get('glb_sha256') and digest(p)!=previous['glb_sha256']:raise ValueError('Retained GLB changed since export validation.')
                return dict(schema_version=1,status='partial',operation='inspect',export_status=previous['status'],output=str(out),completion=previous['completion'],glb=dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p),meshes=len(g['meshes'])),validation=dict(errors=validation['issues']['numErrors'],warnings=validation['issues']['numWarnings']),failures=previous.get('failures',[]),full_report=str(saved),note='Retained candidate; failed consumer checks remain unresolved. Inspecting it does not promote it to accepted output.')
        readback=json.loads((out/'readback.json').read_text(encoding='utf-8'))
        geometry=json.loads((out/'geometry.json').read_text(encoding='utf-8'))
        if validation['issues']['numErrors'] or not readback['blend_readable'] or not readback['blend_images_packed'] or readback['triangles']!=geometry['triangles']:
            raise ValueError('Validator/readback evidence failed.')
        return dict(schema_version=1,status='ready',export_status=previous.get('status'),completion=previous.get('completion'),output=str(out),glb=dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p),meshes=len(g['meshes']),images=len(g.get('images',[])),embedded=True),validation=dict(errors=validation['issues']['numErrors'],warnings=validation['issues']['numWarnings']),readback=readback)
    except (OSError,ValueError,KeyError,struct.error) as ex:
        raise BridgeError('invalid_result',str(ex),output=str(out)) from ex

def export_static(asset,output,input_roots=None,game_dir=None,config=None,timeout=600):
    explicit=Path(asset).expanduser()
    if explicit.suffix.lower()=='.flver':
        if game_dir:raise BridgeError('input_required','An explicit FLVER uses expanded input_roots for textures/materials; omit game_dir.')
        if not explicit.is_file():raise BridgeError('input_missing','Explicit FLVER does not exist.',path=str(explicit.resolve()))
        input_roots=[str(explicit.resolve().parent),*(input_roots or [])]
        asset=explicit.stem
    match=lookup_asset(asset)
    ident=match['results'][0]['id'] if match['status']=='unique' else asset
    profile=PROFILES.get(ident)
    if explicit.suffix.lower()=='.flver' and (not profile or profile['type']!='weapon'):
        profile=dict(type='weapon',exclude_mtd=[],label='Explicit single FLVER using existing single-model backend; binding is attempted, not inferred')
    if not profile:
        if re.fullmatch(r'WP_[A-Z]_\d+',ident,re.I):
            ident=ident.upper();profile=dict(type='weapon',exclude_mtd=[],label='Explicit original resource attempt; no catalog registration required')
        elif re.fullmatch(r'frame_\d+',ident,re.I):
            ident=ident.lower();profile=dict(type='ac',exclude_mtd=[],label='Same-ID static assembly attempt; raw bind-space')
        elif explicit.suffix.lower()=='.flver':
            profile=dict(type='weapon',exclude_mtd=[],label='Explicit single FLVER using existing static single-model path')
        else:raise BridgeError('resource_identity_required','Supply a unique known profile, WP_L/R_NUMBER, frame_NUMBER, or an explicit FLVER path. The static backend supports AC assemblies and single FLVER attempts.',lookup=match)
    namespace=match['results'][0]['namespace'] if match['status']=='unique' else 'explicit_resource'
    if isinstance(timeout,bool) or not isinstance(timeout,int) or not 10<=timeout<=3600:raise BridgeError('invalid_timeout','timeout must be 10..3600 seconds per external stage.')
    roots=[Path(p).expanduser().resolve() for p in (input_roots or [])]
    if bool(roots)==bool(game_dir):raise BridgeError('input_required','Provide either one or more input_roots OR game_dir.')
    inputs=roots if roots else [Path(game_dir).expanduser().resolve()]
    for p in inputs:
        if not p.is_dir():raise BridgeError('input_missing','Input directory does not exist.',path=str(p))
    c=load_config(config);out=Path(output).expanduser().resolve();allowed=Path(c['output_root'])
    if not under(out,allowed) or out==allowed:raise BridgeError('output_outside_root','Output must be a fresh child directory of configured output_root.',output=str(out),output_root=str(allowed))
    if out.exists():raise BridgeError('output_exists','Choose a fresh output directory; existing jobs are never overwritten.',output=str(out))
    protected=inputs+[Path(v) if Path(v).is_dir() else Path(v).parent for k,v in c.items() if k in PATH_KEYS and k!='output_root']+[Path(__file__).parent]
    if any(under(out,p) or under(p,out) for p in protected):raise BridgeError('path_overlap','Output overlaps input/tool/source directory.',output=str(out))
    health=doctor(config,'game' if game_dir else 'expanded','static')
    if health['status']!='ready':raise BridgeError('runtime_missing','Required runtime is missing; run doctor.',checks=health)
    if game_dir and not all(health['game_mode_checks'].values()):raise BridgeError('extraction_runtime_missing','Game mode needs nuxe_bridge, nuxe_res and witchy.',checks=health['game_mode_checks'])
    backend=Path(__file__).parent/'vendor/fsbridge/src/fs_asset_bridge.py'
    args=[sys.executable,str(backend),'convert','--type',profile['type'],'--id',ident,'--output',str(out), '--timeout',str(timeout)]
    if explicit.suffix.lower()=='.flver':args+=['--source-flver',str(explicit.resolve())]
    for k in ('blender','importer','validator'):args+=['--'+k,c[k]]
    if game_dir:
        args+=['--game-dir',str(inputs[0]),'--nuxe-res',c['nuxe_res'],'--witchy',c['witchy']]
    else:
        for p in roots:args+=['--input-root',str(p)]
        if c.get('material_library'):args+=['--material-library',c['material_library']]
    for mtd in profile['exclude_mtd']:args+=['--exclude-mtd',mtd]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',ACBRIDGE_OUTPUT_ROOT=str(allowed),ACBRIDGE_ADAPTER=c['adapter'],ACBRIDGE_NUXE_BRIDGE=c.get('nuxe_bridge',''))
    allowed.mkdir(parents=True,exist_ok=True)
    fd,logname=tempfile.mkstemp(prefix='.acbridge-',suffix='.log',dir=allowed);os.close(fd)
    timedout=False
    with open(logname,'w',encoding='utf-8') as log:
        # MCP owns stdin. Native processing must never inherit its protocol pipe.
        proc=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=allowed)
        try:code=proc.wait(timeout=timeout*12+60)
        except subprocess.TimeoutExpired:
            timedout=True
            if os.name=='nt':subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
            else:proc.kill()
            proc.wait();code=1
    if out.is_dir():
        destination=out/'logs/entrypoint.log';destination.parent.mkdir(exist_ok=True)
        shutil.move(logname,destination);logname=str(destination)
    status_path=out/'status.json'
    try:report=json.loads(status_path.read_text(encoding='utf-8')) if status_path.exists() else {}
    except (OSError,ValueError):report={}
    if code or report.get('status') not in ('partial','ready'):
        available={p.name:str(p) for p in out.iterdir() if p.is_file()} if out.is_dir() else {}
        details=dict(input=[str(p) for p in inputs],output=str(out),backend_exit_code=code,failed_stage=report.get('failed_stage'),status_file=str(status_path),log=logname,outputs=available)
        message=report.get('error','Backend did not produce a validated result; inspect the execution log.')
        if report.get('failed_stage')=='blender-readback':
            tail=(out/'logs/blender-readback.log').read_text(encoding='utf-8',errors='replace')[-2400:]
            details['consumer_log_tail']=tail
            count=re.search(r'AssertionError: \((\d+), (\d+)\)',tail)
            if count:
                details['consumer_triangles_actual']=int(count[1]);details['expected_triangles']=int(count[2])
                message=f'Blender readback triangle count differs: actual {count[1]}, expected {count[2]}. GLB retained; consumer validation did not pass.'
        failure=dict(code='conversion_timeout' if timedout else 'conversion_failed',message=message,**details)
        validator=out/'validation.json'
        if (out/'asset.glb').is_file() and validator.is_file():
            try:gltf_valid=json.loads(validator.read_text(encoding='utf-8'))['issues']['numErrors']==0
            except (ValueError,KeyError):gltf_valid=False
            if gltf_valid:
                result=dict(schema_version=1,status='partial',operation='export_static',asset=ident,namespace=namespace,output=str(out),outputs=available,glb_sha256=digest(out/'asset.glb'),completion=dict(output_valid=False,gltf_validator_passed=True,consumer_validation_passed=False),failures=[failure],warnings=['A real GLB was retained and passed Validator, but subsequent processing/consumer checks failed. Not an accepted full conversion.'])
                (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');return result
        raise BridgeError(failure.pop('code'),failure.pop('message'),**failure)
    checked=inspect_result(str(out))
    result=dict(schema_version=1,status=report['status'],operation='export_static',asset=ident,namespace=namespace,input=dict(mode='game_dir' if game_dir else 'input_root',paths=[str(p) for p in inputs]),output=str(out),outputs={k:str(out/k) for k in report['outputs']},inspection=checked,warnings=report['warnings'],visual_acceptance='not performed; static legacy material profile, not T52/T53-R2 lookdev',backend='vendored FS Asset Bridge v0.4; original parsers/importer/exporter reused')
    result['completion']=dict(output_valid=True,gltf_validator_passed=True,consumer_validation_passed=True)
    result['failures']=[]
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
