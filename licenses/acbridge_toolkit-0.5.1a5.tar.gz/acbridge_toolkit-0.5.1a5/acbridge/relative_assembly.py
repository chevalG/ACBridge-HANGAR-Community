# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
# T66 2026-10-26: licensing notice only; original executable code retained.
# Applies only to project-controlled contributions; see NOTICE and docs/licensing.md.
"""T61-R1 bounded ownership-and-anchor assembly; no mesh translation.

Parts carry repeated authoring scaffolds. The torso owns BD_Root descendants,
head owns Neck descendants, each arm owns its Clavicle descendants. Legs lead
the common root/waist. Each owned subtree is expressed relative to its actual
attachment frame. Unowned scaffolding is measured and reported, never merged
as a second authority over the leader's joint.
"""
import json
from pathlib import Path
import numpy as np
from acbridge.lookup import BridgeError

SLOTS=('bd','hd','am','lg')
ANCHORS={'bd':('BD_Root',),'hd':('Neck',),'am':('L_Clavicle','R_Clavicle')}

def subtree(parents,root):
    out=set()
    for n in parents:
        p=n
        while p is not None:
            if p==root:out.add(n);break
            p=parents[p]
    return out

def assemble_rig(core,model,proof_path):
    models=core.load(core.MODELS);entry=models[model]['parts']
    names,source_parents,cl,C,sk=core.skeleton(core.SOURCE_SKELETON,core.SOURCE_COMPENDIUM)
    cache=core.load(core.SOURCE_CACHE)
    if names!=cache['bones'] or list(sk['parentIndices'])!=cache['parentIndices']:raise BridgeError('source_skeleton_changed','Source skeleton cache mismatch.')
    if max(float(np.abs(cl[n]-core.mat(v['translation'],v['rotation'],v['scale'])).max()) for n,v in zip(names,cache['referencePose']))>=1e-5:raise BridgeError('source_skeleton_changed','Source local reference matrices differ from decoded skeleton cache.')
    rigs={p:core.skeleton(row['hkx'],row['comp']) for p,row in entry.items()}
    # Actual legs establish the driver reference scaffold. Weighted upper body
    # has no authority to replace the leg root with its authoring duplicate.
    U=dict(rigs['lg'][3]);parent_map=dict(rigs['lg'][1]);owner={n:'lg' for n in U};proof=[]
    for part in ('bd','hd','am'):
        pn,pa,pl,pw,_=rigs[part];owned=set()
        for anchor in ANCHORS[part]:
            if anchor not in pw or anchor not in U:raise BridgeError('attachment_frame_missing','Actual attachment frame not found; no synthetic bone introduced.',part=part,anchor=anchor)
            branch=subtree(pa,anchor);owned|=branch
            shift=U[anchor]@np.linalg.inv(pw[anchor])
            attached={n:shift@pw[n] for n in branch}
            anchor_error=float(np.abs(attached[anchor]-U[anchor]).max())
            conflicts=[]
            for n in branch:
                if n in U and n!=anchor:
                    error=float(np.abs(attached[n]-U[n]).max())
                    if error>1e-4 or pa[n]!=parent_map[n]:conflicts.append(dict(bone=n,max_abs=error,old_parent=parent_map[n],new_parent=pa[n]))
            if conflicts:raise BridgeError('owned_subtree_conflict','Two owned deforming subtrees disagree after measured anchor normalization.',part=part,anchor=anchor,conflicts=conflicts)
            if anchor_error>1e-4:raise BridgeError('attachment_alignment_failed','Anchor normalization residual exceeds unchanged tolerance.',residual=anchor_error)
            for n in pn:
                if n in branch:
                    if n not in U:U[n]=attached[n];parent_map[n]=pa[n];owner[n]=part
                    # Existing anchor/reference frames remain the leader's exact
                    # matrices; only measured equal owned overlaps can share.
            proof.append(dict(part=part,anchor=anchor,leader='lg' if part=='bd' else 'bd',subtree_bones=len(branch),transform=shift.tolist(),anchor_residual=anchor_error,geometry_transform='identity',max_owned_overlap_residual=max((float(np.abs(attached[n]-U[n]).max()) for n in branch if n in U),default=0)))
        # A positive mesh weight outside the owned branch is a real unresolved
        # dependency, not permission to silently attach it elsewhere.
        f=core.read_flver(Path(entry[part]['flver']));weighted=set()
        for mesh in f.inflate():
            w=np.asarray(mesh.vertices.bone_weights);bi=np.asarray(mesh.vertices.bone_indices,int)
            weighted.update(f.bones[i].name for i in set(bi[w>0].tolist()))
        if weighted-owned:raise BridgeError('weight_outside_owned_subtree','Weighted bones need an explicit assembly relationship outside the present branch model.',part=part,bones=sorted(weighted-owned))
    parents=dict(source_parents);parents.update({n:parent_map[n] for n in U if n not in parents})
    # Preserve the old source-first ordering, so baseline names and payloads can
    # be compared without confusing array reordering with changed skinning.
    desired=list(names)
    for part in SLOTS:
        desired.extend(n for n in rigs[part][0] if n in U and n not in desired)
    order=[];seen=set()
    def visit(n):
        if n in seen:return
        p=parents[n]
        if p:visit(p)
        seen.add(n);order.append(n)
    for n in desired:visit(n)
    bind={}
    for n in order:
        if n in U:bind[n]=U[n]
        elif parents[n]:bind[n]=bind[parents[n]]@cl[n]
        else:bind[n]=C[n]
    ignored=[]
    for part,(_,pa,_,pw,_) in rigs.items():
        owned=set(pw) if part=='lg' else set().union(*(subtree(pa,a) for a in ANCHORS[part]))
        for n in sorted(set(pw)-owned):
            if n in bind:
                error=float(np.abs(pw[n]-bind[n]).max())
                if error>1e-4:ignored.append(dict(part=part,bone=n,max_raw_authoring_difference=error,role='Unowned repeated authoring scaffold; leader frame used by explicit component ownership'))
    data=dict(method='Relative assembly of owned joint subtrees using actual HKX attachment frames',model=model,tolerance=1e-4,geometry_unchanged=True,anchors=proof,unowned_authoring_scaffold_differences=ignored,owners=owner,bind={n:bind[n].tolist() for n in order},parents=parents,source_reference={n:C[n].tolist() for n in names},scope='Retains T47 relative-local animation rule; not a claim of closed-source engine equivalence. No direct-FK orientation override, FootIK or extra game behavior.')
    Path(proof_path).write_text(json.dumps(data,indent=2),encoding='utf-8')
    core.ASSEMBLY_PROOF=data
    return entry,order,parents,cl,C,bind,sk
