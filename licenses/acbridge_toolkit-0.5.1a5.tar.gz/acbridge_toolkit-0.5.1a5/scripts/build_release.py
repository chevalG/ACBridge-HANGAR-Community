"""Build complete source + wheel; invoke from a source tree with build installed."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
res=R/'acbridge/resources'
for n in ['README.md','config.example.json','LICENSE','NOTICE']:shutil.copyfile(R/n,res/n)
for p in (R/'docs').glob('*.md'):shutil.copyfile(p,res/'docs'/p.name)
for p in (R/'licenses').iterdir():
    if p.is_file():shutil.copyfile(p,res/'licenses'/p.name)
matrix=[]
public_files=list((R/'acbridge').rglob('*'))
for folder in ['docs','licenses','tests']:public_files.extend((R/folder).rglob('*'))
public_files.extend(R/n for n in ['LICENSE','NOTICE','README.md','pyproject.toml','config.example.json','acbridge.py','acbridge.cmd','MANIFEST.in','scripts/build_release.py','scripts/catalog_remediate.py','scripts/generate_builtin_name_index.py'])
for p in sorted(public_files):
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    rel=p.relative_to(R).as_posix()
    license='GPL-3.0-only';origin='ACBridge project-controlled contribution; author authority confirmation pending'
    if p.name in ['flver.py','flver_utils.py'] and 'flver_parser' in p.parts:
        license='GPL-3.0-or-later';origin='shintheweapon/Blender-flver-importer @ 29c97bcc19ff4f1c251ab2a5000b8af82a751aff; unmodified parser'
    elif p.name in ['spline_decode.py','decode_keys.py']:
        origin='Python adaptation of Meowmaritus/SoulsAssetPipeline @ d11caf989c917c7a43e2c7559915b1c5af218153, HavokLib @ ef5d5c6f5ab8d7f32cb4e8983300b8db61e4dc6b; upstream GPL-3.0-or-later; local GPLv3 contributions'
    elif p.name=='tag0c.py':origin='TagTools/Havoc @ 23302ac18562204a5d5cc552b97339ef6a99964f; upstream MIT + local GPLv3 extensions';license='MIT AND GPL-3.0-only'
    elif 'fsbridge' in p.parts:origin='ACBridge fs-asset-bridge T20-B v0.4 via T62/T64; current PROVENANCE inventory; historical modifier authority pending'
    elif p.name=='assets.json':origin='T66 numeric/hash seed catalog; docs/catalog-provenance.md; residual data review pending';license='data rights UNRESOLVED; no blanket grant for third-party facts/text'
    elif p.name=='name_index.json':origin='T66-N equipment name index: per-entry FMG designation + numeric facts provenance, docs/name-index.md; regenerable via scripts/generate_builtin_name_index.py; residual data rights review pending';license='data rights UNRESOLVED; designation strings and facts pending review; no blanket grant'
    elif 'licenses' in p.parts or p.name in ['LICENSE','NOTICE']:license='license/notice text; original terms preserved';origin='mirrored canonical root notices'
    if p.name=='SOURCE-MATRIX.json':continue
    matrix.append(dict(path=rel,sha256=sha(p),license=license,source=origin,publication_status='review candidate; not final clearance'))
write(R/'SOURCE-MATRIX.json',json.dumps(matrix,indent=2))
subprocess.run([sys.executable,'-m','build'],cwd=R,check=True)
