# SPDX-FileCopyrightText: 2026 ACBridge project contributors
# SPDX-License-Identifier: GPL-3.0-only
"""Maintainer: regenerate the shipped builtin equipment name index.

Takes explicit paths to a legally owned local extraction (FMG XML root,
regulation PARAM XML root, optional BinderKeys archive index) and writes
acbridge/data/name_index.json plus an evidence file. Never bundles the
input files; records their digests only. Any user can regenerate an
equivalent index locally with `acbridge build-name-index`.
"""
import argparse
import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from acbridge.nameindex_build import build_name_index  # noqa: E402

DISTRIBUTION_BASIS = (
    'Each entry maps one FMG item designation string (model code and/or unit name, '
    'for example SB-033M MORLEY) to numeric facts (param row id, equipModelId, equip '
    'flags) and an archive path citation. Designation strings are individual short '
    'identifiers; descriptive text (FMG description files) is never read or included. '
    'Selection is mechanical: every FMG-named equippable row in the four frame slots '
    'and the hand/shoulder weapon ranges of the verified local extraction. The index '
    'is regenerable from any legally owned copy via acbridge build-name-index. '
    'Publication remains gated on the review described in docs/name-index.md; this '
    'file makes no claim of final legal clearance.'
)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--msg-root', required=True, help='Directory containing 武器名/防具名 fmg.xml')
    ap.add_argument('--regulation', required=True, help='Directory containing EquipParam XML')
    ap.add_argument('--archive-index', help='BinderKeys Data0.txt (or its Nuxe res root) for stem verification')
    ap.add_argument('--output', default=str(ROOT / 'acbridge/data/name_index.json'))
    ap.add_argument('--evidence', default=str(ROOT / 'evidence/name-index/generation.json'))
    ap.add_argument('--index-version', default='T66N.1-builtin-engus')
    a = ap.parse_args()

    index, report = build_name_index(a.msg_root, a.regulation, a.archive_index)
    index.update(
        index_version=a.index_version,
        builtin=True,
        scope=('Player-equippable AC frame parts (BD/HD/AM/LG) and hand/shoulder weapons; '
               f'{report["language"]} display designations'),
        distribution_basis=DISTRIBUTION_BASIS,
        rights_status='review candidate; no final legal clearance claimed',
        generated=date.today().isoformat(),
    )
    if report['unresolved_stems'] and index['builtin']:
        raise SystemExit(f'Refusing builtin generation with unresolved stems: {report["unresolved_stems"][:3]}')

    out = Path(a.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding='utf-8', newline='\n')

    import hashlib
    evidence = dict(generation_report=report, output=dict(path=str(out), sha256=hashlib.sha256(out.read_bytes()).hexdigest()),
                    distribution_basis=DISTRIBUTION_BASIS, index_version=a.index_version)
    ev = Path(a.evidence)
    ev.parent.mkdir(parents=True, exist_ok=True)
    ev.write_text(json.dumps(evidence, ensure_ascii=False, indent=1), encoding='utf-8', newline='\n')
    print(json.dumps(dict(entries=len(index['entries']), weapon_rows=report['weapon_rows'],
                          part_rows=report['part_rows'], distinct_names=report['distinct_display_names'],
                          unresolved=report['unresolved_stems'], output=str(out), evidence=str(ev)),
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
