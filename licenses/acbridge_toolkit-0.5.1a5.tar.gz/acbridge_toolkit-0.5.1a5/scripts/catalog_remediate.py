"""Strip unverified display labels from a supplied pre-T66 catalog.

No game files are read. The baseline is an explicit local review input; never
include that baseline's display strings or machine paths in release archives.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remediate(baseline):
    data = copy.deepcopy(baseline)
    removals = []

    def strip(value, path):
        if isinstance(value, dict):
            for key in list(value):
                child = path + '/' + key
                if key == 'paramdexName' or (key == 'text' and path.startswith('/sources/')):
                    removals.append(child)
                    del value[key]
                else:
                    strip(value[key], child)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                strip(child, path + '/' + str(index))

    strip(data, '')
    source_rows = []
    for source_id, source in data['sources'].items():
        old = baseline['sources'][source_id]
        if old['kind'] == 'game_param_with_community_labels':
            source['kind'] = 'game_param_numeric_facts'
        if old['kind'] == 'game_text':
            # This remains a citation/hash of an excluded name source.
            source['kind'] = 'game_text_reference_only'
            source['fields'] = {}
            source['content_included'] = False
        if old['kind'] == 'community_reference':
            source['content_included'] = False
        if old['kind'] == 'tool_archive_path_index':
            source['reference_attribution'] = {
                'project': 'JKAnderson/BinderKeys',
                'license': 'Apache-2.0',
                'fixed_ref_from_T65': 'b95a32c5',
                'upstream': 'https://github.com/JKAnderson/BinderKeys',
                'scope': 'Factual path citation and file digest only; index file not bundled.'
            }
        source_rows.append({
            'source_id': source_id,
            'path': source['path'], 'selector': source['selector'],
            'sha256': source.get('sha256'),
            'removed_fields': sorted(set(old.get('fields', {})) - set(source.get('fields', {}))),
            'retained_fields': sorted(source.get('fields', {})),
        })
    entry_rows = []
    for old, entry in zip(baseline['entries'], data['entries']):
        entry['name_en'] = entry['id']
        entry['aliases'] = []
        entry['alias_origin'] = 'T66: human display names and aliases excluded pending source rights review'
        changed = ['name_en', 'aliases', 'alias_origin']
        removed = []
        if entry.get('name_basis') == 'community_paramdex_label':
            entry['name_basis'] = 'technical_resource_id_only'
            changed.append('name_basis')
            if 'label_confidence' in entry:
                del entry['label_confidence']
                removed.append('label_confidence')
            entry['limitations'] = [
                'Display name excluded; no verified NpcParam-to-FMG name mapping.',
                'Resource identity references do not establish redistribution rights.'
            ]
            if entry['id'] == 'c4210':
                entry['limitations'].append('isDummyChr=1 is recorded in the referenced numeric parameter facts; character name remains UNKNOWN.')
            changed.append('limitations')
        entry_rows.append({
            'id': entry['id'], 'namespace': entry['namespace'],
            'replaced_fields': changed, 'removed_fields': removed,
            'removed_alias_count': len(old['aliases']),
            'retained_sources': entry['sources'],
            'retained_resource_path': entry.get('resource_path'),
            'retained_components': entry.get('components'),
        })
    data['catalog_version'] = 'T66.1-technical-ids'
    data['coverage'] = '24 bounded technical resource records; human display names and aliases excluded'
    data['redistribution'] = (
        'REVIEW REQUIRED: unverified community labels and game display strings excluded. '
        'Remaining numeric facts, paths, digests and citations are not an assertion of third-party authorization; '
        'project owner must review any residual data/database rights before publication.'
    )
    evidence = {
        'task': 'T66 catalog label removal',
        'entry_count': len(data['entries']), 'source_count': len(data['sources']),
        'paramdexName_removed': sum(p.endswith('/paramdexName') for p in removals),
        'source_text_removed': sum(p.endswith('/text') for p in removals),
        'name_en_replaced': len(entry_rows),
        'aliases_removed': sum(r['removed_alias_count'] for r in entry_rows),
        'entries': entry_rows, 'sources': source_rows,
        'recursive_removed_paths': removals,
        'remaining_data_rights_status': 'REVIEW REQUIRED; no authorization inferred from factual selection or removal',
    }
    # Invariants: all lookup IDs, references, source digests, numeric values and
    # resource/assembly locators survive. Only labels/metadata above change.
    assert len(data['entries']) == 24
    assert list(data['sources']) == list(baseline['sources'])
    for key, source in baseline['sources'].items():
        for field in ('path', 'selector', 'sha256'):
            assert data['sources'][key].get(field) == source.get(field), (key, field)
        for field, value in source.get('fields', {}).items():
            if isinstance(value, (int, float)) or (isinstance(value, str) and value.lstrip('-').isdigit()):
                assert data['sources'][key]['fields'][field] == value, (key, field)
    for old, new in zip(baseline['entries'], data['entries']):
        for field in ('id', 'namespace', 'category', 'is_game_id', 'sources', 'resource_path', 'components', 'side'):
            assert old.get(field) == new.get(field), (old['id'], field)
    assert 'paramdexName' not in json.dumps(data)
    return data, evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True, help='Pre-T66 assets.json; read only')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    assert args.baseline.resolve() != args.output.resolve(), 'Never overwrite baseline'
    original = json.loads(args.baseline.read_text(encoding='utf-8'))
    data, evidence = remediate(original)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    evidence['baseline_sha256'] = digest(args.baseline)
    evidence['output_sha256'] = digest(args.output)
    args.evidence.parent.mkdir(parents=True, exist_ok=True)
    args.evidence.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: evidence[k] for k in ('entry_count','source_count','paramdexName_removed','source_text_removed','name_en_replaced','aliases_removed','output_sha256')}))


if __name__ == '__main__':
    main()
