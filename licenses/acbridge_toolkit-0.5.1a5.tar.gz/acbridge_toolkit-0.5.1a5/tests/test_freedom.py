import json,tempfile,unittest
from pathlib import Path
from acbridge.dynamic import select_profile
from acbridge.dynamic_worker import discover
import test_dynamic_discovery as fixtures

class FreedomTests(unittest.TestCase):
    def test_arbitrary_labels_are_not_registry_permission(self):
        self.assertEqual(select_profile('my-mixed-ac',['locally_named_motion'])[0],'my-mixed-ac')
        self.assertEqual(select_profile('frame_98765',['a777_123456'])[0],'frame_98765')
    def test_failed_clip_keeps_other_resolved_sources(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixtures.DiscoveryTests().tree(root);failures=[]
            entry,master,clips=discover([root],'frame_1400',['missing_clip','a000_020100'],failures=failures)
            self.assertEqual(list(clips),['a000_020100']);self.assertEqual(failures[0]['category'],'input_resolution')
    def test_explicit_file_names_and_mixed_slots_are_not_an_id_gate(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixtures.DiscoveryTests().tree(root)
            parts={}
            for n,p in enumerate(('bd','hd','am','lg')):
                folder=root/(p+'_m_1400-partsbnd-dcx');flver=next(folder.glob('*.FLVER'))
                renamed=root/('different-source-'+str(n)+'.flver');renamed.write_bytes(flver.read_bytes())
                parts[p]=dict(flver=str(renamed),hkx=str(next(folder.rglob('Skeleton.hkx'))),comp=str(root/'bd_m_1400-partsbnd-dcx/BD_M_1400.compendium'))
            models=root/'models.json';models.write_text(json.dumps({'parts':parts}))
            hkx=root/'chr/c0000_a000_01-anibnd-dcx-wanibnd/a000_020100.hkx'
            entry,master,clips=discover([root],'my-mix',['custom-clip'],models,{'custom-clip':{'hkx':str(hkx),'compendium':str(hkx.parent/'a000_01.compendium')}})
            self.assertEqual(len(entry['parts']),4);self.assertIn('custom-clip',clips)
