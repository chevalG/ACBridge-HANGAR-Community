import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

from acbridge.lookup import catalog, lookup_asset

ROOT = Path(__file__).resolve().parents[1]

def cli(*args):
    p = subprocess.run([sys.executable, str(ROOT/'acbridge.py'), *args], capture_output=True, text=True, encoding='utf-8')
    return p, json.loads(p.stdout) if p.stdout.strip().startswith('{') else {}

class LookupContract(unittest.TestCase):
    def test_technical_id_normalization(self):
        for query, expected in [('c6100','c6100'), ('c 6100','c6100'), ('wp-r-1610','WP_R_1610'), ('bd m 1010','BD_M_1010')]:
            with self.subTest(query=query):
                p, r=cli('lookup',query)
                self.assertEqual(p.returncode,0,p.stderr)
                self.assertEqual(r['status'],'unique')
                self.assertEqual(r['results'][0]['id'],expected)
                self.assertTrue(r['results'][0]['sources'])

    def test_ambiguity_and_limit_do_not_choose(self):
        # Synthetic project-owned labels exercise collision handling without
        # reintroducing removed game/community display strings to the catalog.
        data = catalog()
        data['entries'] = data['entries'][:2]
        for entry in data['entries']:
            entry['name_en'] = 'Technical reference sample'
        with patch('acbridge.lookup.catalog', return_value=data):
            r = lookup_asset('Technical reference sample', limit=1)
        self.assertEqual(r['status'],'ambiguous')
        self.assertGreaterEqual(r['total'],2)
        self.assertTrue(r['truncated'])

    def test_fuzzy_suggests_without_confirming(self):
        p,r=cli('lookup','wp r 161')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(r['status'],'suggestions')
        self.assertEqual(r['results'][0]['id'],'WP_R_1610')

    def test_public_catalog_uses_only_technical_display_labels(self):
        data = catalog()
        self.assertEqual(len(data['entries']), 24)
        for entry in data['entries']:
            self.assertEqual(entry['name_en'], entry['id'])
            self.assertEqual(entry['aliases'], [])
        self.assertNotIn('paramdexName', json.dumps(data))
        for source in data['sources'].values():
            if source['kind'] == 'game_text_reference_only':
                self.assertEqual(source['fields'], {})
                self.assertFalse(source['content_included'])

    def test_project_sample_separate_namespace(self):
        p,r=cli('lookup','frame_1010')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(r['results'][0]['namespace'],'project_sample')
        self.assertFalse(r['results'][0]['is_game_id'])
        self.assertEqual(r['results'][0]['components'],['HD_M_1010','BD_M_1010','AM_M_1010','LG_M_1010'])

    def test_unknown_ids_never_fuzzy_resolve(self):
        for q in ('c9999','WP_R_9999'):
            p,r=cli('lookup',q)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertEqual(r['status'],'not_found')
        p,r=cli('lookup','frame_9999')
        self.assertEqual(r['results'][0]['availability'],'not_inspected')
        self.assertFalse(r['results'][0]['is_game_id'])

    def test_query_errors_are_json(self):
        for args in [('lookup',''),('lookup','x','--limit','0'),('lookup','x','--namespace','invented'),('export-static','c6100','--output','x')]:
            p,r=cli(*args)
            self.assertNotEqual(p.returncode,0)
            self.assertEqual(r['status'],'error')
            self.assertTrue(r['error']['code'])

    def test_capabilities_distinguish_lookup_and_conversion(self):
        _,r=cli('capabilities','c6100')
        self.assertEqual(r['results'][0]['operations'],[])
        _,r=cli('capabilities','WP_R_1610')
        self.assertEqual(r['results'][0]['operations'],['export_static'])

if __name__=='__main__':unittest.main()
