import unittest,json,tempfile
from pathlib import Path
from acbridge.verification import assessment
from acbridge.presentation import present

class VerificationSemantics(unittest.TestCase):
 def inspect_case(self,leg):
  with tempfile.TemporaryDirectory() as tmp:
   out=Path(tmp);(out/'request.json').write_text(json.dumps(dict(assembly_method='geometry')))
   (out/'asset.glb').write_bytes(b'test fixture: existence only')
   (out/'blender-readback.json').write_text(json.dumps(dict(status='passed',adapter='identity-basis',sample_policy='all-keys',max_error_m=1e-5)))
   return assessment(out,dict(parts={'lg':dict(part_id=leg)}),dict(status='passed'),{'asset.glb':dict(errors=0)})
 def test_numeric_pass_never_certifies_unknown_appearance(self):
  r=self.inspect_case('lg_m_9999');self.assertEqual(r['geometry']['status'],'source_checks_passed');self.assertEqual(r['blender_consumption']['status'],'passed');self.assertEqual(r['dynamic_appearance']['status'],'not_verified')
 def test_known_leg_anomaly_survives_numeric_pass(self):
  for leg in ['lg_m_7010','lg_m_9400','lg_m_5510']:
   r=self.inspect_case(leg);self.assertEqual(r['dynamic_appearance']['status'],'known_issue_reference');self.assertFalse(r['dynamic_appearance']['current_output_visually_reviewed']);self.assertTrue(r['dynamic_appearance']['issues'])
 def test_transport_keeps_separate_verification_and_evidence_paths(self):
  v=self.inspect_case('lg_m_7010');r=present(dict(operation='export_dynamic_frame',status='partial',verification=v,outputs={'verification.json':'v','geometry-proof.json':'g','preview-manifest.json':'p'},animations=[]))
  self.assertEqual(r['verification'],v);self.assertEqual(len(r['outputs']),3)

 def test_consumer_crash_without_report_is_failure_not_not_run(self):
  with tempfile.TemporaryDirectory() as tmp:
   out=Path(tmp);(out/'request.json').write_text(json.dumps(dict(blender_adapter='identity-basis',animation_check='all-keys')))
   failure=dict(category='consumer_validation',code='stage_failed',message='Blender process exited before writing JSON')
   r=assessment(out,dict(parts={'lg':dict(part_id='lg_m_1010')}),None,{},[failure])
   self.assertEqual(r['blender_consumption']['status'],'failed');self.assertEqual(r['blender_consumption']['adapter'],'identity-basis');self.assertEqual(r['blender_consumption']['policy'],'all-keys');self.assertEqual(r['blender_consumption']['failures'],[failure])

 def test_missing_second_validator_never_certifies_geometry(self):
  with tempfile.TemporaryDirectory() as tmp:
   out=Path(tmp);(out/'request.json').write_text('{}')
   for name in ['asset.glb','asset-ue.glb']:(out/name).write_bytes(b'existence-only fixture')
   r=assessment(out,dict(parts={'lg':dict(part_id='lg_m_1010')}),dict(status='passed'),{'asset.glb':dict(errors=0)})
   self.assertEqual(r['geometry']['status'],'not_validated');self.assertEqual(r['blender_consumption']['status'],'not_run')

if __name__=='__main__':unittest.main()
