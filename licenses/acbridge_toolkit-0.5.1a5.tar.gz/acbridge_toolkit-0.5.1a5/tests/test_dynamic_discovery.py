"""Filesystem contract fixtures only; real parsing/export uses separate game tests."""
import tempfile,unittest
from pathlib import Path
from acbridge.dynamic_worker import discover
from acbridge.lookup import BridgeError

class DiscoveryTests(unittest.TestCase):
    def tree(self,root):
        def put(relative,content=b'fixture'):
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content);return p
        for part in ('bd','hd','am','lg'):
            stem=part+'_m_1400';put(stem+'-partsbnd-dcx/'+stem.upper()+'.FLVER');put(stem+'-partsbnd-dcx/'+stem+'-anibnd-wanibnd/Skeleton.hkx')
        put('bd_m_1400-partsbnd-dcx/BD_M_1400.compendium',b'body types')
        put('chr/c0000-anibnd-dcx-wanibnd/deep/hkx/Skeleton.hkx',b'master')
        put('chr/c0000_a000_01-anibnd-dcx-wanibnd/a000_020100.hkx',b'walk')
        put('chr/c0000_a000_01-anibnd-dcx-wanibnd/a000_01.compendium',b'clip types')
        return put
    def test_real_bundle_naming_and_body_type_fallback(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);self.tree(root);entry,master,clips=discover([root],'frame_1400',['a000_020100'])
            self.assertEqual(set(entry['parts']),{'bd','hd','am','lg'})
            self.assertEqual(Path(entry['parts']['hd']['comp']).name,'BD_M_1400.compendium')
            self.assertEqual(clips['a000_020100'][1].name,'a000_01.compendium')
    def test_missing_animation_cannot_be_filled_from_an_old_sample(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);self.tree(root)
            with self.assertRaises(BridgeError) as caught:discover([root],'frame_1400',['a000_081200'])
            self.assertEqual(caught.exception.code,'missing_resource')
            self.assertIn('a000_081200.hkx',str(caught.exception))
    def test_distinct_duplicate_flver_is_ambiguous(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);put=self.tree(root);put('other/HD_M_1400.flver',b'different version')
            with self.assertRaises(BridgeError) as caught:discover([root],'frame_1400',['a000_020100'])
            self.assertEqual(caught.exception.code,'ambiguous_resource')
    def test_unlisted_clip_uses_its_sibling_compendium_without_a_whitelist(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);put=self.tree(root)
            put('chr/c0000_a000_01-anibnd-dcx-wanibnd/a000_026830.hkx',b'new clip')
            entry,master,clips=discover([root],'frame_1400',['a000_026830'])
            self.assertEqual(clips['a000_026830'][1].name,'a000_01.compendium')
    def test_clip_spec_can_supply_label_identity_and_compendium(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);put=self.tree(root)
            put('chr/c0000_a000_01-anibnd-dcx-wanibnd/a000_026830.hkx',b'new clip')
            spec={'a000_026830':{'label':'test action','identity':'fixture','compendium':'a000_01.compendium'}}
            entry,master,clips=discover([root],'frame_1400',['a000_026830'],clip_spec=spec)
            self.assertEqual(clips['a000_026830'][1].name,'a000_01.compendium')

if __name__=='__main__':unittest.main()
