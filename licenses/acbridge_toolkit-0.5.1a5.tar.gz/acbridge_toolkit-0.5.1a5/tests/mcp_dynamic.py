"""Actual stdio protocol test including a fresh dynamic game export."""
import argparse,asyncio,json,os,sys
from pathlib import Path
from datetime import timedelta
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
ROOT=Path(__file__).resolve().parents[1]

async def run(a):
    env=dict(os.environ,ACBRIDGE_CONFIG=str(Path(a.config).resolve()),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    async with stdio_client(StdioServerParameters(command=sys.executable,args=[str(ROOT/'acbridge.py'),'mcp'],env=env)) as streams:
        async with ClientSession(*streams,read_timeout_seconds=timedelta(minutes=30)) as session:
            await session.initialize();tools=await session.list_tools()
            assert {t.name for t in tools.tools}=={'lookup_asset','asset_capabilities','export_static','inspect_result','export_dynamic_frame','discover_assets','list_clips','check_assembly'}
            cap=await session.call_tool('asset_capabilities',{'query':a.frame});assert not cap.isError
            assert 'export_dynamic_frame' in cap.structuredContent['results'][0]['operations']
            failed=await session.call_tool('export_dynamic_frame',{'asset':'c6100','output':'unused','game_dir':'missing'})
            assert failed.isError and failed.structuredContent['error']['code']=='input_missing'
            failed=await session.call_tool('export_dynamic_frame',{'asset':a.frame,'output':'unused','game_dir':'missing','clips':['not-a-clip']})
            assert failed.isError and failed.structuredContent['error']['code']=='input_missing'
            args=dict(asset=a.frame,output=str(Path(a.output).resolve()),game_dir=str(Path(a.game_dir).resolve()),detail='full')
            r=await session.call_tool('export_dynamic_frame',args)
            if r.isError:raise RuntimeError(r.content)
            data=r.structuredContent
            assert data['status']=='partial' and data['operation']=='export_dynamic_frame'
            inspect=await session.call_tool('inspect_result',{'output':args['output']})
            assert not inspect.isError
            direct=json.loads((Path(a.output)/'result.json').read_text(encoding='utf-8'))
            assert data==direct
            report=dict(status='passed',transport='official SDK ClientSession/stdio_client',tools=[t.name for t in tools.tools],capabilities=cap.structuredContent,error_flags=True,real_export=data,inspection=inspect.structuredContent,mcp_equals_written_shared_api_result=True)
            Path(a.report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps(dict(status='passed',frame=a.frame,report=a.report,glbs=inspect.structuredContent['glbs'])))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--frame',default='frame_1010');p.add_argument('--game-dir',required=True);p.add_argument('--output',required=True);p.add_argument('--config',default='config.local.json');p.add_argument('--report',required=True)
    asyncio.run(run(p.parse_args()))
