import json
import struct
import tempfile
import unittest
from pathlib import Path
import numpy as np

from acbridge.root_analysis import analyze_glb_root


def fixture(path, unequal_times=False):
    binary = bytearray()
    accessors, views = [], []

    def add(values, kind, dtype='float32'):
        binary.extend(b'\0' * (-len(binary) % 4))
        array = np.asarray(values, dtype=dtype)
        offset = len(binary)
        binary.extend(array.tobytes())
        views.append({'buffer': 0, 'byteOffset': offset, 'byteLength': array.nbytes})
        accessors.append({'bufferView': len(views) - 1, 'componentType': 5123 if dtype == 'uint16' else 5126,
                          'count': len(array), 'type': kind})
        return len(accessors) - 1

    attributes = {'POSITION': add([[0, 0, 0], [1, 0, 0]], 'VEC3'),
                  'JOINTS_0': add([[0, 0, 0, 0]] * 2, 'VEC4', 'uint16'),
                  'WEIGHTS_0': add([[1, 0, 0, 0]] * 2, 'VEC4')}
    ib = add([np.eye(4).T.ravel()], 'MAT4')
    times = add([[0], [1]], 'SCALAR')
    other_times = add([[0], [2]], 'SCALAR') if unequal_times else times
    extra = add([[0, 0, 0], [10, 0, 0]], 'VEC3')
    internal = add([[0, 0, 0], [-10, 2, 0]], 'VEC3')
    doc = {'asset': {'version': '2.0'}, 'scene': 0, 'scenes': [{'nodes': [0]}],
           'nodes': [{'name': 'RootMotion', 'children': [1, 2]}, {'name': 'Root'},
                     {'name': 'mesh', 'mesh': 0, 'skin': 0}],
           'meshes': [{'primitives': [{'attributes': attributes}, {'attributes': attributes}]}],
           'skins': [{'joints': [1], 'skeleton': 1, 'inverseBindMatrices': ib}],
           'animations': [{'name': 'fixture_root', 'samplers': [
               {'input': times, 'output': extra}, {'input': other_times, 'output': internal}],
               'channels': [{'sampler': 0, 'target': {'node': 0, 'path': 'translation'}},
                            {'sampler': 1, 'target': {'node': 1, 'path': 'translation'}}]}],
           'accessors': accessors, 'bufferViews': views, 'buffers': [{'byteLength': len(binary)}]}
    raw = json.dumps(doc).encode()
    raw += b' ' * (-len(raw) % 4)
    path.write_bytes(struct.pack('<4sII', b'glTF', 2, 28 + len(raw) + len(binary)) +
                     struct.pack('<II', len(raw), 0x4e4f534a) + raw +
                     struct.pack('<II', len(binary), 0x004e4942) + binary)


class RootAnalysisTests(unittest.TestCase):
    def test_hierarchy_product_and_true_skin_world(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'fixture.glb'
            fixture(p)
            row = analyze_glb_root(p)['animations'][0]
            self.assertEqual(row['world_nodes']['RootMotion']['net_displacement_m'], 10)
            self.assertEqual(row['world_nodes']['Root']['net_displacement_m'], 2)
            self.assertEqual(row['skinned_world']['centroid']['net_displacement_m'], 2)
            self.assertEqual(row['skinned_world']['vertices_evaluated'], 2)
            self.assertEqual(row['sample_intervals'], 1)
            self.assertEqual(row['native_key_intervals_per_second'], 1)
            self.assertEqual(analyze_glb_root(p, ['absent'])['animations'], [])

    def test_unaligned_timeline_is_not_misreported(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'fixture.glb'
            fixture(p, True)
            with self.assertRaisesRegex(ValueError, 'frame-aligned'):
                analyze_glb_root(p)


if __name__ == '__main__':
    unittest.main()
