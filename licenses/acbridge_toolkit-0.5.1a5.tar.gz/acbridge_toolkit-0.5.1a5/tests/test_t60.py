import json,tempfile,unittest
from pathlib import Path
from acbridge.lookup import lookup_asset
from acbridge.operations import capabilities
from acbridge.presentation import present

class T60Contract(unittest.TestCase):
    def test_lookup_and_capabilities_same_unregistered_frame(self):
        for ident in ('frame_1080','frame_7010','frame_99999'):
            a=lookup_asset(ident)['results'][0];b=capabilities(ident)['results'][0]
            self.assertEqual((a['id'],a['namespace']),(b['id'],b['namespace']))
            self.assertFalse(a['is_game_id']);self.assertEqual(a['availability'],'not_inspected')

    def test_summary_preserves_motion_limit_but_full_evidence_stays_full(self):
        original=dict(status='partial',operation='export_dynamic_frame',output='C:/jobs/x',animations=[dict(clip='x',root_motion=dict(extracted_motion_present=False,source='No extractedMotion; real bone tracks remain',downstream_limit='Root-only consumer omits internal tracks',actual_varying_translation_tracks=list(range(100))))])
        brief=present(original)
        self.assertEqual(brief['animations'][0]['root_motion']['varying_translation_track_count'],100)
        self.assertIn('real bone tracks',brief['animations'][0]['root_motion']['source'])
        self.assertIn('omits',brief['animations'][0]['root_motion']['downstream_limit'])
        self.assertEqual(len(original['animations'][0]['root_motion']['actual_varying_translation_tracks']),100)
        self.assertIs(present(original,'full'),original)

    def test_mcp_default_result_and_invalid_detail(self):
        from acbridge.server import result
        d=result(lambda:dict(status='ready',label='\u884c\u8d70'))
        self.assertEqual(json.loads(d.content[0].text)['label'],'\u884c\u8d70');self.assertFalse(d.isError)
        e=result(lambda:dict(status='ready'),detail='unknown')
        self.assertTrue(e.isError);self.assertEqual(e.structuredContent['error']['code'],'invalid_detail')

if __name__=='__main__':unittest.main()
