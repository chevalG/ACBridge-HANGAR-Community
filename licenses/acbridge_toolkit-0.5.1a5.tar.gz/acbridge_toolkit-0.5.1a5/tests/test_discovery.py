import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from acbridge.discovery import discover_assets, list_clips, _animation_rows
from acbridge.lookup import BridgeError


class DiscoveryTests(unittest.TestCase):
    def test_actual_parts_derive_partial_project_frame_without_claiming_game_identity(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'HD_M_9876.flver').write_bytes(b'not parsed')
            (root / 'LG_M_9876.flver').write_bytes(b'not parsed')
            (root / 'WP_R_1150.flver').write_bytes(b'not parsed')
            result = discover_assets('frame-9876', kind='frame', input_roots=[td])
            self.assertEqual(result['total'], 1)
            row = result['results'][0]
            self.assertFalse(row['is_game_id'])
            self.assertEqual(row['missing_slots'], ['am', 'bd'])
            self.assertEqual(row['compatibility'], 'uninspected')
            weapon = discover_assets('wp r 1150', input_roots=[td])
            self.assertEqual(weapon['results'][0]['id'], 'WP_R_1150')

    def test_index_availability_is_distinct_from_actual_game_content(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'Data0.bhd').write_bytes(b'header')
            c = dict(nuxe_res=td)
            with patch('acbridge.discovery.load_config', return_value=c), patch('acbridge.discovery._catalog', return_value={'/parts/wp_r_1150.partsbnd.dcx': 'Data0'}):
                row = discover_assets('1150', config='test', game_dir=td)['results'][0]
                self.assertEqual(row['sources'][0]['availability'], 'container_pair_missing')
                (root / 'Data0.bdt').write_bytes(b'data')
                row = discover_assets('1150', config='test', game_dir=td)['results'][0]
                self.assertEqual(row['sources'][0]['availability'], 'container_pair_present')
                self.assertFalse(row['sources'][0]['content_parsed'])

    def test_environment_configuration_is_honored_by_both_public_apis(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / 'source'
            source.mkdir()
            (source / 'a999_123456.hkx').write_bytes(b'not Havok')
            (root / 'index').mkdir()
            c = dict(nuxe_res=str(root / 'index'), output_root=str(root / 'jobs'), _config=str(root / 'config.json'))
            with patch.dict('os.environ', {'ACBRIDGE_CONFIG': str(root / 'config.json')}), patch('acbridge.discovery.load_config', return_value=c) as loader, patch('acbridge.discovery._catalog', return_value={'/parts/wp_r_1150.partsbnd.dcx': 'Data0'}):
                self.assertEqual(discover_assets('1150')['results'][0]['id'], 'WP_R_1150')
                result = list_clips(input_roots=[str(source)])
                self.assertTrue(Path(result['output']).is_relative_to(root / 'jobs'))
                self.assertEqual(loader.call_count, 2)

    def test_native_sixty_hz_metadata_and_real_compendium_association(self):
        with tempfile.TemporaryDirectory() as td:
            hkx = Path(td) / 'a000_024615.hkx'
            comp = Path(td) / 'types.compendium'
            hkx.write_bytes(b'hkx')
            comp.write_bytes(b'types')
            animation = dict(numFrames=161, duration=8 / 3, frameDuration=1 / 60,
                             numberOfTransformTracks=114, extractedMotion=None)
            class FakeTag:
                def __init__(self, *args, **kwargs): pass
                def root_object(self):
                    return dict(animations=[animation], bindings=[dict(originalSkeletonName='c0000', transformTrackToBoneIndices=list(range(114)))])
            row = _animation_rows(hkx, [comp], FakeTag)[0]
            self.assertEqual(row['native_sample_fps'], 60)
            self.assertEqual(row['transform_tracks'], 114)
            self.assertFalse(row['extracted_motion']['present'])
            self.assertEqual(row['semantic'], 'UNKNOWN')
            self.assertEqual(row['compendium'], str(comp))

    def test_parse_failure_is_retained_as_partial_with_full_report(self):
        with tempfile.TemporaryDirectory() as td:
            source, output = Path(td) / 'source', Path(td) / 'output'
            source.mkdir()
            (source / 'a999_123456.hkx').write_bytes(b'not Havok')
            result = list_clips(input_roots=[str(source)], output=str(output), limit=1)
            self.assertEqual(result['status'], 'partial')
            self.assertEqual(result['metadata_errors'], 1)
            report = json.loads(Path(result['result_json']).read_text(encoding='utf-8'))
            self.assertEqual(report['clips'][0]['error']['code'], 'hkx_metadata_parse_failed')
            self.assertEqual((source / 'a999_123456.hkx').read_bytes(), b'not Havok')

    def test_output_protection_and_empty_bank_error(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / 'source'
            source.mkdir()
            with self.assertRaises(BridgeError) as cm:
                list_clips(input_roots=[str(source)], output=str(source / 'output'))
            self.assertEqual(cm.exception.code, 'path_overlap')
            with self.assertRaises(BridgeError) as cm:
                list_clips(input_roots=[str(source)], output=str(Path(td) / 'empty'))
            self.assertEqual(cm.exception.code, 'archive_contents_missing')
            self.assertTrue(Path(cm.exception.details['result_json']).is_file())


if __name__ == '__main__':
    unittest.main()
