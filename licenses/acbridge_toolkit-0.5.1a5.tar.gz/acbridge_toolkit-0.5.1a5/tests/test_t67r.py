import asyncio
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from acbridge.nameindex import builtin_index_path, name_index_status

ROOT = Path(__file__).resolve().parents[1]
CLEAN_ENV = {k: v for k, v in os.environ.items() if k not in ('ACBRIDGE_NAME_INDEX', 'ACBRIDGE_CONFIG')}


def cli(*args):
    p = subprocess.run([sys.executable, str(ROOT / 'acbridge.py'), *args],
                       capture_output=True, text=True, encoding='utf-8', env=CLEAN_ENV)
    return p, json.loads(p.stdout) if p.stdout.strip().startswith('{') else {}


def builtin():
    return json.loads(builtin_index_path().read_text(encoding='utf-8'))


class T67RDocumentation(unittest.TestCase):
    def test_every_packaged_docs_reference_exists(self):
        doc_files = {p.name for p in (ROOT / 'docs').glob('*.md')}
        scanned = [ROOT / 'acbridge/workflows.py', ROOT / 'acbridge/operations.py',
                   ROOT / 'acbridge/data/workflows.json', ROOT / 'README.md',
                   ROOT / 'NOTICE', *sorted((ROOT / 'docs').glob('*.md'))]
        for p in scanned:
            text = p.read_text(encoding='utf-8', errors='replace')
            for ref in re.findall(r'docs/[\w\-]+\.md', text):
                with self.subTest(file=str(p.relative_to(ROOT)), ref=ref):
                    self.assertIn(ref.split('/', 1)[1], doc_files)

    def test_release_texts_point_to_the_same_version(self):
        version = '0.5.1a5'
        for name, needles in {
            'README.md': [version, 'acbridge_toolkit-0.5.1a5-py3-none-any.whl', '十个共享CLI实现的工具'],
            'NOTICE': [version, 'acbridge_toolkit-0.5.1a5.tar.gz'],
            'docs/installation.md': ['acbridge_toolkit-0.5.1a5-py3-none-any.whl', 'unittest discover'],
            'pyproject.toml': [f'version = "{version}"'],
        }.items():
            text = (ROOT / name).read_text(encoding='utf-8')
            for needle in needles:
                self.assertIn(needle, text, f'{name}: {needle}')
        self.assertNotIn('0.5.1a3-py3-none-any.whl', (ROOT / 'docs/installation.md').read_text(encoding='utf-8'))

    def test_bundled_skill_matches_release(self):
        from acbridge.resources import resources
        r = resources()
        self.assertIsNotNone(r['skill'])
        text = Path(r['skill']).read_text(encoding='utf-8')
        for tool in ('lookup_asset', 'name_index_status', 'build_name_index', 'asset_capabilities',
                     'export_static', 'inspect_result', 'export_dynamic_frame', 'discover_assets',
                     'list_clips', 'check_assembly'):
            self.assertIn(tool, text)
        self.assertIn('10', text.replace('十', '10'))
        self.assertIn('0.5.1a5', text)


class T67RNameIndex(unittest.TestCase):
    def test_shared_archive_annotations_are_content_verified(self):
        entries = builtin()['entries']
        m2720 = [e for e in entries if e['model_id'] == 2720 and e['kind'] == 'weapon']
        self.assertEqual(len(m2720), 2)
        for e in m2720:
            self.assertIn('content_verification', e)
            self.assertIn('distinct dedicated mesh', e['content_verification'])
        left_3010 = next(e for e in entries if e['model_id'] == 3010 and e['side'] == 'left')
        self.assertEqual(left_3010['companion_stems'], ['wp_a_3010'])
        self.assertIn('needs wp_a_3010 geometry', left_3010['content_verification'])
        right_3010 = next(e for e in entries if e['model_id'] == 3010 and e['side'] == 'right')
        self.assertNotIn('companion_stems', right_3010)

    def test_lookup_surfaces_companion_resources(self):
        p, r = cli('lookup', 'VP-66LR')
        self.assertEqual(p.returncode, 0, p.stderr)
        companions = {tuple(x['name_index'].get('companion_resource_ids') or ()) for x in r['results']}
        self.assertIn(('WP_A_2720',), companions)

    def test_overlay_does_not_double_count_entries_by_slot(self):
        base = name_index_status()
        baseline_counts = base['summary']['entries_by_slot']
        data = builtin()
        data['index_version'] = 'local-copy'
        with tempfile.TemporaryDirectory() as t:
            local = Path(t) / 'name_index.local.json'
            local.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            with patch.dict(os.environ, dict(CLEAN_ENV, ACBRIDGE_NAME_INDEX=str(local)), clear=True):
                overlaid = name_index_status()
                self.assertEqual(len(overlaid['local_indexes']), 1)
                self.assertEqual(overlaid['summary']['entries_by_slot'], baseline_counts)
                origins = overlaid['summary']['entry_origin_by_slot']
                self.assertTrue(all(v['builtin'] == 0 and v['local'] > 0 for v in origins.values()))

    def test_mcp_server_exposes_ten_tools(self):
        try:
            from acbridge import server
        except ImportError:
            self.skipTest('mcp SDK not installed')
        tools = asyncio.run(server.server.list_tools())
        names = {t.name for t in tools}
        expected = {'lookup_asset', 'name_index_status', 'build_name_index', 'asset_capabilities',
                    'export_static', 'inspect_result', 'export_dynamic_frame', 'discover_assets',
                    'list_clips', 'check_assembly'}
        self.assertEqual(names, expected)


if __name__ == '__main__':
    unittest.main()
