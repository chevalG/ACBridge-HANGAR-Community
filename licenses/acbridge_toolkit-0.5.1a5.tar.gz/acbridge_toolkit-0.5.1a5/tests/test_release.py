import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from acbridge.operations import doctor
from acbridge.discovery import discover_assets
from acbridge.lookup import catalog

class ReleasePaths(unittest.TestCase):
 def test_expanded_dynamic_doctor_does_not_require_extraction_or_importer(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'validator.js').write_text('');c=p/'config.json';c.write_text(json.dumps(dict(output_root=str(p/'jobs'),validator=str(p/'validator.js'))))
   with patch('acbridge.operations.shutil.which',return_value='runtime'):
    r=doctor(str(c),'expanded');g=doctor(str(c),'game')
   self.assertEqual(r['status'],'ready');self.assertFalse(r['checks']['adapter']);self.assertEqual(g['status'],'error');self.assertIn('nuxe_bridge',g['missing'])
 def test_expanded_discovery_ignores_irrelevant_broken_index(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);inputs=p/'inputs';inputs.mkdir();(inputs/'BD_M_1080.flver').write_bytes(b'filename discovery only')
   c=p/'config.json';c.write_text(json.dumps(dict(output_root=str(p/'jobs'),nuxe_res=str(p/'absent'))))
   r=discover_assets('1080','part',[str(inputs)],config=str(c));self.assertEqual(r['status'],'ready');self.assertEqual(r['total'],1);self.assertEqual(r['results'][0]['id'],'BD_M_1080')
 def test_portable_citations_retain_reference_integrity(self):
  d=catalog();text=json.dumps(d);self.assertNotIn('agent-rusty',text)
  for e in d['entries']:
   for s in e['sources']:self.assertIn(s,d['sources'])

if __name__=='__main__':unittest.main()
