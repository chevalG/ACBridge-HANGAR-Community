import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from acbridge.nameindex import build_local, builtin_index_path, name_index_status, search_name_index

ROOT = Path(__file__).resolve().parents[1]
CLEAN_ENV = {k: v for k, v in os.environ.items() if k not in ('ACBRIDGE_NAME_INDEX', 'ACBRIDGE_CONFIG')}


def cli(*args):
    p = subprocess.run([sys.executable, str(ROOT / 'acbridge.py'), *args],
                       capture_output=True, text=True, encoding='utf-8', env=CLEAN_ENV)
    return p, json.loads(p.stdout) if p.stdout.strip().startswith('{') else {}


def builtin():
    return json.loads(builtin_index_path().read_text(encoding='utf-8'))


WEAPON_FMG = '''<?xml version="1.0" encoding="utf-8"?>
<fmg><entries><text id="10099999">TEST-RIFLE 99</text><text id="30200000">LOCAL-TEST MORLEY</text></entries></fmg>
'''
PART_FMG = '''<?xml version="1.0" encoding="utf-8"?>
<fmg><entries><text id="50999999">HD-999 TEST HEAD</text></entries></fmg>
'''
WEAPON_PARAM = '''<?xml version="1.0" encoding="utf-8"?>
<param><rows>
<row id="10099999" equipModelId="9999" rightHandEquipable="1" leftHandEquipable="0" rightBackEquipable="0" leftBackEquipable="0" shoulderEquipType="1"/>
<row id="30200000" equipModelId="4110" rightHandEquipable="0" leftHandEquipable="0" rightBackEquipable="1" leftBackEquipable="0" shoulderEquipType="0"/>
</rows></param>
'''
PART_PARAM = '''<?xml version="1.0" encoding="utf-8"?>
<param><rows>
<row id="50999999" equipModelId="9999" headEquip="1" legEquip="0"/>
</rows></param>
'''


def write_fixture(root):
    (root / 'item-msgbnd-dcx').mkdir()
    (root / 'item-msgbnd-dcx' / '武器名.fmg.xml').write_text(WEAPON_FMG, encoding='utf-8')
    (root / 'item-msgbnd-dcx' / '防具名.fmg.xml').write_text(PART_FMG, encoding='utf-8')
    (root / 'regulation-bin').mkdir()
    (root / 'regulation-bin' / 'EquipParamWeapon.param.xml').write_text(WEAPON_PARAM, encoding='utf-8')
    (root / 'regulation-bin' / 'EquipParamProtector.param.xml').write_text(PART_PARAM, encoding='utf-8')
    return root / 'item-msgbnd-dcx', root / 'regulation-bin'


class BuiltinIndexIntegrity(unittest.TestCase):
    def test_builtin_file_contract(self):
        data = builtin()
        self.assertEqual(data['index_kind'], 'ac6_equipment_name_index')
        self.assertTrue(data['builtin'])
        self.assertIn('review candidate', data['rights_status'])
        self.assertTrue(data['distribution_basis'])
        weapons = [e for e in data['entries'] if e['kind'] == 'weapon']
        parts = [e for e in data['entries'] if e['kind'] == 'part']
        self.assertEqual(len(weapons), 194)
        self.assertEqual(len(parts), 84)
        text = json.dumps(data)
        self.assertNotIn('paramdexName', text)
        self.assertNotIn('説明', text)
        for e in data['entries']:
            with self.subTest(row=e['row_id']):
                self.assertTrue(e['display_name'])
                self.assertTrue(e['resource_id'] and e['resource_stem'])
                self.assertTrue(e['resource_path'].startswith('/parts/'))
                self.assertGreaterEqual(len(e['evidence']), 2)
        for src in data['sources'].values():
            self.assertRegex(src['sha256'], r'^[0-9a-f]{64}$')

    def test_morley_pair_slot_and_side(self):
        rows = [e for e in builtin()['entries'] if e['display_name'] == 'SB-033M MORLEY']
        self.assertEqual({e['row_id'] for e in rows}, {30200000, 35200000})
        self.assertEqual({e['side'] for e in rows}, {'right', 'left'})
        self.assertEqual({e['slot_group'] for e in rows}, {'shoulder'})
        by_row = {e['row_id']: e for e in rows}
        self.assertEqual(by_row[30200000]['resource_id'], 'WP_R_4110')
        self.assertEqual(by_row[35200000]['resource_id'], 'WP_L_4110')
        self.assertTrue(by_row[30200000]['equip_flags']['rightBack'])
        self.assertTrue(by_row[35200000]['equip_flags']['leftBack'])


class NameLookup(unittest.TestCase):
    def test_four_frame_slots_by_full_name(self):
        for name, ident in [('HD-011 MELANDER', 'HD_M_1010'), ('BD-011 MELANDER', 'BD_M_1010'),
                            ('AR-011 MELANDER', 'AM_M_1010'), ('LG-011 MELANDER', 'LG_M_1010')]:
            with self.subTest(name=name):
                p, r = cli('lookup', name)
                self.assertEqual(p.returncode, 0, p.stderr)
                self.assertEqual(r['status'], 'unique')
                self.assertEqual(r['results'][0]['id'], ident)
                self.assertTrue(r['results'][0]['sources'])

    def test_designation_and_model_code_with_normalization(self):
        for query in ('MORLEY', 'morley', 'SB-033M', 'sb-033m', 'sb 033m morley'):
            with self.subTest(query=query):
                p, r = cli('lookup', query)
                self.assertEqual(p.returncode, 0, p.stderr)
                self.assertEqual(r['status'], 'ambiguous')
                self.assertEqual({x['id'] for x in r['results']}, {'WP_R_4110', 'WP_L_4110'})
                for x in r['results']:
                    self.assertEqual(x['name_index']['slot_group'], 'shoulder')
                self.assertIn('left/right', r['results'][0]['name_index']['disambiguation'])

    def test_cross_slot_designation_lists_all_slots(self):
        p, r = cli('lookup', 'MELANDER', '--limit', '20')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(r['status'], 'ambiguous')
        slots = {x['name_index']['slot'] for x in r['results']}
        self.assertTrue({'HD', 'BD', 'AM', 'LG'} <= slots)

    def test_param_row_id_resolves_to_resource(self):
        p, r = cli('lookup', '30200000')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(r['status'], 'unique')
        self.assertEqual(r['results'][0]['id'], 'WP_R_4110')
        self.assertEqual(r['results'][0]['name_index']['row_id'], 30200000)

    def test_shared_archive_weapon_marks_inference(self):
        p, r = cli('lookup', 'VP-66LH')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(r['status'], 'ambiguous')
        self.assertEqual({x['id'] for x in r['results']}, {'WP_A_2710', 'WP_A_2710'})
        for x in r['results']:
            self.assertEqual(x['name_index']['resource_basis'], 'archive_inventory_shared')
            self.assertIn('shared wp_a_', x['name_index']['resource_note'])

    def test_unknown_ids_never_resolve(self):
        for q in ('c9999', 'WP_R_9999', 'bd_m_9999'):
            with self.subTest(query=q):
                p, r = cli('lookup', q)
                self.assertEqual(p.returncode, 0, p.stderr)
                self.assertEqual(r['status'], 'not_found', q)
        # A partial 3-digit pattern is not an ID; near matches stay unconfirmed
        # suggestions, never an exact resolution.
        p, r = cli('lookup', 'wp_r_999')
        self.assertIn(r['status'], ('suggestions', 'not_found'))
        if r['results']:
            self.assertEqual(r['results'][0]['match']['method'], 'name_index_fuzzy')

    def test_fuzzy_suggestions_without_confirmation(self):
        p, r = cli('lookup', 'morle')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(r['status'], 'suggestions')
        self.assertTrue(any('MORLEY' in x['name_en'] for x in r['results']))

    def test_technical_id_lookup_is_enriched_with_display_name(self):
        p, r = cli('lookup', 'WP_R_1610')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(r['status'], 'unique')
        self.assertEqual(r['results'][0]['id'], 'WP_R_1610')
        self.assertEqual(r['results'][0]['display_name'], 'MA-J-200 RANSETSU-RF')
        self.assertTrue(r['results'][0]['sources'])


class LocalIndexBuildAndOverlay(unittest.TestCase):
    def test_build_overlay_and_precedence(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            msg, reg = write_fixture(root)
            out = root / 'name_index.local.json'
            result = build_local(str(msg), str(reg), None, str(out))
            self.assertEqual(result['status'], 'ready')
            self.assertTrue(out.is_file())
            local = json.loads(out.read_text(encoding='utf-8'))
            self.assertFalse(local['builtin'])
            self.assertIn('do not redistribute', local['rights_notice'])
            env = dict(CLEAN_ENV, ACBRIDGE_NAME_INDEX=str(out))
            with patch.dict(os.environ, env, clear=True):
                status = name_index_status()
                self.assertEqual(len(status['local_indexes']), 1)
                # Fixture-only name resolves through the overlay.
                hit = search_name_index('TEST-RIFLE 99')
                self.assertEqual(hit['status'], 'unique')
                self.assertEqual(hit['results'][0]['id'], 'WP_R_9999')
                self.assertEqual(hit['results'][0]['name_index']['resource_basis'], 'param_model_id_unverified')
                # Same (kind,row_id) key: local row overlays the builtin MORLEY row.
                morley = search_name_index('LOCAL-TEST MORLEY')
                self.assertEqual(morley['status'], 'unique')
                self.assertEqual(morley['results'][0]['name_index']['row_id'], 30200000)
                self.assertNotEqual(morley['results'][0]['name_index']['origin'], 'builtin')
                builtin_side = search_name_index('SB-033M')
                self.assertEqual({x['name_index']['origin'] for x in builtin_side['results']}, {'builtin'})

    def test_build_refuses_builtin_path(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            msg, reg = write_fixture(root)
            from acbridge.lookup import BridgeError
            with self.assertRaises(BridgeError):
                build_local(str(msg), str(reg), None, str(builtin_index_path()))


class CliMcpConsistency(unittest.TestCase):
    QUERIES = [('lookup', 'MORLEY'), ('lookup', 'HD-011 MELANDER'), ('lookup', '30200000'),
               ('name-index',)]

    def test_cli_and_shared_api_agree(self):
        from acbridge.lookup import lookup_asset
        from acbridge.presentation import present
        for args in self.QUERIES:
            with self.subTest(args=args):
                p, r = cli(*args)
                self.assertEqual(p.returncode, 0, p.stderr)
                if args[0] == 'lookup':
                    reference = present(lookup_asset(args[1]), 'summary')
                    self.assertEqual(r['status'], reference['status'])
                    self.assertEqual([x['id'] for x in r['results']], [x['id'] for x in reference['results']])

    def test_mcp_tool_matches_cli_when_sdk_present(self):
        try:
            from acbridge import server
        except ImportError:
            self.skipTest('mcp SDK not installed')
        for args in self.QUERIES:
            with self.subTest(args=args):
                p, r = cli(*args)
                if args[0] == 'lookup':
                    res = server.lookup_asset(args[1])
                    payload = json.loads(res.content[0].text)
                    self.assertEqual(payload['status'], r['status'])
                    self.assertEqual([x['id'] for x in payload['results']], [x['id'] for x in r['results']])


if __name__ == '__main__':
    unittest.main()
