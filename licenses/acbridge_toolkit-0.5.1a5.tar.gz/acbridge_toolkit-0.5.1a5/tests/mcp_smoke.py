"""Actual SDK stdio client, not direct function invocation.

Pass --export --input-root PATH --output PATH --config PATH for a real MCP export.
"""
import argparse,asyncio,json,os,sys
from pathlib import Path
from datetime import timedelta
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from acbridge.lookup import lookup_asset

async def run(a):
    env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    if a.config:env['ACBRIDGE_CONFIG']=str(Path(a.config).resolve())
    server=StdioServerParameters(command=sys.executable,args=[str(ROOT/'acbridge.py'),'mcp'],env=env)
    async with stdio_client(server) as streams:
        async with ClientSession(*streams,read_timeout_seconds=timedelta(minutes=30)) as session:
            await session.initialize()
            tools=await session.list_tools()
            assert {t.name for t in tools.tools}=={'lookup_asset','asset_capabilities','export_static','inspect_result','export_dynamic_frame','discover_assets','list_clips','check_assembly'}
            checks=[]
            for q in ('c 6100','WP_R_1610','wp r 161','frame_1010','c9999'):
                r=await session.call_tool('lookup_asset',{'query':q})
                assert not r.isError
                data=r.structuredContent
                assert data==lookup_asset(q),(q,data)
                checks.append({'query':q,'status':data['status'],'ids':[e['id'] for e in data['results']]})
            bad=await session.call_tool('lookup_asset',{'query':''})
            assert bad.isError and bad.structuredContent['error']['code']=='invalid_query'
            missing=await session.call_tool('export_static',{'asset':'WP_R_1610','output':'unused','input_roots':['/nonexistent-acbridge-input']})
            assert missing.isError and missing.structuredContent['error']['code']=='input_missing'
            report={'status':'passed','transport':'official SDK stdio ClientSession','tools':[t.name for t in tools.tools],'lookup_parity':checks,'error_flags':True}
            if a.export:
                r=await session.call_tool('export_static',{'asset':a.asset,'output':str(Path(a.output).resolve()),'input_roots':[str(Path(p).resolve()) for p in a.input_root]})
                if r.isError:raise RuntimeError(r.content)
                report['real_export']=r.structuredContent
                r=await session.call_tool('inspect_result',{'output':str(Path(a.output).resolve())})
                assert not r.isError;report['inspection']=r.structuredContent
            return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config');p.add_argument('--export',action='store_true');p.add_argument('--asset',default='WP_L_0411');p.add_argument('--input-root',action='append');p.add_argument('--output');p.add_argument('--report',required=True)
    a=p.parse_args();report=asyncio.run(run(a));Path(a.report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'status':report['status'],'report':str(Path(a.report).resolve())}))
