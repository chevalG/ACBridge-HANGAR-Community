import json,subprocess,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
import test_dynamic_discovery as fixtures
from acbridge.dynamic_worker import discover,clip_archives
ROOT=Path(__file__).resolve().parents[1]
class ReviewFixes(unittest.TestCase):
    def test_explicit_missing_compendium_is_never_substituted(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixtures.DiscoveryTests().tree(root)
            for comp in ('wrong.compendium',str(root/'absent/a000_01.compendium')):
                failures=[];entry,master,clips=discover([root],'frame_1400',['a000_020100'],clip_spec={'a000_020100':{'compendium':comp}},failures=failures)
                self.assertFalse(clips);self.assertEqual(failures[0]['code'],'missing_compendium')
    def test_one_missing_reference_bank_does_not_cancel_other_clip(self):
        job=SimpleNamespace(request={'clips':['a000_020100','a000_081200']},failures=[])
        game=SimpleNamespace(catalog={'/chr/c0000_a000_02.anibnd.dcx':'Data0'})
        self.assertEqual(clip_archives(job,game),['/chr/c0000_a000_02.anibnd.dcx'])
        self.assertEqual(job.failures[0]['clip'],'a000_020100')
    def test_malformed_models_are_structured_input_errors(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            for parts in ([], 'x', {'bd':[]}, {'bd':{'flver':7}}):
                path=root/'models.json';path.write_text(json.dumps({'parts':parts}))
                p=subprocess.run([sys.executable,str(ROOT/'acbridge.py'),'export-dynamic-frame','my-mix','--models',str(path),'--input-root',t,'--output',str(root/'output')],capture_output=True,text=True,encoding='utf-8')
                data=json.loads(p.stdout);self.assertEqual(data['error']['code'],'invalid_models');self.assertNotEqual(p.returncode,0)
