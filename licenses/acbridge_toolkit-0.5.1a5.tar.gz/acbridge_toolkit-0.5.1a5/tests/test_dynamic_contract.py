import json,subprocess,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def cli(*args):
    p=subprocess.run([sys.executable,str(ROOT/'acbridge.py'),*args],stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding='utf-8')
    return p,json.loads(p.stdout) if p.stdout.startswith('{') else {}
class DynamicContract(unittest.TestCase):
    def test_both_project_samples_discover_dynamic_input_and_workflow(self):
        for ident in ('frame_1010','frame_1400'):
            for command in ('lookup','capabilities'):
                p,d=cli(command,ident);self.assertEqual(p.returncode,0,p.stderr)
                e=d['results'][0];self.assertFalse(e['is_game_id'])
                self.assertIn('export_dynamic_frame',e.get('operations',[]))
                self.assertTrue(e.get('related_workflows'))
                self.assertTrue(e.get('required_inputs'))
                self.assertEqual(e['operation_status']['export_dynamic_frame'],'attemptable')
    def test_character_samples_are_rejected_before_input_or_config(self):
        p,d=cli('export-dynamic-frame','c6100','--game-dir','missing','--output','jobs/unused')
        self.assertEqual(p.returncode,2)
        self.assertEqual(d['error']['code'],'input_missing')
    def test_assembled_frame_pattern_is_accepted_but_runtime_input_is_still_required(self):
        p,d=cli('export-dynamic-frame','frame_3010','--game-dir','missing','--output','jobs/unused')
        self.assertEqual(p.returncode,2)
        self.assertEqual(d['error']['code'],'input_missing')
    def test_non_clip_syntax_is_rejected(self):
        p,d=cli('export-dynamic-frame','frame_1400','--clip','not-a-clip','--game-dir','missing','--output','jobs/unused')
        self.assertEqual(p.returncode,2)
        self.assertEqual(d['error']['code'],'input_missing')
    def test_unlisted_original_clip_syntax_is_accepted_for_resolution(self):
        p,d=cli('export-dynamic-frame','frame_1400','--clip','a000_026830','--game-dir','missing','--output','jobs/unused')
        self.assertEqual(p.returncode,2)
        self.assertEqual(d['error']['code'],'input_missing')
    def test_assembled_frame_capability_is_explicitly_bounded(self):
        p,d=cli('capabilities','frame_3010');self.assertEqual(p.returncode,0)
        e=d['results'][0];self.assertEqual(e['namespace'],'assembled_frame')
        self.assertEqual(e['operation_status']['export_dynamic_frame'],'attemptable')
        self.assertIn('Resources are not yet inspected',e['limitations'][0])
    def test_dynamic_export_input_missing_is_explicit(self):
        p,d=cli('export-dynamic-frame','frame_1400','--input-root','missing','--output','jobs/unused')
        self.assertEqual(p.returncode,2)
        self.assertEqual(d['error']['code'],'input_missing')
    def test_decode_is_public_documented_interface(self):
        p=subprocess.run([sys.executable,str(ROOT/'acbridge.py'),'decode-hkx','--help'],stdin=subprocess.DEVNULL,capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('--skeleton-hkx',p.stdout)
        self.assertIn('--compendium',p.stdout)
    def test_character_is_not_dynamic_frame(self):
        p,d=cli('capabilities','c6100');self.assertEqual(p.returncode,0)
        self.assertNotIn('export_dynamic_frame',d['results'][0]['operations'])
        self.assertTrue(d['results'][0]['related_workflows'])
if __name__=='__main__':unittest.main()
