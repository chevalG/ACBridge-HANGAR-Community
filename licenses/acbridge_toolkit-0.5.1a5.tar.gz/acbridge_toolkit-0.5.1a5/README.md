# ACBridge Toolkit 0.5.1a5 · Alpha RC candidate

**Release Blocked：本地评估候选，代码/索引授权及最终发布授权未清，不对外分发。** T66以GPL-3.0-only组合作品候选准备，第三方原许可保留；本轮仅整改许可、署名和索引标签，没有修改装配或HKX算法，不宣称全游戏兼容。用户自行提供合法原版资源，游戏资产和第三方原生工具不随包提供。

## 从wheel安装

Windows PowerShell；在只有候选wheel的新目录执行，不需要开发源码：

```powershell
py -3 -m venv .venv
./.venv/Scripts/python.exe -m pip install './acbridge_toolkit-0.5.1a5-py3-none-any.whl[dynamic,mcp,preview]'
./.venv/Scripts/acbridge.exe --version
./.venv/Scripts/acbridge.exe resources
./.venv/Scripts/acbridge.exe init ./workspace
```

这是本地wheel命令，不是PyPI已发布声明。激活venv后使用`acbridge`；不能激活时直接用exe绝对路径或`.venv/Scripts/python.exe -m acbridge`，不要求修改PowerShell策略。`resources`定位已安装文档/示例，`init`复制到新工作目录，不覆盖已有目录。裸包支持轻量lookup；动态导出需`[dynamic]`，MCP需`[mcp]`，GIF需`[preview]`。

## 选择输入

| 输入 | 必需组件 | 独立使用边界 |
|---|---|---|
| 已展开FLVER、Skeleton、HKX、compendium | Python动态依赖、Node.js、官方glTF Validator；Blender可选 | 正式文档化入口；不需要Adapter.exe、NuxeBridge.exe、WitchyBND.exe、Nuxe索引或外部FLVER importer |
| 原版Game BHD/BDT | 上述组件+NuxeBridge、Nuxe资源索引、WitchyBND | 既有环境可用；NuxeBridge尚无经核实的公开安装包，不能承诺只有Game的新用户可完成 |
| 静态模型/武器 | 额外需要Adapter/.NET、Blender、FLVER importer | 保留既有能力；不列为本轮干净安装承诺 |

工具作用、版本、许可证及可核实来源见[依赖清单](docs/dependencies.md)。不需要Ninja Ripper、私人捕获或UE工程。

## 展开资源完整工作流

在workspace中准备Validator与私人配置：

```powershell
npm install --prefix ./user-tools gltf-validator@2.0.0-dev.3.10
Copy-Item config.example.json config.local.json
acbridge doctor --config config.local.json --input-mode expanded
acbridge discover-assets --input-root ./expanded --kind part --config config.local.json
acbridge list-clips --input-root ./expanded --config config.local.json --output ./jobs/bank --limit 10
acbridge export-dynamic-frame frame_1010 --input-root ./expanded --clip a000_020100 --config config.local.json --output ./jobs/my-ac
acbridge inspect ./jobs/my-ac --config config.local.json
```

先按[安装与输入说明](docs/installation.md)准备展开目录。示例配置仅含validator/output_root，路径相对配置目录。没有Blender时仍可生成并验证GLB，消费数值为not_run；填写blender可执行路径后获得真实数值回读与asset.blend。

`frame_NUMBER`是同尾号四槽便利标签，不是官方模型ID。任意标签可重复`--part bd=... --part hd=... --part am=... --part lg=...`混装，也可用models/clip-spec显式文件。未知资源允许实际尝试；缺骨、错误轨数和部分动作失败如实保留，无覆盖率门禁。

## 消费与结果

**动画优先使用asset-ue.glb**：它是标准glTF，不专属Unreal。asset.glb可能有NODE_SKINNED_MESH_NON_ROOT警告，报告不隐藏。

默认`--blender-adapter default`保持普通导入，存在型号相关骨轴消费偏差；若失败，可在新作业显式尝试`--blender-adapter identity-basis --animation-check all-keys`。此适配只在本机Blender4.5.12等有限样本验证，不设为全局默认。预览另加`--render-preview`，需要Blender和preview extra。

先看completion、failures、warnings、verification。geometry源检查、Blender数值和动态外观是独立结论；partial不是无产物，output_valid不是动态PASS。新输出保留not_verified或known_issue_reference。7010机械控制、9400异常、5510坦克分支仍未解决，允许尝试。

NLA只启用目标轨并清空活动Action，不归零全部pose；源HKX秒时间与Blender30FPS显示时间基独立。In-Place仍保留高度等骨轨。front相机标签沿用源朝向，不保证真正正面，必要时旋转查看。见[Blender说明](docs/blender-playback.md)、[验证语义](docs/verification.md)、[已知限制](docs/known-limitations.md)。

## MCP与Agent

`acbridge mcp`启动十个共享CLI实现的工具（lookup_asset、name_index_status、build_name_index、asset_capabilities、export_static、inspect_result、export_dynamic_frame、discover_assets、list_clips、check_assembly）。设置ACBRIDGE_CONFIG为配置绝对路径，PYTHONUTF8=1、PYTHONIOENCODING=utf-8；MCP相对路径按配置目录，CLI按当前目录。parts字典、clips数组和assembly_method/blender_adapter/animation_check/render_preview对应CLI同名横线选项。默认摘要，按需读取完整结果；不改生产MCP注册。

Agent操作说明随包分发：`acbridge resources`输出的skill路径（`skills/acbridge/SKILL.md`，与本版10个MCP工具一致）；`init`会连同文档复制到新工作区。不要使用机器上遗留的旧版全局Skill。

[安装](docs/installation.md) · [依赖](docs/dependencies.md) · [许可状态](docs/licensing.md) · [输入格式](docs/dynamic-pipeline.md)

T66范围：expanded-only。Game及静态入口保留为历史代码，不属于首版安装/发行支持承诺。许可状态以本版NOTICE与docs/licensing.md为准。
技术ID编目保持T66的24条无名称种子；装备显示名称查询由独立的T66-N名称索引提供（`lookup "MORLEY"`、`name-index`、`build-name-index`，覆盖四槽部件与手/肩武器的engus名称，来源与分发依据见[名称索引](docs/name-index.md)）。用户本地生成的名称映射不随包分发。
对应源码与构建见[构建说明](docs/building.md)。
