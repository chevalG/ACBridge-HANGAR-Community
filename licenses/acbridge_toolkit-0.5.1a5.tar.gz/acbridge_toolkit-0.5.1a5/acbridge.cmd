@echo off
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONDONTWRITEBYTECODE=1
if defined ACBRIDGE_PYTHON goto explicit
where py.exe >nul 2>nul
if errorlevel 1 goto fallback
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if errorlevel 1 goto fallback
py -3 "%~dp0acbridge.py" %*
exit /b %ERRORLEVEL%
:explicit
"%ACBRIDGE_PYTHON%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if errorlevel 1 goto missing
"%ACBRIDGE_PYTHON%" "%~dp0acbridge.py" %*
exit /b %ERRORLEVEL%
:fallback
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if errorlevel 1 goto missing
python "%~dp0acbridge.py" %*
exit /b %ERRORLEVEL%
:missing
echo {"schema_version":1,"status":"error","error":{"code":"python_version","message":"Python 3.11+ required. Set ACBRIDGE_PYTHON to a compatible interpreter executable."}}
exit /b 2
